"""Fetch public Yahoo Finance daily price data for the comparison universe.

Preserve raw responses and provenance; no credentials or private account access.
The default sample is 2021-11-05 through 2026-11-06 inclusive.
"""
from __future__ import annotations

import concurrent.futures
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.parse
import urllib.request

import pandas as pd

OUT = Path(__file__).resolve().parent
RAW = OUT / "raw"
TICKERS = "NVDA INTC AMZN SBUX KO PG JNJ WMT XOM JPM DUK SPY GLD IEF SGOV".split()
START = dt.datetime(2021, 11, 5, tzinfo=dt.timezone.utc)
END = dt.datetime(2026, 11, 7, tzinfo=dt.timezone.utc)


def fetch(symbol: str):
    params = {
        "period1": int(START.timestamp()),
        "period2": int(END.timestamp()),
        "interval": "1d",
        "events": "div,splits,capitalGains",
        "includeAdjustedClose": "true",
    }
    url = "https://query2.finance.yahoo.com/v8/finance/chart/" + symbol + "?" + urllib.parse.urlencode(params)
    request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    retrieved = dt.datetime.now(dt.timezone.utc).isoformat()
    with urllib.request.urlopen(request, timeout=40) as response:
        body = response.read()
    obj = json.loads(body)
    if obj["chart"]["error"]:
        raise RuntimeError(f"{symbol}: {obj['chart']['error']}")
    result = obj["chart"]["result"][0]
    (RAW / f"{symbol}.json").write_bytes(body)
    dates = pd.to_datetime(result["timestamp"], unit="s", utc=True).tz_convert("America/New_York").date
    adjusted = pd.Series(result["indicators"]["adjclose"][0]["adjclose"], index=dates, name=symbol)
    close = pd.Series(result["indicators"]["quote"][0]["close"], index=dates, name=symbol)
    if not adjusted.index.is_unique:
        raise ValueError(f"{symbol}: duplicate session dates")
    meta = {
        "ticker": symbol,
        "provider": "Yahoo Finance public chart endpoint",
        "source_url": url,
        "retrieved_utc": retrieved,
        "sha256": hashlib.sha256(body).hexdigest(),
        "raw_file": f"raw/{symbol}.json",
        "first_date": str(adjusted.index[0]),
        "last_date": str(adjusted.index[-1]),
        "rows": len(adjusted),
        "null_adjusted": int(adjusted.isna().sum()),
        "null_close": int(close.isna().sum()),
        "currency": result["meta"].get("currency"),
        "adjustment": "Yahoo adjusted close, adjusted for stock splits and distributions as supplied by provider",
        "split_events": result.get("events", {}).get("splits", {}),
        "dividend_event_count": len(result.get("events", {}).get("dividends", {})),
    }
    print(symbol, meta["rows"], meta["first_date"], meta["last_date"], "nulls", meta["null_adjusted"], flush=True)
    return adjusted, close, meta


def main():
    RAW.mkdir(parents=True, exist_ok=True)
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        results = list(executor.map(fetch, TICKERS))
    adjusted = pd.concat([r[0] for r in results], axis=1).sort_index()
    close = pd.concat([r[1] for r in results], axis=1).sort_index()
    adjusted.index.name = close.index.name = "Date"
    adjusted.to_csv(OUT / "adjusted_close.csv", float_format="%.10f")
    close.to_csv(OUT / "close.csv", float_format="%.10f")
    (OUT / "provenance.json").write_text(json.dumps({
        "requested_start_inclusive": START.date().isoformat(),
        "requested_end_inclusive": (END - dt.timedelta(days=1)).date().isoformat(),
        "ticker_order": TICKERS,
        "series": [r[2] for r in results],
        "join": "outer by New York trading-session date; no forward fill",
        "adjusted_close_definition_url": "https://help.yahoo.com/kb/SLN28256.html",
    }, indent=2), encoding="utf-8")
    print("Joined shape", adjusted.shape, "missing", int(adjusted.isna().sum().sum()), flush=True)


if __name__ == "__main__":
    main()
