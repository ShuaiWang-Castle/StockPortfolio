from pathlib import Path
import json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
p=pd.read_csv(ROOT/'adjusted_close.csv',index_col='Date',parse_dates=True)
ret=p.pct_change(fill_method=None).iloc[1:]
old={'VTI':.35,'NVDA':.20,'MSFT':.15,'AMZN':.10,'XLV':.10,'SGOV':.10}
replacement={'VTI':.35,'NVDA':.15,'MSFT':.10,'AMZN':.10,'GOOGL':.10,'XLV':.10,'SGOV':.10}
add_all={t:w*5/6 for t,w in old.items()};add_all['GOOGL']=1/6
add_balanced={t:5000*w/6000 for t,w in old.items()}
for t,dollars in {'VTI':350,'GOOGL':450,'XLV':100,'SGOV':100}.items():
 add_balanced[t]=add_balanced.get(t,0)+dollars/6000
specs={'original_5000':{'weights':old,'capital':5000},'replace_5000':{'weights':replacement,'capital':5000},'replace_6000':{'weights':replacement,'capital':6000},'add_all_google_6000':{'weights':add_all,'capital':6000},'add_balanced_6000':{'weights':add_balanced,'capital':6000}}
valuation_plan={'VTI':.40,'NVDA':.15,'MSFT':.10,'AMZN':.05,'GOOGL':.10,'XLV':.10,'SGOV':.10}
specs['valuation_plan_5000']={'weights':valuation_plan,'capital':5000}
specs['valuation_plan_6000']={'weights':valuation_plan,'capital':6000}

def run(r,w):
 target=pd.Series(w).reindex(r.columns,fill_value=0.)
 assert np.isclose(target.sum(),1) and target.min()>=0
 current=target.copy();last=None;out=[]
 for date,row in r.iterrows():
  quarter=date.to_period('Q')
  if quarter!=last: current=target.copy();last=quarter
  rp=float(current@row);out.append(rp)
  current=current*(1+row)/(1+rp)
 return pd.Series(out,index=r.index)

def stats(r,start):
 wealth=(1+r).cumprod();dd=wealth/wealth.cummax().clip(lower=1)-1
 return {'ann_vol':r.std(ddof=1)*np.sqrt(252),'max_drawdown':dd.min(),
         'cagr':wealth.iloc[-1]**(365.25/(r.index[-1]-start).days)-1,
         'es95_daily_loss':-r[r<=r.quantile(.05)].mean(),
         'nov5_return':r.loc['2026-11-05'], 'n_returns':len(r)}

results={};paths={}
for key,spec in specs.items():
 results[key]={**spec}
 for window,start in [('five_year',pd.Timestamp('2021-11-05')),('two_year',pd.Timestamp('2024-11-06'))]:
  r=ret.loc[ret.index>start];rp=run(r,spec['weights'])
  results[key][window]=stats(rp,start)
  results[key][window]['annual_dollar_vol_at_initial_capital']=results[key][window]['ann_vol']*spec['capital']
  results[key][window]['dollar_drawdown_if_peak_equals_initial_capital']=results[key][window]['max_drawdown']*spec['capital']
  if window=='five_year': paths[key]=rp

swap_results=[]
for t in ['GOOGL','META','TSM','AVGO','PLTR','AMD','VRT','MU']:
 w=old.copy();w['NVDA']-=.05;w['MSFT']-=.05;w[t]=.10
 r=ret.loc[ret.index>pd.Timestamp('2024-11-06')]
 swap_results.append({'ticker':t,**stats(run(r,w),pd.Timestamp('2024-11-06'))})

holdings={'NVDA':.0687,'MSFT':.0510,'AMZN':.0340,'GOOGL':.0269+.0212}
through={}
for key,spec in specs.items():
 w=spec['weights'];through[key]={t:w.get(t,0)+w.get('VTI',0)*f for t,f in holdings.items()}
 through[key]['same_four_issuer_total']=sum(through[key].values())
final={'meta':{'price_end':'2026-11-06','two_year_price_start':'2024-11-06','five_year_price_start':'2021-11-05','rebalance':'quarterly, previous quarter-end close, weights drift within quarter','fees_taxes':'excluded','interpretation':'retrospective comparison of fixed candidate weights; not optimized on these returns'},'portfolio_results':results,'candidate_swaps_same_10pct':swap_results,'lookthrough_20260831':through}
(ROOT/'expansion_comparison.json').write_text(json.dumps(final,ensure_ascii=False,indent=2))
pd.DataFrame(paths).to_csv(ROOT/'expansion_portfolio_returns.csv')
pd.DataFrame(swap_results).to_csv(ROOT/'candidate_swap_risk.csv',index=False)
for key,item in results.items():print(key,json.dumps({window:item[window] for window in ['two_year','five_year']},ensure_ascii=False))
print('LOOKTHROUGH',json.dumps(through,ensure_ascii=False))
print('SWAPS',pd.DataFrame(swap_results).round(5).to_string(index=False))
