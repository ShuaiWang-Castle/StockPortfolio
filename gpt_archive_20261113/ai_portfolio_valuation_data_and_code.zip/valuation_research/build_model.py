"""Reproducible public-data accounting screen and conditional FCFF valuation.

All statement money is USD billions, shares billions, prices USD.
Source JSON files retain raw financial periods, accession numbers and formulas.
Forecast assumptions are analyst scenarios, not reported facts or price targets.
"""
from pathlib import Path
import json, math, csv
import numpy as np
import pandas as pd
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'valuation_research'
P = json.loads((OUT/'platforms.json').read_text())['companies']
S = json.loads((OUT/'semiconductors.json').read_text())['companies']
W = json.loads((OUT/'software_infra.json').read_text())['companies']
prices = pd.read_csv(ROOT/'ai_expansion_analysis/close.csv',index_col=0).iloc[-1]
adj = pd.read_csv(ROOT/'ai_expansion_analysis/adjusted_close.csv',index_col=0,parse_dates=True)
port = json.loads((ROOT/'ai_expansion_analysis/expansion_comparison.json').read_text())

def val(x):
    if x is None: return None
    if isinstance(x,(float,int)): return x
    for key in ['value','value_usd_billions','value_billions','value_shares_billions']:
        if key in x: return x[key]
    return None

def urls(obj):
    found=[]
    def walk(x):
        if isinstance(x,dict):
            for k,v in x.items():
                if k in ['source_url','url','filing_url','latest_report_url','source_urls']:
                    for u in ([v] if isinstance(v,str) else v if isinstance(v,list) else []):
                        if isinstance(u,str) and u.startswith('https://') and u not in found: found.append(u)
                elif k!='evidence': walk(v)
        elif isinstance(x,list):
            for y in x: walk(y)
    walk(obj)
    return found

names={'GOOGL':'Alphabet','MSFT':'Microsoft','AMZN':'Amazon','META':'Meta',
       'NVDA':'NVIDIA','AVGO':'Broadcom','AMD':'AMD','MU':'Micron','TSM':'TSMC',
       'PLTR':'Palantir','VRT':'Vertiv'}
notes={
 'GOOGL':'投资重估放大GAAP净利润；现金流承受AI资本支出；A/B/C股数合并，以GOOGL价近似全部普通股。',
 'MSFT':'GAAP净利润含投资收益；现金CapEx未含非现金融资租赁新增资产；租赁负债重要。',
 'AMZN':'Anthropic等投资重估放大净利润；统一毛现金CapEx口径的FCF为负。',
 'META':'TTM包含税收利益及诉讼费用；10月优先股融资、远期售股须另看；简单倍数未假定全部远期股份已发行。',
 'NVDA':'最新报告截止7月，盈利含投资收益；流动股票投资不是现金；利润率和应收款需跟踪。',
 'AVGO':'SBC较高；收购无形资产摊销影响GAAP盈利；短期投资余额未单独核实。',
 'AMD':'估值依赖未来经营利润增长；毛现金CapEx和SBC调整后的现金收益率偏低。',
 'MU':'53周财年；当前营业利润率远高于上年，不能把周期高点利润永久化。',
 'TSM':'1 ADS=5普通股；TIFRS与US GAAP现金流利息分类不同；TTM SBC未单独核实，保留空值。',
 'PLTR':'高市销率；SBC及较低当期税率影响持续每股收益；当前股数不等于加权稀释股数。',
 'VRT':'FCF包含客户预付款和营运资本净流入；不能把当期现金转换率永久化。'
}

companies=[]
for t in ['GOOGL','MSFT','AMZN','NVDA','META','TSM','AVGO','AMD','MU','VRT','PLTR']:
    c={'ticker':t,'name':names[t],'price':float(prices[t]),'price_date':'2026-11-06','notes':notes[t]}
    if t in P:
        q=P[t]; tt=q['ttm']; bs=q['latest_balance_sheet']
        c.update(ttm_revenue=val(tt['revenue']),ttm_op_income=val(tt['operating_income_gaap']),
                 ttm_net_income=val(tt['net_income_available_to_common_gaap']),cfo=val(tt['operating_cash_flow']),
                 cash_capex=val(tt['cash_capex_gross']),sbc=val(tt['stock_based_compensation']),
                 cash=val(bs['cash_equivalents']),short_investments=val(bs['short_term_marketable_investments']),
                 debt=val(bs['interest_bearing_debt_excluding_leases']),finance_lease_debt=val(bs.get('finance_lease_liabilities')),
                 financial_period_end='2026-09-30',source_urls=urls(q),
                 cash_lease_principal=val(tt['finance_lease_principal_payments']))
        sh=bs.get('common_shares_latest_cover_date',bs['common_shares_outstanding'])
        c.update(share_count_billion=val(sh),share_date=sh['asof'],share_basis='最新披露普通股总数；按同一普通股价格近似',
                 diluted_shares_billion=val(q['latest_quarter']['weighted_average_diluted_shares']))
    elif t in S:
        q=S[t]; ss=q['summary_usd_billions']; bs=q['balance']; sh=q['shares']
        c.update(ttm_revenue=ss['revenue'],ttm_op_income=ss['operating_income_gaap'],
                 ttm_net_income=ss['net_income_attributable_to_parent_gaap'],cfo=ss['cfo'],
                 cash_capex=ss['cash_capex_gross'],sbc=ss['sbc_cashflow_addback'],
                 cash=val(bs['cash_and_equivalents']),financial_period_end=q['latest_period_end'],source_urls=urls(q),
                 cash_lease_principal=None,finance_lease_debt=val(bs.get('finance_lease_liabilities')))
        if t=='TSM':
            c.update(share_count_billion=25.932/5,share_date='2026-09-30',share_basis='已披露普通股25.932bn / 5，ADS等值股数；原股数四舍五入',
                     diluted_shares_billion=25.932/5,
                     short_investments=val(bs['current_marketable_financial_instruments']),debt=val(bs['interest_bearing_debt_carrying']))
        else:
            chosen=sh.get('cover_common',sh['period_end_common'])
            c.update(share_count_billion=val(chosen),share_date=chosen['asof'],share_basis='最新10-Q/10-K封面普通股总数',
                     diluted_shares_billion=val(sh['latest_quarter_diluted_weighted_average']))
            if t=='NVDA': short=val(bs['current_marketable_debt_securities'])+val(bs['current_marketable_equity_securities'])
            elif t=='AVGO': short=None
            else: short=val(bs['short_term_investments'])
            c['short_investments']=short
            c['debt']=val(bs.get('interest_bearing_debt_carrying',bs.get('interest_bearing_notes_carrying_excluding_finance_leases')))
    else:
        q=W[t]; tt=q['ttm'];bs=q['balance_sheet'];sh=q['shares']
        c.update(ttm_revenue=val(tt['revenue']),ttm_op_income=val(tt['gaap_operating_income']),
                 ttm_net_income=val(tt['net_income_attributable_common']),cfo=val(tt['cfo']),
                 cash_capex=val(tt['cash_capex_total']),sbc=val(tt['sbc']),
                 cash=val(bs['cash_and_cash_equivalents']),short_investments=val(bs.get('short_term_investments',bs.get('marketable_securities'))),
                 debt=val(bs['interest_bearing_debt_gross']),finance_lease_debt=None,
                 financial_period_end=q['financial_asof'],source_urls=urls(q),
                 share_count_billion=val(sh['current_outstanding_total']),share_date=sh['current_outstanding_total']['asof'],
                 share_basis='最新10-Q封面普通股总数，包含各普通股类别',diluted_shares_billion=val(sh['latest_quarter_weighted_diluted']),
                 cash_lease_principal=None)
    c['market_cap']=c['price']*c['share_count_billion']
    c['pe_ttm']=c['market_cap']/c['ttm_net_income']
    c['ps_ttm']=c['market_cap']/c['ttm_revenue']
    c['operating_margin']=c['ttm_op_income']/c['ttm_revenue']
    c['fcf']=c['cfo']-c['cash_capex']
    c['fcf_yield']=c['fcf']/c['market_cap']
    c['fcf_less_sbc']=None if c['sbc'] is None else c['fcf']-c['sbc']
    c['fcf_less_sbc_yield']=None if c['fcf_less_sbc'] is None else c['fcf_less_sbc']/c['market_cap']
    c['cash_capex_revenue_ratio']=c['cash_capex']/c['ttm_revenue']
    c['sbc_revenue_ratio']=None if c['sbc'] is None else c['sbc']/c['ttm_revenue']
    companies.append(c)

# Detailed operating forecasts for the four direct core-candidate holdings.
# These are deliberately explicit analyst hypotheses, NOT company guidance.
# Five explicitly decelerating revenue-growth assumptions, then a linear fade.
# Investment includes cash CapEx AND noncash finance-lease asset originations.
# Depreciation and CapEx refer to the same physical-asset scope; acquired
# intangible/content amortization stays in operating expenses as a conservative
# replacement-cost approximation. NVDA's cash CapEx also includes intangibles;
# its roughly $3bn PPE depreciation estimate is flagged in the source notes.
core_actuals={
 'GOOGL':{'ppe_depreciation':27.995,'finance_lease_additions':3.604},
 'MSFT':{'ppe_depreciation':38.300,'finance_lease_additions':20.653},
 'AMZN':{'ppe_depreciation':53.958,'finance_lease_additions':4.543},
 'NVDA':{'ppe_depreciation':2.972,'finance_lease_additions':None}
}
bridge={
 'GOOGL':{'cash_debt_securities':174.714,'listed_equity_assets':90.384,'other_investment_assets':135.230,
          'funded_debt':126.118,'finance_lease_debt':3.705,'preferred_claim':18.023},
 'MSFT':{'cash_debt_securities':60.509,'listed_equity_assets':0.0,'other_investment_assets':41.808,
         'funded_debt':35.481,'finance_lease_debt':70.973,'preferred_claim':0.0},
 'AMZN':{'cash_debt_securities':110.130,'listed_equity_assets':4.096,'other_investment_assets':289.900,
         'funded_debt':180.332,'finance_lease_debt':14.495,'preferred_claim':0.0},
 'NVDA':{'cash_debt_securities':56.586,'listed_equity_assets':42.783,'other_investment_assets':51.157,
         'funded_debt':33.366,'finance_lease_debt':0.0,'preferred_claim':0.0}
}
# Each tuple: EBIT margin Y5, EBIT margin Y10, WACC,
# terminal ROIC, total investment/revenue Y1...5, PPE depreciation/revenue Y1...5,
# terminal PPE depreciation/revenue, incremental operating working-capital rate.
# The last rate includes the minimum operating cash needs; it is not estimated
# from a single observed working-capital release.
driver_sets={
 'GOOGL':{
   'Conservative':(.27,.25,.115,.15,[.43,.42,.38,.34,.30],[.075,.09,.105,.115,.12],.12,.07),
   'Base':(.32,.30,.095,.20,[.41,.39,.35,.29,.24],[.075,.09,.105,.115,.12],.12,.05),
   'Optimistic':(.36,.34,.085,.25,[.39,.36,.31,.26,.22],[.075,.09,.105,.115,.12],.12,.04)},
 'MSFT':{
   'Conservative':(.37,.35,.11,.15,[.53,.52,.47,.42,.36],[.12,.14,.16,.17,.17],.16,.07),
   'Base':(.43,.40,.09,.20,[.50,.47,.42,.35,.29],[.12,.14,.16,.17,.17],.16,.05),
   'Optimistic':(.48,.45,.08,.25,[.46,.42,.38,.31,.26],[.12,.14,.16,.17,.17],.16,.04)},
 'AMZN':{
   'Conservative':(.10,.09,.12,.10,[.32,.31,.29,.26,.23],[.08,.10,.11,.12,.12],.10,.07),
   'Base':(.17,.18,.10,.15,[.28,.27,.25,.22,.19],[.08,.10,.11,.12,.12],.10,.05),
   'Optimistic':(.20,.22,.09,.20,[.26,.24,.22,.20,.18],[.08,.10,.11,.12,.12],.10,.04)},
 'NVDA':{
   'Conservative':(.40,.35,.13,.20,[.04,.04,.04,.04,.04],[.012,.014,.016,.018,.02],.02,.25),
   'Base':(.55,.45,.11,.35,[.035,.035,.035,.035,.035],[.012,.014,.016,.018,.02],.02,.20),
   'Optimistic':(.65,.55,.10,.50,[.03,.03,.03,.03,.03],[.012,.014,.016,.018,.02],.02,.15)}
}

# Front-loaded paths reflect that the latest reported run rate already exceeds
# some stale TTM starting levels. They are not fitted to the share price.
# Especially NVDA: Q2 FY27 revenue 96.221bn, Q3 guidance 108bn +/-2% (Aug26).
# The scenarios retain substantial uncertainty in deceleration and margins.
growth_paths={
 'GOOGL':{'Conservative':[.10,.08,.06,.05,.04],'Base':[.20,.17,.14,.12,.10],'Optimistic':[.28,.24,.20,.18,.15]},
 'MSFT':{'Conservative':[.10,.09,.08,.06,.05],'Base':[.20,.18,.16,.14,.12],'Optimistic':[.25,.23,.21,.19,.17]},
 'AMZN':{'Conservative':[.07,.06,.05,.04,.03],'Base':[.14,.12,.10,.08,.07],'Optimistic':[.20,.18,.16,.14,.12]},
 'NVDA':{'Conservative':[.20,.15,.10,.05,.03],'Base':[.45,.35,.25,.20,.15],'Optimistic':[.65,.50,.35,.25,.20]}
}

def assumptions(t,case,raw):
    m5,m10,wacc,troic,cap5,dep5,dep10,wc=raw
    c=next(x for x in companies if x['ticker']==t)
    tax=.22; terminal_growth=.03
    g5=growth_paths[t][case]
    growths=g5+[g5[-1]+(terminal_growth-g5[-1])*i/5 for i in range(1,6)]
    margins=[c['operating_margin']+(m5-c['operating_margin'])*i/5 for i in range(1,6)]+[m5+(m10-m5)*i/5 for i in range(1,6)]
    deps=dep5+[dep5[-1]+(dep10-dep5[-1])*i/5 for i in range(1,6)]
    # At steady state total net investment = NOPAT * g / ROIC. Align
    # year-10 asset investment with that identity, including delta NWC.
    terminal_capex_ratio=dep10+m10*(1-tax)*terminal_growth/troic-wc*terminal_growth/(1+terminal_growth)
    caps=cap5+[cap5[-1]+(terminal_capex_ratio-cap5[-1])*i/5 for i in range(1,6)]
    return {'revenue_growth':growths,'operating_margin':margins,'ppe_depreciation_ratio':deps,
            'asset_investment_ratio':caps,'tax_rate':tax,'working_capital_rate':wc,
            'discount_rate':wacc,'terminal_growth':terminal_growth,'terminal_roic':troic,
            'terminal_ppe_depreciation_ratio':dep10,'terminal_asset_investment_ratio':terminal_capex_ratio,
            'cash_reserve_revenue_ratio':{'Conservative':.05,'Base':.03,'Optimistic':.02}[case],
            'listed_investment_recovery':{'Conservative':.70,'Base':.85,'Optimistic':1.00}[case],
            'other_investment_recovery':{'Conservative':.35,'Base':.60,'Optimistic':.85}[case],
            'margin_year5':m5,'margin_year10':m10,'growth_first5':float(np.prod(1+np.array(g5))**.2-1)}

def run_dcf(c,bs,a):
    rows=[]; previous=c['ttm_revenue']
    for i in range(10):
        rev=previous*(1+a['revenue_growth'][i]); ebit=rev*a['operating_margin'][i]
        taxes=ebit*a['tax_rate']; nopat=ebit-taxes
        dep=rev*a['ppe_depreciation_ratio'][i]; investment=rev*a['asset_investment_ratio'][i]
        delta_wc=(rev-previous)*a['working_capital_rate']
        fcff=nopat+dep-investment-delta_wc
        df=(1+a['discount_rate'])**(i+1)
        rows.append({'year':i+1,'revenue':rev,'ebit':ebit,'cash_taxes':taxes,'nopat':nopat,
                     'ppe_depreciation':dep,'total_asset_investment':investment,
                     'delta_operating_working_capital':delta_wc,'fcff':fcff,
                     'discount_factor':1/df,'present_value_fcff':fcff/df})
        previous=rev
    terminal_nopat=rows[-1]['revenue']*(1+a['terminal_growth'])*a['margin_year10']*(1-a['tax_rate'])
    terminal_fcff=terminal_nopat*(1-a['terminal_growth']/a['terminal_roic'])
    terminal_value=terminal_fcff/(a['discount_rate']-a['terminal_growth'])
    pv_terminal=terminal_value/(1+a['discount_rate'])**10
    pv_period=sum(r['present_value_fcff'] for r in rows)
    operating_value=pv_period+pv_terminal
    reserve=c['ttm_revenue']*a['cash_reserve_revenue_ratio']
    valued_listed=bs['listed_equity_assets']*a['listed_investment_recovery']
    valued_other=bs['other_investment_assets']*a['other_investment_recovery']
    net_bridge=bs['cash_debt_securities']-reserve+valued_listed+valued_other-bs['funded_debt']-bs['finance_lease_debt']-bs['preferred_claim']
    equity_value=operating_value+net_bridge
    # Negative residual means this spending path needs financing/restructuring;
    # common stock's limited-liability value cannot be a negative stock price.
    common_value=max(0.0,equity_value)
    fair=common_value/c['share_count_billion']
    return {'forecast':rows,'pv_explicit_fcff':pv_period,'terminal_nopat':terminal_nopat,
            'terminal_fcff':terminal_fcff,'terminal_value':terminal_value,'pv_terminal':pv_terminal,
            'operating_value':operating_value,'terminal_share_of_operating_value':pv_terminal/operating_value,
            'operating_cash_reserve':reserve,'valued_listed_investments':valued_listed,
            'valued_other_investments':valued_other,'net_equity_bridge':net_bridge,
            'equity_value':equity_value,'common_equity_value_limited_liability':common_value,
            'needs_financing_or_restructuring':equity_value<0,'value_per_share':fair,'value_vs_price':fair/c['price']-1,
            'year10_to_terminal_fcff_growth':terminal_fcff/rows[-1]['fcff']-1,
            'sensitivity_using_quarter_diluted_shares':common_value/c['diluted_shares_billion']}

dcfs=[]
for t in ['GOOGL','NVDA','MSFT','AMZN']:
    c=next(x for x in companies if x['ticker']==t)
    a={case:assumptions(t,case,raw) for case,raw in driver_sets[t].items()}
    results={case:run_dcf(c,bridge[t],assum) for case,assum in a.items()}
    sensitivity=[]
    for delta in [-.01,0,.01]:
        test=dict(a['Base']);test['discount_rate']+=delta
        sensitivity.append({'wacc':test['discount_rate'],'value_per_share':run_dcf(c,bridge[t],test)['value_per_share']})
    # Reverse DCF is a separate one-variable experiment: constant first-five
    # growth, then fade to 3%, keeping the Base margin/investment ratios/WACC.
    # It is not an estimate of future growth and not the same path as Base.
    def price_residual(g):
        test=dict(a['Base']);test['revenue_growth']=[g]*5+[g+(test['terminal_growth']-g)*i/5 for i in range(1,6)]
        return run_dcf(c,bridge[t],test)['value_per_share']-c['price']
    implied=brentq(price_residual,-.01,1.5)
    def shape_residual(scale):
        test=dict(a['Base'])
        first=[(1+g)**scale-1 for g in test['revenue_growth'][:5]]
        test['revenue_growth']=first+[first[-1]+(test['terminal_growth']-first[-1])*i/5 for i in range(1,6)]
        return run_dcf(c,bridge[t],test)['value_per_share']-c['price']
    implied_scale=brentq(shape_residual,.01,5)
    implied_path=[(1+g)**implied_scale-1 for g in a['Base']['revenue_growth'][:5]]
    capex_sens=[]
    for delta in [-.05,0,.05]:
        test=dict(a['Base'])
        test['asset_investment_ratio']=[max(0,r+delta) if i<3 else r for i,r in enumerate(test['asset_investment_ratio'])]
        capex_sens.append({'year1_to_3_investment_ratio_change_pp':100*delta,'value_per_share':run_dcf(c,bridge[t],test)['value_per_share']})
    growth_sens=[]
    for terminal in [.02,.025,.03]:
        test=dict(a['Base']);test['terminal_growth']=terminal
        # For a one-variable perpetuity test keep the 10 forecast years intact.
        growth_sens.append({'terminal_growth':terminal,'value_per_share':run_dcf(c,bridge[t],test)['value_per_share']})
    dcfs.append({'ticker':t,'method':'FCFF: revenue × GAAP EBIT margin × (1−tax) + PPE depreciation − cash and finance-lease asset investment − incremental operating working capital',
                 'base_revenue':c['ttm_revenue'],'base_operating_margin':c['operating_margin'],
                 'shares':c['share_count_billion'],'bridge':bridge[t],'actuals':core_actuals[t],
                 'case_assumptions':a,'expected_results':results,'discount_sensitivity':sensitivity,
                 'terminal_growth_sensitivity_holding_explicit_years_fixed':growth_sens,
                 'early_capex_sensitivity':capex_sens,
                 'price_implied_constant_first5_growth_under_base_other_assumptions':implied,
                 'price_implied_decelerating_growth_scale':implied_scale,
                 'price_implied_decelerating_growth_first5':implied_path,
                 'price_implied_decelerating_growth_cagr':float(np.prod(1+np.array(implied_path))**.2-1)})

cor_tickers=['NVDA','GOOGL','MSFT','AMZN','TSM','AVGO','AMD','MU','META','VRT','PLTR','VTI','XLV','SGOV']
rets=adj.loc['2024-11-06':,cor_tickers].pct_change(fill_method=None).dropna()
model={
 'meta':{'asof':'2026-11-09','price_asof':'2026-11-06','currency':'USD',
         'financial_units':'USD billions; shares billions; per-share USD',
         'portfolio_total':5000,
         'method_notes':['估值使用11月6日收盘价和此前最新公开财报，股数/资产负债表日期与价格日期不同，市值为近似。',
                         'TTM由实际FY+当年YTD−上年YTD或完整财年构成，未将单季乘4。',
                         '简单P/E是市场价值/TTM普通股股东净利润；它可能包含非经营投资重估、税收利益及周期高点利润。',
                         '统一FCF=CFO−毛现金CapEx，未扣融资租赁本金、非现金新增租赁、收购和投资证券购买；TSM利息现金流分类另有差异。',
                         'FCF−SBC仅作经济成本敏感性，不是GAAP指标或严格FCFF。GAAP EBIT已经扣过SBC，DCF不重复扣。',
                         '未知披露值保留空白，不能解释为0。',
                         '公司筛选是当前已知存续公司样本，存在选择及幸存者偏差。历史组合风险不是未来上限。']},
 'companies':companies,
 'allocations':[{'name':k,'total':v['capital'],'weights':v['weights'],'metrics':{'five_year':v['five_year'],'two_year':v['two_year']}} for k,v in port['portfolio_results'].items()],
 'risk':{'correlation_tickers':cor_tickers,'correlation_matrix':rets.corr().values.tolist(),
         'period':['2024-11-06','2026-11-06'],'observations':len(rets),'return_frequency':'daily',
         'method':'split/dividend-adjusted simple daily returns; sample Pearson; no fill; 252 trading days annualization'},
 'portfolio_meta':port['meta'],'lookthrough':port['lookthrough_20260831'],
 'recommended_allocation':'valuation_plan_5000',
 'candidate_swaps':port['candidate_swaps_same_10pct'],
 'dcf':dcfs,
 'dcf_notes':[
    '四家公司详细估值为分析者条件情景，非市场共识、目标价、置信区间或收益保证；其他七家仅作会计筛选，未强行套用同一DCF。',
    '从最新TTM作为近似当前基数预测10年；未单独模拟财报日至估值日的短期stub，NVDA财报滞后更需留意。',
    'GAAP经营利润率保留SBC及费用化研发；不重复扣SBC。现有股份激励未逐笔做期权估值，股数固定是假设。',
    '税率统一22%为正常化情景假设，不等于各公司实际税率或税收建议。折现率为情景参数，未声称来自当前CAPM精确估计。',
    '未来资产投入包含现金CapEx及融资租赁新增资产；桥中扣现有融资租赁债务，FCFF不再扣未来租赁本金。经营租赁租金保留在利润率内，不另扣经营租赁负债。',
    'PPE折旧按收入比例建模，没有逐项固定资产折旧滚动表；终值强制满足再投资与g/ROIC关系，避免CapEx小于持续增长需求。',
    'AMZN中间情景Y1资产投入约255bn，略高于220bn当年现金CapEx指引，非把Q3高投入单季乘4；利润率假设升至18%，隐含AWS占比/运营效率改善，非公司预测。',
    'NVDA增长路径用最新季度与当时指引检查近端合理性，但仍是分析者减速情景；管理层8月指引不能保证11月后实现。',
    'Δ营运资金比例为增量资金占增量收入，包括最低运营现金需要；现金桥单独留出当前运营现金储备。',
    '投资资产兑现比例已合并体现估值、变现及潜在税负折价，不另把相同税费重复扣除；不是精确出售税模型。',
    'GOOGL18.023bn优先股以账面请求权近似扣除，不再同时增加假设转股股份；强制可转条款未逐条期权定价。',
    'MSFT把现金/短投中受限4bn移至其他投资池；AMZN仅加一次143.7bn私人股权和146.2bn可转债，不把总计再叠加。',
    'NVDA融资租赁新增投资及负债未单独核实，模型以不重大/0作近似假设，非事实性零余额；PPE折旧为D&A扣无形资产摊销的近似残差。',
    '11月初新增举债若现金留存，现金与债务同步增加，对净股权桥基本中性；未将融资现金单独加成财富。资产负债表不是完整滚动至11月6日的实时表。',
    '收购及少数股东权益等未单独全面预测；非经营资产账面值非11月6日逐项实时市值。承诺/担保不自动按最高敞口作为已借债扣除。'
 ]
}

if __name__=='__main__':
    (OUT/'consolidated_model.json').write_text(json.dumps(model,ensure_ascii=False,indent=2))
    keys=['ticker','price','market_cap','pe_ttm','ps_ttm','operating_margin','fcf','fcf_yield','fcf_less_sbc','fcf_less_sbc_yield','financial_period_end','share_date']
    df=pd.DataFrame(companies)
    df[keys].to_csv(OUT/'accounting_screen.csv',index=False)
    print(df[keys].round(4).to_string(index=False))
    print('\nDCF CONDITIONAL SCENARIOS')
    for d in dcfs:
        print(d['ticker'],{k:round(v['value_per_share'],2) for k,v in d['expected_results'].items()},
              'baseTV%',round(100*d['expected_results']['Base']['terminal_share_of_operating_value'],2),
              'impliedconstantgrowth%',round(100*d['price_implied_constant_first5_growth_under_base_other_assumptions'],2))
        print('Base cash flows', [round(r['fcff'],2) for r in d['expected_results']['Base']['forecast']])
    (OUT/'dcf_results.json').write_text(json.dumps(dcfs,ensure_ascii=False,indent=2))
