"""Static research figure from the reproducible portfolio return data."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
from matplotlib.font_manager import FontProperties

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs/ai_valuation'
OUT.mkdir(exist_ok=True,parents=True)
font=FontProperties(fname='/usr/local/share/fonts/NotoSansCJKsc-Regular.otf')
plt.rcParams.update({'font.family':font.get_name(),'axes.unicode_minus':False,
                     'font.size':11,'axes.spines.top':False,'axes.spines.right':False})
data=json.loads((ROOT/'ai_expansion_analysis/expansion_comparison.json').read_text())
returns=pd.read_csv(ROOT/'ai_expansion_analysis/expansion_portfolio_returns.csv',index_col=0,parse_dates=True)
prices=pd.read_csv(ROOT/'ai_expansion_analysis/adjusted_close.csv',index_col=0,parse_dates=True)
daily=prices.pct_change(fill_method=None).iloc[1:]
old='original_5000';new='valuation_plan_5000'
colors={old:'#98A5B1',new:'#087F8C'}
fig,(ax1,ax2)=plt.subplots(2,1,figsize=(12.8,8.2),gridspec_kw={'height_ratios':[1.15,1]},layout='constrained')
fig.suptitle('新增 GOOGL、降低集中度：历史风险改善有限',fontsize=19,fontweight='bold',x=.06,ha='left')
for key,label in [(old,'原组合'),(new,'更新后的目标组合')]:
    wealth=(1+returns[key]).cumprod()
    dd=wealth/wealth.cummax().clip(lower=1)-1
    ax1.plot(dd.index,dd,color=colors[key],label=label,linewidth=1.55)
    worst=dd.idxmin();ax1.scatter([worst],[dd.loc[worst]],color=colors[key],s=25,zorder=4)
    ax1.annotate(f'{dd.loc[worst]:.1%}',(worst,dd.loc[worst]),xytext=(10,-17 if key==old else 13),
                 textcoords='offset points',color=colors[key],fontweight='bold')
ax1.set_title('一、从此前高点回撤多少？',loc='left',fontsize=13,pad=10)
ax1.yaxis.set_major_formatter(PercentFormatter(1,decimals=0))
ax1.set_ylim(-.39,.025);ax1.grid(axis='y',alpha=.2)
ax1.legend(frameon=False,ncol=2,loc='lower right')
ax1.set_xlim(returns.index[0],returns.index[-1])
ax1.set_ylabel('累计净值的回撤')

tickers=['VTI','NVDA','MSFT','AMZN','GOOGL','XLV','SGOV']
x=np.arange(len(tickers));width=.36
for key,shift,label in [(old,-width/2,'原组合'),(new,width/2,'更新后的目标组合')]:
    w=pd.Series(data['portfolio_results'][key]['weights']).reindex(tickers,fill_value=0)
    covariance=daily[tickers].cov()*252
    risk=w*(covariance@w)/(w@covariance@w)
    bars=ax2.bar(x+shift,risk,width,label=label,color=colors[key])
    for bar,v in zip(bars,risk):
        ax2.annotate(f'{v:.1%}',(bar.get_x()+bar.get_width()/2,bar.get_height()),
                     ha='center',va='bottom',fontsize=9,xytext=(0,3),textcoords='offset points')
ax2.set_title('二、每项持仓贡献多少组合方差？',loc='left',fontsize=13,pad=10)
ax2.set_xticks(x,tickers);ax2.set_ylim(0,.49)
ax2.yaxis.set_major_formatter(PercentFormatter(1,decimals=0));ax2.grid(axis='y',alpha=.2)
ax2.set_ylabel('风险贡献比例')
ax2.set_xlabel('VTI 是宽基基金；其风险贡献分散在多家公司。此图不代表资金比例。',labelpad=12)
fig.supxlabel('样本：2021-11-05 至 2026-11-06。上图：季度再平衡、日收盘总回报、不含税费；下图：固定目标权重 × 全样本协方差。\n历史结果不构成未来回撤上限。数据：Yahoo Finance 复权价格；计算与情景设计：本次分析。',fontsize=9,color='#52616B',ha='left',x=.06)
fig.savefig(OUT/'portfolio_risk_review.png',dpi=180,facecolor='white')
print(str(OUT/'portfolio_risk_review.png'))
