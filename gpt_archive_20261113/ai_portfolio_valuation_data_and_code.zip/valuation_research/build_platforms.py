import json
from pathlib import Path

OUT = Path(__file__).parent
RAW = OUT / 'platform_raw'
ASOF = '2026-09-30'
CUTOFF = '2026-11-06'

SOURCES = {
 'GOOGL': {
  'annual': 'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000012/googexhibit991q42025.htm',
  'quarter': 'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000080/googexhibit991q32026.htm',
  'filing': 'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000084/goog-20260930.htm',
  'facts': 'https://data.sec.gov/api/xbrl/companyfacts/CIK0001652044.json',
  'release_dates': {'annual':'2026-02-04','quarter':'2026-10-28','filing':'2026-10-29'}},
 'MSFT': {
  'annual': 'https://www.microsoft.com/en-us/investor/earnings/fy-2026-q4/press-release-webcast',
  'quarter': 'https://www.microsoft.com/en-us/Investor/earnings/FY-2027-Q1/press-release-webcast',
  'filing': 'https://www.sec.gov/Archives/edgar/data/789019/000119312526436133/msft-20260930.htm',
  'facts': 'https://data.sec.gov/api/xbrl/companyfacts/CIK0000789019.json',
  'release_dates': {'annual':'2026-07-29','quarter':'2026-10-28','filing':'2026-10-28'}},
 'AMZN': {
  'annual': 'https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Fourth-Quarter-Results/default.aspx',
  'quarter': 'https://ir.aboutamazon.com/news-release/news-release-details/2026/Amazon-com-Announces-Third-Quarter-Results/',
  'filing': 'https://www.sec.gov/Archives/edgar/data/1018724/000101872426000040/amzn-20260930.htm',
  'facts': 'https://data.sec.gov/api/xbrl/companyfacts/CIK0001018724.json',
  'release_dates': {'annual':'2026-02-05','quarter':'2026-10-29','filing':'2026-10-30'}},
 'META': {
  'annual': 'https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Fourth-Quarter-and-Full-Year-2025-Results/',
  'quarter': 'https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/',
  'filing': 'https://www.sec.gov/Archives/edgar/data/1326801/000162828026066773/meta-20260930.htm',
  'facts': 'https://data.sec.gov/api/xbrl/companyfacts/CIK0001326801.json',
  'release_dates': {'annual':'2026-01-28','quarter':'2026-10-21','filing':'2026-10-22'}}
}

# Original figures are millions of USD, transcribed from official financial tables.
# Each vector is [most recent full fiscal year, current YTD, prior comparable YTD].
INPUTS = {
 'GOOGL': {
  'revenue':[402836,357269,289007], 'operating_income_gaap':[129039,121042,93105],
  'net_income_consolidated_gaap':[132170,201239,97715],
  'net_income_available_to_common_gaap':[132170,200855,97715],
  'operating_cash_flow':[164713,127149,112311], 'cash_capex_gross':[91447,131953,63596],
  'stock_based_compensation':[24953,23338,17882], 'other_income_expense_net':[29787,127478,26604],
  'income_before_tax':[158826,248520,119709], 'income_tax_expense':[26656,47281,21994],
  'depreciation_ppe':[21136,21955,15096],
  'net_gain_debt_equity_securities':[24620,126755,22266],
  'preferred_dividends':[0,384,0]},
 'MSFT': {
  'revenue':[331839,92279,77673], 'operating_income_gaap':[155237,45915,37961],
  'net_income_consolidated_gaap':[133749,36629,27747],
  'net_income_available_to_common_gaap':[133749,36629,27747],
  'operating_cash_flow':[182935,58000,45057], 'cash_capex_gross':[115948,39367,19394],
  'stock_based_compensation':[12405,3134,2983], 'other_income_expense_net':[10697,38,-3660],
  'income_before_tax':[165934,45953,34301], 'income_tax_expense':[32185,9324,6554],
  'depreciation_amortization_and_other':[38534,11744,8147],
  'net_recognized_gain_investments_derivatives':[11047,231,-3907]},
 'AMZN': {
  'revenue':[716924,584069,503538], 'operating_income_gaap':[79975,79389,54998],
  'net_income_consolidated_gaap':[77670,113587,56478],
  'net_income_available_to_common_gaap':[77670,113587,56478],
  'operating_cash_flow':[139514,113841,85055], 'cash_capex_gross':[131819,175670,92297],
  'ppe_sale_incentive_proceeds':[3499,3482,2446],
  'stock_based_compensation':[19467,15476,15070], 'other_income_expense_net':[15229,68359,14052]},
 'META': {
  'revenue':[200966,181712,141073], 'operating_income_gaap':[83276,54635,58531],
  'net_income_consolidated_gaap':[60458,52481,37690],
  'net_income_available_to_common_gaap':[60458,52481,37690],
  'operating_cash_flow':[115800,96873,79586], 'cash_capex_gross':[69691,83055,48308],
  'stock_based_compensation':[20427,21053,14537], 'other_income_expense_net':[2656,-1126,2047],
  'income_before_tax':[85932,53509,60578], 'income_tax_expense':[25474,1028,22888],
  'depreciation_amortization':[18616,19509,13205],
  'finance_lease_principal_payments':[2524,2769,1770]}
}

def metric(value, source_url, asof=ASOF, unit='USD_billion', **kwargs):
 return dict(value=value, unit=unit, asof=asof, source_url=source_url, **kwargs)

def manual(sym, m, src='quarter', **kwargs):
 return metric(None if m is None else round(m/1000,9), SOURCES[sym][src], **kwargs)

def facts_rows(sym, tag, unit='USD', namespace='us-gaap'):
 stem={'GOOGL':'goog','MSFT':'msft','AMZN':'amzn','META':'meta'}[sym]
 facts=json.loads((RAW/(stem+'_facts.json')).read_text())
 return facts['facts'].get(namespace,{}).get(tag,{}).get('units',{}).get(unit,[])

def fact(sym, tag, start=None, end=ASOF, unit='USD', namespace='us-gaap'):
 rows=[r for r in facts_rows(sym,tag,unit,namespace) if r['end']==end and r.get('start')==start and r.get('filed','9999')<=CUTOFF]
 if not rows:
  return metric(None,SOURCES[sym]['facts'],asof=end,unit='shares_billion' if unit=='shares' else 'USD_billion',xbrl_tag=namespace+':'+tag,notes='No exact-date fact verified as of cutoff.')
 r=sorted(rows,key=lambda r:r['filed'])[-1]
 return metric(r['val']/1e9,SOURCES[sym]['facts'],asof=end,unit='shares_billion' if unit=='shares' else 'USD_billion',xbrl_tag=namespace+':'+tag,period_start=start,accession=r['accn'],filed=r['filed'],filing_url=SOURCES[sym]['filing'] if end==ASOF else None)

data={'data_cutoff':CUTOFF,'financial_period_end':ASOF,'ttm_period_start':'2025-10-01',
      'currency':'USD','financial_unit':'billion','share_unit':'billion',
      'method':'Actual reported FY + current YTD - prior comparable YTD; never annualized newest quarter. Cash CapEx shown as positive cash outflows. Latest diluted shares are quarter-weighted averages, not period-end outstanding.',
      'companies':{}}

for sym, metrics in INPUTS.items():
 periods=[('2025-01-01','2025-12-31'),('2026-01-01','2026-09-30'),('2025-01-01','2025-09-30')]
 if sym=='MSFT': periods=[('2025-07-01','2026-06-30'),('2026-07-01','2026-09-30'),('2025-07-01','2025-09-30')]
 c={'sources':SOURCES[sym],'ttm':{},'latest_balance_sheet':{},'latest_quarter':{},'accounting_notes':[]}
 for name, vals in metrics.items():
  terms=[]
  for i,(v,(start,end)) in enumerate(zip(vals,periods)):
   source='annual' if i==0 else 'quarter'
   terms.append(metric(v/1000,SOURCES[sym][source],asof=end,period_start=start,reported_value=v,reported_unit='USD_million',operator='-' if i==2 else '+',published=SOURCES[sym]['release_dates'][source]))
  c['ttm'][name]=metric(round((vals[0]+vals[1]-vals[2])/1000,9),[SOURCES[sym]['annual'],SOURCES[sym]['quarter']],period_start='2025-10-01',method='FY + current YTD - prior YTD',formula=f'{vals[0]/1000} + {vals[1]/1000} - {vals[2]/1000}',components=terms)
 if 'finance_lease_principal_payments' not in c['ttm']:
  if sym in ['GOOGL','MSFT']:
   terms=[fact(sym,'FinanceLeasePrincipalPayments',start=a,end=b) for a,b in periods]
   if all(x['value'] is not None for x in terms):
    vals=[x['value'] for x in terms]
    c['ttm']['finance_lease_principal_payments']=metric(round(vals[0]+vals[1]-vals[2],9),SOURCES[sym]['facts'],period_start='2025-10-01',method='FY + current YTD - prior YTD',formula=f'{vals[0]} + {vals[1]} - {vals[2]}',components=terms)
  elif sym=='AMZN':
   c['ttm']['finance_lease_principal_payments']=manual(sym,1681,period_start='2025-10-01',method='Direct reported trailing twelve months')
 cfo=c['ttm']['operating_cash_flow']['value'];capex=c['ttm']['cash_capex_gross']['value'];lp=c['ttm']['finance_lease_principal_payments']['value']
 c['ttm']['free_cash_flow_gross_cash_capex']=metric(round(cfo-capex,9),c['ttm']['operating_cash_flow']['source_url'],period_start='2025-10-01',formula='operating_cash_flow - cash_capex_gross',notes='Before finance-lease principal payments, before acquisitions and securities investments.')
 c['ttm']['free_cash_flow_gross_cash_capex_after_finance_lease_principal']=metric(round(cfo-capex-lp,9),c['ttm']['operating_cash_flow']['source_url'],period_start='2025-10-01',formula='operating_cash_flow - cash_capex_gross - finance_lease_principal_payments')
 if sym=='AMZN':
  netcapex=round(capex-c['ttm']['ppe_sale_incentive_proceeds']['value'],9)
  c['ttm']['cash_capex_net_of_ppe_sales_incentives']=metric(netcapex,SOURCES[sym]['quarter'],period_start='2025-10-01',formula='cash_capex_gross - ppe_sale_incentive_proceeds',direct_reported_cross_check=210.657)
  c['ttm']['company_reported_free_cash_flow']=manual(sym,-42357,period_start='2025-10-01',formula='CFO - cash_capex_net_of_ppe_sales_incentives',notes='Company definition excludes finance-lease principal payments; differs from gross-CapEx definition used for comparison.')
 elif sym=='META':
  c['ttm']['company_reported_free_cash_flow']=metric(round(cfo-capex-lp,9),[SOURCES[sym]['annual'],SOURCES[sym]['quarter']],period_start='2025-10-01',formula='CFO - cash_capex_gross - finance_lease_principal_payments')
 elif sym=='GOOGL':
  c['ttm']['company_reported_free_cash_flow']=metric(round(cfo-capex,9),SOURCES[sym]['quarter'],period_start='2025-10-01',formula='CFO - cash_capex_gross',notes='Excludes finance-lease principal payments and acquisitions.')
 c['ttm']['cash_capex_gross']['notes']='Cash payments for PPE/additions to PPE; excludes noncash assets initially obtained through finance leases and excludes acquisitions. For Amazon, gross before PPE sale/incentive proceeds.'
 data['companies'][sym]=c

balances={
 'GOOGL':{'cash_equivalents':56334,'short_term_marketable_investments':208764,'cash_plus_short_term_investments':265098,'nonmarketable_investments':135230,'marketable_equity_securities':90384,'marketable_debt_securities':118380,'common_shares_outstanding':12294,'preferred_equity_carrying_value':18023},
 'MSFT':{'cash_equivalents':20281,'short_term_marketable_investments':44228,'cash_plus_short_term_investments':64509,'equity_and_other_investments_noncurrent':37808,'common_shares_outstanding':7427},
 'AMZN':{'cash_equivalents':55783,'short_term_marketable_investments':58443,'cash_plus_short_term_investments':114226,'common_shares_outstanding':10811,'preferred_equity_carrying_value':0},
 'META':{'cash_equivalents':11222,'short_term_marketable_investments':71227,'cash_plus_short_term_investments':82449,'nonmarketable_equity_investments':32624,'common_shares_outstanding':2556}}

for sym, fields in balances.items():
 c=data['companies'][sym];b=c['latest_balance_sheet']
 for name,v in fields.items():
  b[name]=manual(sym,v,src='filing' if name in ['marketable_equity_securities','marketable_debt_securities'] or (sym=='META' and name=='common_shares_outstanding') else 'quarter',unit='shares_billion' if name=='common_shares_outstanding' else 'USD_billion')
 for name,tag in [('long_term_debt_current','LongTermDebtCurrent'),('long_term_debt_noncurrent','LongTermDebtNoncurrent'),('finance_lease_liabilities','FinanceLeaseLiability')]:
  b[name]=fact(sym,tag)
 if sym=='AMZN':b['short_term_borrowings']=fact(sym,'ShortTermBorrowings')
 elif sym=='GOOGL':b['short_term_borrowings']=fact(sym,'CommercialPaper')
 else:b['short_term_borrowings']=metric(None,SOURCES[sym]['filing'],notes='No separate short-term borrowings line verified; total below contains only separately verified funded-debt categories.')
 debt=round(b['long_term_debt_current']['value']+b['long_term_debt_noncurrent']['value']+(b['short_term_borrowings']['value'] or 0),9)
 b['interest_bearing_debt_excluding_leases']=metric(debt,SOURCES[sym]['filing'],formula='current portion of long-term debt + noncurrent debt + separately verified short-term borrowings',notes='Debt carrying values, excluding operating/finance leases and preferred equity; do not substitute gross face value.')
 if b['finance_lease_liabilities']['value'] is None and sym=='AMZN':
  terms=[fact(sym,'FinanceLeaseLiabilityCurrent'),fact(sym,'FinanceLeaseLiabilityNoncurrent')]
  b['finance_lease_liabilities']=metric(round(sum(t['value'] for t in terms),9),SOURCES[sym]['facts'],components=terms)
 b['cash_plus_marketable_less_funded_debt']=metric(round(b['cash_plus_short_term_investments']['value']-debt,9),[SOURCES[sym]['quarter'],SOURCES[sym]['filing']],formula='cash_plus_short_term_investments - interest_bearing_debt_excluding_leases',notes='Accounting bridge only, not all risk-free cash. Excludes finance leases, preferred equity, noncurrent investments and tax effects.')

quarters={
 'GOOGL':{'revenue':127577,'operating_income_gaap':40576,'net_income_available_to_common_gaap':26170,'operating_cash_flow':42290,'cash_capex_gross':51355,'weighted_average_diluted_shares':12368,'weighted_average_basic_shares':12256},
 'MSFT':{'revenue':92279,'operating_income_gaap':45915,'net_income_available_to_common_gaap':36629,'operating_cash_flow':58000,'cash_capex_gross':39367,'weighted_average_diluted_shares':7446,'weighted_average_basic_shares':7426},
 'AMZN':{'revenue':201944,'operating_income_gaap':28076,'net_income_available_to_common_gaap':20685,'operating_cash_flow':42422,'cash_capex_gross':77259,'weighted_average_diluted_shares':10929,'weighted_average_basic_shares':10797},
 'META':{'revenue':64601,'operating_income_gaap':12988,'net_income_available_to_common_gaap':9860,'operating_cash_flow':32786,'cash_capex_gross':33942,'weighted_average_diluted_shares':2573,'weighted_average_basic_shares':2552}}
for sym,fields in quarters.items():
 for name,v in fields.items():
  data['companies'][sym]['latest_quarter'][name]=manual(sym,v,period_start='2026-07-01',unit='shares_billion' if 'shares' in name else 'USD_billion')

g=data['companies']['GOOGL'];a=data['companies']['AMZN'];m=data['companies']['META'];s=data['companies']['MSFT']
g['latest_balance_sheet']['cash_plus_marketable_less_market_equity']=metric(174.714,SOURCES['GOOGL']['filing'],formula='265.098 - 90.384',notes='Cash plus marketable debt; marketable debt still has duration/credit risk, so not identical to cash.')
g['latest_balance_sheet']['marketable_equity_securities']['notes']='Includes USD75.2bn SpaceX shares with short-term sale restrictions. Not risk-free cash.'
g['latest_balance_sheet']['common_shares_outstanding']['classes']={'A':5.888,'B':0.828,'C':5.578}
m['latest_balance_sheet']['common_shares_outstanding']['classes']={'A':2.214,'B':0.342}
m['latest_balance_sheet']['common_shares_outstanding']['notes']='Quarter-end rounded millions, Class A + Class B. Does not reflect subsequent common/preferred financing announced in October.'
m['latest_balance_sheet']['common_shares_latest_cover_date']=metric(2.556241253,SOURCES['META']['filing'],asof='2026-10-16',unit='shares_billion',components={'Class_A':2.214472367,'Class_B':0.341768886})
s['latest_balance_sheet']['common_shares_latest_cover_date']=fact('MSFT','EntityCommonStockSharesOutstanding',end='2026-10-22',unit='shares',namespace='dei')
a['latest_balance_sheet']['common_shares_latest_cover_date']=fact('AMZN','EntityCommonStockSharesOutstanding',end='2026-10-21',unit='shares',namespace='dei')

g['accounting_notes']=[
 {'finding':'GAAP net income is not a clean operating earnings proxy. 9M2026 other income is USD127.478bn; equity securities gains USD127.282bn include USD116.316bn unrealized net gains from nonmarketable measurement-alternative investments, USD9.377bn unrealized gains from marketable/other equities, and USD1.589bn realized gains. Cash-flow statement removes net debt/equity securities gains USD126.755bn.', 'source_url':SOURCES['GOOGL']['filing'],'asof':ASOF},
 {'finding':'Latest quarter reverses some markups: equity losses USD8.664bn, largely marketable SpaceX loss, reduced net income by approximately USD6.7bn. Gains should not be capitalized as recurring search/cloud earnings. Nonmarketable assets need an independent haircut/tax-adjusted bridge rather than automatic book-value addition.','source_url':SOURCES['GOOGL']['filing'],'asof':ASOF},
 {'finding':'USD18.023bn mandatory convertible preferred equity carrying value and USD0.384bn YTD preferred dividends exist. Common-stock value/EV bridge must treat preferred conversion and dilution consistently.','source_url':SOURCES['GOOGL']['quarter'],'asof':ASOF},
 {'finding':'TTM cash FCF USD19.747bn is much lower than GAAP common net income USD235.310bn. It is affected by rapid infrastructure CapEx; cannot equate depressed current FCF with permanent earning power or disregard investment spending.','source_url':[SOURCES['GOOGL']['annual'],SOURCES['GOOGL']['quarter']],'asof':ASOF}]
a['accounting_notes']=[
 {'finding':'9M2026 other income USD68.359bn is dominated by investment revaluation. Anthropic nonvoting preferred-stock upward adjustments were approximately USD62.8bn; convertible notes conversions also reclassify OCI gains into net income. TTM GAAP net income is not a clean retail/AWS earnings proxy.','source_url':SOURCES['AMZN']['filing'],'asof':ASOF},
 {'finding':'September carrying values: Anthropic nonvoting preferred approximately USD92.5bn, Anthropic convertible notes approximately USD146.2bn; OpenAI preferred USD50.0bn; total private equity investments not equity-method USD143.7bn. These are largely outside current cash/marketables, with valuation and sale restrictions.','source_url':SOURCES['AMZN']['filing'],'asof':ASOF},
 {'finding':'Company FCF subtracts PPE spending net of proceeds/incentives. For uniform gross-cash comparison subtract USD215.192bn, yielding FCF -USD46.892bn, compared with company -USD42.357bn. Finance leases, acquisitions, and equity investments remain additional claims.','source_url':SOURCES['AMZN']['quarter'],'asof':ASOF}]
s['accounting_notes']=[
 {'finding':'TTM net recognized investment/derivative gains add USD15.185bn to GAAP income before tax. FY2026 press release identifies OpenAI impacts and a USD3.2bn Anthropic gain in Q4; management non-GAAP OpenAI exclusion does not necessarily remove all investment gains.','source_url':SOURCES['MSFT']['annual'],'asof':ASOF},
 {'finding':'Cash PPE spending excludes noncash finance-lease additions. Latest finance lease liability is USD70.973bn, material relative to USD35.481bn funded debt. Keep lease treatment consistent between EBIT, FCF, and EV.','source_url':SOURCES['MSFT']['filing'],'asof':ASOF}]
m['accounting_notes']=[
 {'finding':'Q1 2026 recorded USD8.03bn income-tax benefit, partially offsetting Q3 2025 USD15.93bn noncash tax charge. The older charge has rolled out of this TTM but the benefit remains; TTM effective tax rate is therefore not a sustainable normalized rate.','source_url':'https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-First-Quarter-2026-Results/','asof':'2026-03-31'},
 {'finding':'Q3 2026 includes approximately USD9.89bn litigation expense from U.S. state attorneys general teen mental-health agreement. It reduces GAAP EBIT and net income. A normalized scenario may show it separately, but cash liability and recurring legal risk cannot simply be erased.','source_url':SOURCES['META']['quarter'],'asof':ASOF},
 {'finding':'Company FCF includes finance-lease principal. Generic CFO minus cash PPE FCF USD28.649bn differs from company-method USD25.126bn. Latest 10-Q states USD355.73bn future operating/finance leases not yet commenced, but these are contractual commitments over many years, not all current funded debt.','source_url':SOURCES['META']['filing'],'asof':ASOF}]

for sym,c in data['companies'].items():
 t=c['ttm']
 t['operating_margin']=metric(round(t['operating_income_gaap']['value']/t['revenue']['value'],9),t['revenue']['source_url'],unit='ratio',formula='operating_income_gaap/revenue')
 if 'income_tax_expense' in t:
  t['reported_effective_tax_rate']=metric(round(t['income_tax_expense']['value']/t['income_before_tax']['value'],9),t['income_tax_expense']['source_url'],unit='ratio',formula='income_tax_expense/income_before_tax',notes='Reported rate, not recommended normalized tax rate.')

(OUT/'platforms.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
for sym,c in data['companies'].items():
 print(sym,{k:v['value'] for k,v in c['ttm'].items() if k in ['revenue','operating_income_gaap','net_income_available_to_common_gaap','operating_cash_flow','cash_capex_gross','stock_based_compensation','free_cash_flow_gross_cash_capex','finance_lease_principal_payments']})
 print('BALANCE',{k:v['value'] for k,v in c['latest_balance_sheet'].items() if k in ['cash_plus_short_term_investments','interest_bearing_debt_excluding_leases','finance_lease_liabilities','common_shares_outstanding']})
print('SAVED',OUT/'platforms.json')
