import json
from pathlib import Path

ROOT = Path(__file__).parent
ASOF = '2026-11-06'
CASES = {
    'NVDA': dict(cik='0001045810', fy=('2025-01-27','2026-01-25'), ytd=('2026-01-26','2026-07-26'), prior=('2025-01-27','2025-07-27'), q=('2026-04-27','2026-07-26'), release='2026-08-26', revenue='Revenues', net='NetIncomeLoss', capex='PaymentsToAcquireProductiveAssets', url='https://www.sec.gov/Archives/edgar/data/1045810/000104581026000075/nvda-20260726.htm', ref='turn36view0'),
    'AVGO': dict(cik='0001730168', fy=('2024-11-04','2025-11-02'), ytd=('2025-11-03','2026-08-02'), prior=('2024-11-04','2025-08-03'), q=('2026-05-04','2026-08-02'), release='2026-09-02', revenue='RevenueFromContractWithCustomerExcludingAssessedTax', net='ProfitLoss', capex='PaymentsToAcquirePropertyPlantAndEquipment', url='https://www.sec.gov/Archives/edgar/data/1730168/000173016826000080/avgo-20260802.htm', ref='turn41view0'),
    'AMD': dict(cik='0000002488', fy=('2024-12-29','2025-12-27'), ytd=('2025-12-28','2026-09-26'), prior=('2024-12-29','2025-09-27'), q=('2026-06-28','2026-09-26'), release='2026-11-03', revenue='RevenueFromContractWithCustomerExcludingAssessedTax', net='NetIncomeLoss', capex='PaymentsToAcquirePropertyPlantAndEquipment', url='https://www.sec.gov/Archives/edgar/data/2488/000000248826000191/amd-20260926.htm', ref='turn41view1'),
    'MU': dict(cik='0000723125', fy=('2025-08-29','2026-09-03'), ytd=None, prior=None, q=('2026-05-29','2026-09-03'), release='2026-09-30', revenue='RevenueFromContractWithCustomerExcludingAssessedTax', net='NetIncomeLoss', capex='PaymentsToAcquirePropertyPlantAndEquipment', url='https://www.sec.gov/Archives/edgar/data/723125/000072312526000023/mu-20260903.htm', ref='turn36view1'),
}
DATA = {s: json.loads((ROOT/'raw'/f'{s}_companyfacts.json').read_text()) for s in CASES}

def observation(s, tag, period=None, end=None, unit='USD', namespace='us-gaap'):
    obs = DATA[s]['facts'].get(namespace,{}).get(tag,{}).get('units',{}).get(unit,[])
    matches = [x for x in obs if x['filed'] <= ASOF and (period is None or (x.get('start'),x['end'])==period) and (end is None or x['end']==end)]
    if not matches:
        return None
    x = max(matches,key=lambda x:(x['filed'],x['end']))
    return {**x, 'unit': unit, 'taxonomy_tag': namespace+':'+tag, 'value_billions': x['val']/1e9, 'source_url': f'https://data.sec.gov/api/xbrl/companyfacts/CIK{CASES[s]["cik"]}.json', 'filing_index_url': f'https://www.sec.gov/Archives/edgar/data/{int(CASES[s]["cik"])}/{x["accn"].replace("-", "")}/{x["accn"]}-index.html'}

def flow(s, tag):
    c = CASES[s]
    periods = [('FY',c['fy'],1)] if c['ytd'] is None else [('FY',c['fy'],1),('current_YTD',c['ytd'],1),('prior_YTD',c['prior'],-1)]
    parts = [{**observation(s,tag,period=p), 'role': role, 'coefficient': coef} for role,p,coef in periods]
    value = sum(x['val']*x['coefficient'] for x in parts)/1e9
    formula = ' '.join(('+' if x['coefficient']>0 and i else '-' if x['coefficient']<0 else '')+' '+str(x['value_billions']) for i,x in enumerate(parts)).strip()
    return {'value_usd_billions': round(value,9), 'formula_usd_billions': formula, 'method': 'latest full fiscal year; 53 weeks' if s=='MU' else 'FY + current YTD - prior YTD', 'constituents': parts}

def balance(s,tag,namespace='us-gaap',unit='USD',end=None):
    c=CASES[s]
    if end is None: end=(c['ytd'] or c['fy'])[1]
    x=observation(s,tag,end=end,namespace=namespace,unit=unit)
    return {'value_usd_billions' if unit=='USD' else 'value_shares_billions': x['value_billions'] if x else None, 'asof':end, 'evidence':x}

def manual(value, asof, url, **kw):
    return dict(value_usd_billions=value,asof=asof,source_url=url,**kw)

out={'asof_information_cutoff':ASOF,'retrieval_date':'2026-11-09','units':'USD billions; shares in billions unless explicitly TWD. Positive cash capex means cash outflow.','methodology':[
    'Only observations filed on or before 2026-11-06 were used. TTM is actual FY plus current YTD less prior YTD, or the latest complete fiscal year; no quarter is annualized.',
    'Cash-flow-derived FCF is CFO minus gross cash capex. It is a useful accounting proxy, not automatically FCFF or FCFE. Acquisitions, financial investments, and noncash lease additions are not cash PPE capex.',
    'SBC is the cash-flow statement add-back. FCF less SBC is a sensitivity proxy, not GAAP cash flow. Do not simultaneously deduct all SBC and model the same dilution again.',
    'Debt carrying amounts, principal values, finance leases, and operating leases are distinguished where available. Null means not established, not zero.',
    'Period-end ordinary shares, cover-date ordinary shares and latest-quarter diluted weighted shares have different dates and uses. Do not label earnings divided by current shares as GAAP TTM EPS.',
], 'companies':{}}
for s,c in CASES.items():
    end=(c['ytd'] or c['fy'])[1]
    metrics={name:flow(s,tag) for name,tag in {'revenue':c['revenue'],'operating_income_gaap':'OperatingIncomeLoss','net_income_attributable_to_parent_gaap':c['net'],'cfo':'NetCashProvidedByUsedInOperatingActivities','cash_capex_gross':c['capex'],'sbc_cashflow_addback':'ShareBasedCompensation'}.items()}
    fcf=metrics['cfo']['value_usd_billions']-metrics['cash_capex_gross']['value_usd_billions']
    metrics['fcf_cfo_minus_gross_cash_capex']={'value_usd_billions':round(fcf,9),'formula':'cfo - cash_capex_gross'}
    metrics['fcf_less_sbc_sensitivity']={'value_usd_billions':round(fcf-metrics['sbc_cashflow_addback']['value_usd_billions'],9),'formula':'cfo - cash_capex_gross - sbc_cashflow_addback','not_gaap':True}
    qshares=observation(s,'WeightedAverageNumberOfDilutedSharesOutstanding',period=c['q'],unit='shares')
    covers=DATA[s]['facts']['dei']['EntityCommonStockSharesOutstanding']['units']['shares']
    cover=max([x for x in covers if x['filed']<=ASOF],key=lambda x:(x['end'],x['filed']))
    co={'accounting_standard':'US GAAP','latest_period_end':end,'latest_earnings_publication_date':c['release'],'latest_report_url':c['url'],'web_source_ref':c['ref'],'ttm':metrics,'balance':{'cash_and_equivalents':balance(s,'CashAndCashEquivalentsAtCarryingValue')},'shares':{'period_end_common':balance(s,'CommonStockSharesOutstanding',unit='shares'),'latest_quarter_diluted_weighted_average':{'value_shares_billions':qshares['value_billions'] if qshares else None,'period':list(c['q']),'evidence':qshares},'cover_common':{'value_shares_billions':cover['val']/1e9,'asof':cover['end'],'filed':cover['filed'],'source_url':c['url']},'latest_fiscal_year_diluted_weighted_average':{'value_shares_billions':observation(s,'WeightedAverageNumberOfDilutedSharesOutstanding',period=c['fy'],unit='shares')['value_billions'],'period':list(c['fy'])}},'notes':[]}
    if s=='NVDA':
        co['capex_definition']='Gross cash purchases related to PPE and intangible assets, before asset disposals, excluding acquisitions, investments, unpaid capex and noncash lease additions.'
        co['balance'].update({'current_marketable_debt_securities':balance(s,'DebtSecuritiesCurrent'),'current_marketable_equity_securities':balance(s,'EquitySecuritiesFvNi'),'cash_plus_current_debt_securities':manual(56.586,end,c['url'],formula='22.443 + 34.143'),'cash_plus_all_current_marketable_investments':manual(99.369,end,c['url'],formula='22.443 + 34.143 + 42.783'),'interest_bearing_debt_carrying':balance(s,'LongTermDebt'),'debt_current':balance(s,'LongTermDebtCurrent'),'debt_noncurrent':balance(s,'LongTermDebtNoncurrent'),'operating_lease_liabilities':balance(s,'OperatingLeaseLiability'),'finance_lease_liabilities':manual(None,end,c['url']),'nonmarketable_equity_securities':balance(s,'EquitySecuritiesWithoutReadilyDeterminableFairValueAmount')})
        co['shares']['period_end_common']={'value_shares_billions':24.147,'asof':end,'source_url':c['url'],'location':'Condensed consolidated statements of shareholders equity; balances as of Jul 26 2026; 24,147 million.'}
        co['notes'] += ['Current marketable equity securities are risk assets, not equivalent to cash. Cash plus debt securities is 56.586; adding current equities yields 99.369. Nonmarketable investments are excluded from both.', 'H1 FY2027 other income net is 24.140 versus 3.039 in prior H1. GAAP net income contains investment gains. Use operating income or normalized earnings for valuation; no earnings normalization is imposed here.', 'H1 FY2027 CFO 74.421 is well below H1 net income 118.010. The filing discusses receivables/extended payment terms and noncash investment gains; do not assume accrual earnings convert one-for-one to cash.']
    elif s=='AVGO':
        co['capex_definition']='Gross cash purchases of PPE; excludes financial investments, acquisitions and any noncash lease additions.'
        co['balance'].update({'short_term_investments_separately_established':manual(None,end,c['url']),'cash_plus_short_term_investments':manual(None,end,c['url'],note='Short-term investments are not separately quantified in the reviewed balance sheet. Do not infer zero from absence of a separate line.'),'disclosed_cash_liquidity_minimum':manual(23.975,end,c['url']),'interest_bearing_debt_carrying':balance(s,'LongTermDebt'),'interest_bearing_debt_principal':manual(61.079,end,c['url'],location='Note 6 Borrowings; debt principal 61,079m less unamortized discounts and issuance costs 1,660m = carrying amount 59,419m.'),'debt_current':balance(s,'LongTermDebtCurrent'),'debt_noncurrent':balance(s,'LongTermDebtNoncurrent'),'finance_lease_liabilities':manual(None,end,c['url'])})
        co['notes'] += ['ProfitLoss is the consolidated net income reported for common shareholders; no separate NCI attribution appears in the latest income statement.', 'The filing identifies 23.975 of cash and equivalents as primary balance-sheet liquidity; purchases of short-term investments appear in cash flows, but an additional current investment balance was not separately established. Use cash-only conservatively if needed, with this limitation.', 'SBC TTM 8.482 is material. Gross FCF and SBC-adjusted cash-flow sensitivity are both supplied; they answer different questions.']
    elif s=='AMD':
        co['capex_definition']='Gross cash purchases of PPE; unpaid capex and noncash lease additions are excluded.'
        co['balance'].update({'short_term_investments':balance(s,'ShortTermInvestments'),'cash_plus_short_term_investments':manual(15.776,end,c['url'],formula='7.404 + 8.372'),'interest_bearing_debt_carrying':manual(7.079,end,c['url'],formula='current debt 0 + noncurrent 7.079'),'debt_current':balance(s,'LongTermDebtCurrent'),'debt_noncurrent':balance(s,'LongTermDebtNoncurrent'),'finance_lease_liabilities':manual(None,end,c['url'])})
        co['notes'] += ['GAAP net income includes tax and nonoperating items; Q3 2026 has a 0.555 tax benefit. Raw GAAP P/E should be read with the reconciliation and operating margins.']
    elif s=='MU':
        release='https://micron.gcs-web.com/node/50991'
        co['capex_definition']='Gross cash expenditures for PPE = 30.712. Company net capex deducts PPE sale proceeds 0.029 and government incentives 3.316, producing 27.367. Gross cash capex excludes new noncash finance leases and finance-lease principal repayments.'
        co['ttm']['cash_capex_company_net']={'value_usd_billions':27.367,'formula_usd_billions':'30.712 - 0.029 - 3.316','source_url':release,'source_ref':'turn51view3','asof':end}
        co['ttm']['company_adjusted_free_cash_flow']={'value_usd_billions':62.308,'formula_usd_billions':'89.675 - 27.367','source_url':release,'asof':end}
        co['balance'].update({'short_term_investments':balance(s,'AvailableForSaleSecuritiesDebtSecuritiesCurrent'),'cash_plus_short_term_investments':manual(43.434,end,c['url'],formula='38.364 + 5.070'),'long_term_marketable_debt_investments':balance(s,'AvailableForSaleSecuritiesDebtSecuritiesNoncurrent'),'cash_plus_short_and_long_term_marketable_investments':manual(73.453,end,c['url'],formula='38.364 + 5.070 + 30.019',note='Excludes restricted cash and nonmarketable equity investments.'),'interest_bearing_notes_carrying_excluding_finance_leases':balance(s,'LongTermDebt'),'interest_bearing_debt_carrying_including_finance_leases':manual(5.179,end,c['url'],formula='notes 2.792 + finance leases 2.387 = current 0.491 + noncurrent 4.688'),'notes_principal_excluding_finance_leases':manual(2.808,end,c['url']),'debt_current_including_finance_leases':balance(s,'DebtCurrent'),'debt_noncurrent_including_finance_leases':balance(s,'LongTermDebtAndCapitalLeaseObligations'),'finance_lease_liabilities':balance(s,'FinanceLeaseLiability')})
        co['shares']['latest_quarter_diluted_weighted_average']={'value_shares_billions':1.147,'period':list(c['q']),'source_url':release,'source_ref':'turn51view0','location':'FY26 release, consolidated operations, Q4 diluted shares 1,147 million.'}
        co['notes'] += ['Latest complete fiscal year contains 53 weeks; all FY figures are actual reported values, not quarter annualizations.', 'The LongTermDebt tag 2.792 excludes finance leases; balance-sheet long-term debt 4.688 includes noncurrent finance leases. Current debt 0.491 is all current finance lease liability. Total including finance leases is 5.179.', 'FY2026 operating margin 74.6% is exceptionally high versus FY2025 26.1%; 10-K attributes sales growth to major ASP increases as well as bit growth. Normalize the cycle when valuing; no extrapolation of peak margins is assumed here.', 'Headline liquidity 73.48 includes long-term marketable investments and restricted cash; it is not the cash-plus-short-term-investments figure 43.434.']
    co['summary_usd_billions']={k:v['value_usd_billions'] for k,v in co['ttm'].items()}
    out['companies'][s]=co

tsm_q3='https://investor.tsmc.com/english/encrypt/files/encrypt_file/qr/phase4_reports/2026-10/e18db1d00f041c8d37a90dedbcb150518d8277d9/FS.pdf'
tsm_q4='https://investor.tsmc.com/english/encrypt/files/encrypt_file/reports/2026-02/cb73d5f4e019a8f6d7a494a0f8f6c6da2dfc4ee2/FS.pdf'
tsm_mgmt='https://investor.tsmc.com/english/encrypt/files/encrypt_file/reports/2026-10/f83780000ddc0c3b48e57a87eab6814c4ab35058/3Q26%20ManagementReport.pdf'
tsm={'accounting_standard':'TIFRS, not US GAAP','latest_period_end':'2026-09-30','latest_earnings_publication_date':'2026-10-15','latest_report_url':tsm_q3,'source_urls':[tsm_q3,tsm_q4,tsm_mgmt],'web_source_refs':['turn26search5','turn38view1','turn47view1'],'ttm_period':['2025-10-01','2026-09-30'],'ads_to_ordinary_share_ratio':5,'fx_twd_per_usd':{'balance_sheet_2026_09_30':31.880,'income_and_cashflow_9m2026_weighted_average':31.744,'income_q4_2025_weighted_average':31.013,'income_q3_2026_weighted_average':31.983},'ttm':{},'balance':{},'shares':{},'notes':[]}
q4={'revenue':1046.090,'operating_income_gaap':564.903,'net_income_attributable_to_parent_gaap':505.744,'cfo':725.509,'cash_capex_gross':356.906}
ytd={'revenue':3898.727,'operating_income_gaap':2302.014,'net_income_attributable_to_parent_gaap':2042.106,'cfo':2402.117,'cash_capex_gross':1289.971}
ytd_usd={'revenue':122.819,'operating_income_gaap':72.518,'net_income_attributable_to_parent_gaap':64.330,'cfo':75.671,'cash_capex_gross':40.637}
q4_usd={'revenue':33.731,'operating_income_gaap':18.215,'net_income_attributable_to_parent_gaap':16.307,'cfo':725.509/31.013,'cash_capex_gross':356.906/31.013}
for k in q4:
    twd=q4[k]+ytd[k]
    tsm['ttm'][k]={'value_usd_billions':round(q4_usd[k]+ytd_usd[k],9),'value_twd_billions':round(twd,9),'usd_translation_method':'Q4 2025 at its period average + 9M 2026 company USD translation; historical-flow FX, not spot FX','value_usd_billions_constant_sep30_fx':round(twd/31.880,9),'formula_twd_billions':f'{q4[k]} + {ytd[k]}','method':'actual Q4 2025 + actual 9M 2026','constituents':[{'period':['2025-10-01','2025-12-31'],'raw_twd_millions':round(q4[k]*1000),'value_usd_billions':q4_usd[k],'source_url':tsm_q4,'usd_conversion':'company reported Q4 USD for earnings; Q4 TWD cash flows divided by Q4 31.013 for cash flows'},{'period':['2026-01-01','2026-09-30'],'raw_twd_millions':round(ytd[k]*1000),'value_usd_billions':ytd_usd[k],'source_url':tsm_q3,'usd_conversion':'company reported 9M USD at 31.744'}]}
tsm['ttm']['sbc_cashflow_addback']={'value_usd_billions':None,'value_twd_billions':None,'reason':'Latest Q3 condensed cash-flow statement groups this in changes in working capital and others; current 9M SBC was not separately verified. Prior FY SBC is not substituted for TTM.','source_url':tsm_q3}
tsm['ttm']['fcf_cfo_minus_gross_cash_capex']={'value_usd_billions':round(tsm['ttm']['cfo']['value_usd_billions']-tsm['ttm']['cash_capex_gross']['value_usd_billions'],9),'value_twd_billions':round(2402.117+725.509-1289.971-356.906,9),'formula':'cfo - gross cash PPE acquisitions'}
tsm['ttm']['fcf_less_sbc_sensitivity']={'value_usd_billions':None,'reason':'TTM SBC not separately established.'}
for k,twd in {'cash_and_equivalents':3621.894,'current_marketable_financial_instruments':395.085,'cash_plus_current_marketable_investments':4016.979,'interest_bearing_debt_carrying':1031.58,'current_bonds_and_bank_loans':213.198,'noncurrent_bonds':770.315}.items():
    tsm['balance'][k]={'value_usd_billions':round(twd/31.880,9),'value_twd_billions':twd,'asof':'2026-09-30','fx_twd_per_usd':31.880,'source_url':tsm_mgmt if k=='interest_bearing_debt_carrying' else tsm_q3}
tsm['balance']['finance_lease_liabilities']={'value_usd_billions':None,'asof':'2026-09-30','note':'Latest condensed statement does not separately quantify lease liabilities. TIFRS lease/debt boundary differs from US GAAP.'}
tsm['shares']={'period_end_ordinary_common':{'value_shares_billions':None,'reason':'Exact unrounded September 30 ordinary shares not separately established from condensed financials.'},'latest_quarter_diluted_weighted_average_ordinary':{'value_shares_billions':25.932,'period':['2026-07-01','2026-09-30'],'source_url':tsm_q3},'latest_quarter_diluted_weighted_average_ads_equivalent':{'value_shares_billions':5.1864,'formula':'25.932 / 5','period':['2026-07-01','2026-09-30'],'source_url':tsm_q3}}
tsm['capex_definition']='Gross cash acquisitions of PPE, before PPE disposal proceeds, government grants and intangible asset purchases. New noncash leases and lease principal payments excluded. Separate current TTM intangible purchases were not established from the condensed statement.'
tsm['cashflow_interest_reclassification']={'reported_cfo_excludes_interest_and_dividends_received':True,'reported_cfo_excludes_interest_paid':True,'ttm_interest_received_twd_billions':114.255,'ttm_dividends_received_twd_billions':5.160,'ttm_interest_paid_twd_billions':20.054,'us_gaap_style_cfo_proxy_twd_billions':3226.987,'formula_twd_billions':'3127.626 + (88.095+26.160) + (5.111+0.049) - (14.704+5.350)','warning':'Mechanical classification bridge only; not a full US GAAP reconciliation. Dividends may need further investment-specific classification review.','source_urls':[tsm_q3,tsm_q4]}
tsm['notes'] += ['The primary flow series uses historical-period USD translation. For valuation at a single exchange rate, the constant September 30 FX series is provided separately. Never mix TWD cash flows directly with USD share prices.', '1 ADS represents 5 ordinary shares. Divide consolidated USD equity value by ordinary shares / 5 to obtain USD value per ADS. Do not divide directly by 25.932 billion ordinary shares and call the result an ADS price.', 'CFO classification differs from US GAAP: interest/dividends received are investing and interest paid is financing. Cross-company P/FCF requires either a stated bridge or a comparability caveat.', 'Q2 2026 nonoperating earnings include disposal/mark-to-market gains on Vanguard International Semiconductor shares; Q2 operating income also benefited from earthquake insurance recovery. These are reasons not to treat every component of GAAP net income as recurring.', 'Q3 management report interest-bearing debt is NT$1,031.58b and captures noncurrent bank loans in addition to bonds/current debt; do not sum only the two visible condensed balance-sheet debt lines and miss bank loans.', 'TSM gross cash capex excludes intangible asset purchases in condensed cashflow Others, while NVDA capex includes intangibles. Scope difference explicitly retained.']
tsm['summary_usd_billions']={k:v.get('value_usd_billions') for k,v in tsm['ttm'].items()}
out['companies']['TSM']=tsm

(ROOT/'semiconductors.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
for s,c in out['companies'].items():
    print(s,c['summary_usd_billions'])
print(ROOT/'semiconductors.json')
