AI portfolio review — 2026-11-13 US regular close
Budget: USD 7,000. Analysis and a proposed allocation, not executed trades.

Main outputs — final response to the user's NVIDIA-conviction clarification
1. analysis/portfolio_conviction_review.json: complete portfolio weights, dollar allocations,
   current reported-TTM valuation screen, risk calculations and news provenance.
2. analysis/portfolio_conviction_comparison.csv and portfolio_conviction_daily_returns.csv:
   final reusable results. Earlier portfolio_review.json is retained as the cautious
   comparison, not the final recommended target.
3. market_data_extended/: 39-asset final Yahoo chart responses and combined data;
   market_data/ preserves the original 32-asset download. Adjusted/unadjusted closes,
   correlation/covariance tables, source timestamps and quality checks.
4. candidate_research.json and candidate_raw/: primary company/SEC research,
   TTM components, event dates and the actual-versus-assumption distinction.
5. nvidia_news.json: confirmed governance events, unresolved issues and source URLs.
6. analyze_refresh.py and analyze_conviction.py: calculations, in that order.
   Requirements: Python, pandas, numpy. The final model adds policy portfolios
   consistent with the user's stated NVIDIA business conviction.
7. The accompanying valuation_research/consolidated_model.json preserves the
   previous dated accounting inputs and conditional DCF, needed for reproduction.

Reproduce after extracting the zip without changing its folder structure:
    python portfolio_refresh_20261113/analyze_refresh.py
    python portfolio_refresh_20261113/analyze_conviction.py
The included independent audit and figure scripts provide additional checks and
visuals. A spreadsheet is a dated report; changing its budget changes allocation
amounts, not historical covariance or an automatically optimized strategy.

Recommended policy target, revised after the user's clarification:
VTI 35%; NVDA 15%; GOOGL 15%; MSFT 10%; META 5%; BRK-B 10%; XLV 5%; SGOV 5%.
Illustrative initial entry:
VTI 35%; NVDA 10%; GOOGL 15%; MSFT 10%; META 5%; BRK-B 10%; XLV 5%; SGOV 10%.
Initial NVDA USD700 explicitly expresses business conviction. A further USD350
held in SGOV is reserved for a later decision, not automatic buying after earnings.
Review NVIDIA's scheduled November17 release and filings before reassessing it.
The target is 95% equities, with 45% direct AI-related company stocks; entry is
90% equities with 40% direct AI-related company stocks. ETFs add indirect exposure.
The final target accepts slightly higher historical volatility and drawdown than
the previous seven-asset plan. It is not presented as universally safer, optimal,
or guaranteed to outperform. The earlier 5%-NVDA version remains a comparison.

Gemini-plan audit
gemini_audit/ contains primary-source checks of QCOM/CRM earnings, BRK share-class
valuation/insurance float, Apple cloud/Taiwan dependencies, grid-policy timing,
and unsupported hedge/optimization/rebalancing assertions. Exact per-stock Gemini
weights and an expected-return vector were absent; its claimed optimized volatility
cannot be reproduced as an exact portfolio. No guessed weights are attributed to it.
Lower historical correlation is a diversification input, not loss insurance.
Stock-market risk is not removed by outsourcing cloud infrastructure or by avoiding
direct ownership of TSM shares. One-week prices do not identify policy causality.

Interpretation and material limitations
- A 3–5 year or longer horizon is assumed, not confirmed; these allocations are
  unsuitable for capital that must fund a near-term, fixed spending obligation.
- Price data use split/dividend-adjusted total-return proxies in USD. Sample
  windows use price anchors 2021-11-12, 2024-11-13 and 2025-11-13 through 2026-11-13.
- Portfolios rebalance at calendar quarter boundaries with no taxes, commissions
  or spreads. The initial portfolio NAV is included in drawdown calculations.
- Annual volatility uses sample daily standard deviation times sqrt(252).
  ES95 is the mean loss among ceil(5% * number of days) worst historical days.
  It is not an annual loss limit, nor a guaranteed future quantile.
- Risk contributions use target weights and sample covariance; they differ from
  quarterly-rebalanced path metrics. ETF contributions are at wrapper level.
  Direct NVDA exposure/risk excludes the NVIDIA stock already held within VTI.
- The Nov6–Nov13 event replay resets each allocation to target at the Nov6 close.
  These allocations were selected with subsequent information. This is a
  retrospective diagnostic, not out-of-sample validation or earned performance.
- Asset correlations are based on daily returns, not price levels. They vary
  across windows and crises. A lower positive correlation is not a reliable hedge.
- Stress losses are weighted arithmetic for explicit invented joint asset shocks,
  not forecasts or probability estimates. The VTI shock is assumed and is not a
  current holdings-level look-through estimate.
- Historical comparisons contain selection and survivorship bias. Governance
  discontinuities and future customer-financing failures are not fully captured
  by historical covariance. No expected return, Sharpe optimum or guaranteed
  probability of gain is asserted.
- Provider data were refreshed. Nov2 SGOV/IEF distributions were missing from
  the previous price snapshot and are now included. All old and new portfolios
  were recalculated on the same corrected series; do not attribute every change
  from the old printed report to allocation changes alone.
- New ETF/stock names do not automatically add a new economic risk factor.
  META and GOOGL share advertising, market and AI-capex exposure; ANET, TSM and
  ETN can remain exposed to the same hyperscaler spending cycle as NVIDIA.

Accounting definitions
- Financial inputs are reported actuals, in USD billions in portfolio_review.json,
  with period ends and share-count conventions recorded for each company.
- Current approximate common market value = Nov13 price × latest reported shares.
  Alphabet's common share classes use GOOGL's price as an approximation.
- TTM is reconstructed from reported periods; for the five newly checked names:
  FY2025 + 9m2026 - 9m2025, ending September 30, 2026.
- Cash FCF proxy = GAAP operating cash flow - cash purchases of fixed assets.
  It excludes acquisition cash and financing-lease principal and is not FCFF.
- FCF less stock-based compensation is a shareholder-cost sensitivity, not a
  GAAP measure. It must not be deducted again from a DCF whose GAAP EBIT already
  recognizes SBC. Unavailable SBC is null, never assumed zero.
- Reported P/E is affected by investment revaluations, tax items, litigation and
  acquisition accounting. Multiples alone do not establish intrinsic value.
- NVIDIA's 11%/12%/13% discount-rate scenario holds the earlier model's forecasts
  and balance-sheet bridge fixed. It is a sensitivity, not a newly estimated WACC
  or a forecast target. Governance problems may also change future cash flows.
- Guarantees are contingent gross exposure, not automatically funded debt or
  expected loss. Fundraising adds obligations or dilution as well as cash.

No recommendation assumes that earlier proposed portfolios were purchased.
If shares are already held, actual weights, cost bases and account tax treatment
are needed before choosing a trade list. Fractional-share quantities in the report
are illustrative; the next market's execution price will differ from Nov13 close.
