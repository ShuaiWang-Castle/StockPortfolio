"""Extend the preserved Nov 13 public-market panel without altering it.

Freshly fetch seven additional symbols, merge with the original same-session
32-symbol snapshot, and publish reproducible window/tail/event diagnostics.
"""
from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import concurrent.futures
import hashlib
import json
import shutil
import time
import urllib.parse
import urllib.request

import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / "market_data"
RAW = OUT / "raw"
RAW.mkdir(parents=True, exist_ok=True)
EXTRA = ["BRK-B", "LLY", "UNH", "QCOM", "CRM", "AAPL", "SOXX"]
START = "2021-11-05"
ASOF = "2026-11-13"
PERIOD1 = int(datetime(2021, 11, 5, tzinfo=timezone.utc).timestamp())
PERIOD2 = int(datetime(2026, 11, 14, tzinfo=timezone.utc).timestamp())


def fetch(ticker):
    query = urllib.parse.urlencode({"period1": PERIOD1, "period2": PERIOD2, "interval": "1d",
                                   "events": "div,splits,capitalGains", "includeAdjustedClose": "true"})
    url = f"https://query2.finance.yahoo.com/v8/finance/chart/{ticker}?{query}"
    for attempt in range(3):
        try:
            request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(request, timeout=35) as response:
                raw = response.read()
            data = json.loads(raw)
            assert data["chart"]["error"] is None, data["chart"]["error"]
            result = data["chart"]["result"][0]
            meta = result["meta"]
            tz = ZoneInfo(meta["exchangeTimezoneName"])
            dates = [datetime.fromtimestamp(t, tz).date().isoformat() for t in result["timestamp"]]
            frame = pd.DataFrame({"Date": dates, "Close": result["indicators"]["quote"][0]["close"],
                                  "AdjClose": result["indicators"]["adjclose"][0]["adjclose"]}).set_index("Date")
            frame = frame.loc[START:ASOF]
            (RAW / f"{ticker}.json").write_bytes(raw)
            source = {"ticker": ticker, "url": url, "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                      "raw_sha256": hashlib.sha256(raw).hexdigest(), "raw_bytes": len(raw),
                      "symbol": meta["symbol"], "currency": meta["currency"],
                      "exchange_timezone": meta["exchangeTimezoneName"],
                      "regular_market_price": meta["regularMarketPrice"],
                      "regular_market_time_utc": datetime.fromtimestamp(meta["regularMarketTime"], timezone.utc).isoformat(),
                      "first_price_date": frame.index.min(), "last_price_date": frame.index.max(),
                      "n_prices": len(frame), "snapshot_origin": "Fresh seven-symbol extension request",
                      "splits": [{**s, "date_local": datetime.fromtimestamp(s["date"], tz).date().isoformat()}
                                 for s in result.get("events", {}).get("splits", {}).values()],
                      "price_definition": "Provider Close adjusts splits; AdjClose also adjusts dividends. No filling or manual additional adjustment."}
            return ticker, frame, source
        except Exception as exc:
            if attempt == 2:
                return ticker, None, {"ticker": ticker, "url": url, "error": repr(exc)}
            time.sleep(attempt + 1)


def main():
    base_provenance = json.loads((BASE / "provenance.json").read_text())
    close = pd.read_csv(BASE / "close.csv", index_col=0)
    adjusted = pd.read_csv(BASE / "adjusted_close.csv", index_col=0)
    original_columns = close.columns.tolist()
    sources = {}
    for ticker, source in base_provenance["sources"].items():
        sources[ticker] = {**source, "snapshot_origin": "Preserved original 32-symbol Nov 13 completed-session fetch"}
        shutil.copyfile(BASE / "raw" / f"{ticker}.json", RAW / f"{ticker}.json")
    errors = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for ticker, frame, source in pool.map(fetch, EXTRA):
            if frame is None:
                errors[ticker] = source
                print("FETCH_ERROR", ticker, source["error"], flush=True)
            else:
                # Same exchange-session calendar is required; never silently
                # truncate the old universe to make a new symbol fit.
                assert frame.index.equals(close.index), (ticker, frame.index.min(), frame.index.max(), len(frame))
                close[ticker] = frame["Close"]
                adjusted[ticker] = frame["AdjClose"]
                sources[ticker] = source
                print("FETCH_OK", ticker, frame.index[-1], float(frame["Close"].iloc[-1]), len(frame), flush=True)
    provenance = {"analysis_asof": ASOF, "requested_start": START, "ticker_count": len(sources),
                  "base_snapshot": str(BASE),
                  "base_adjusted_csv_sha256": hashlib.sha256((BASE / "adjusted_close.csv").read_bytes()).hexdigest(),
                  "base_close_csv_sha256": hashlib.sha256((BASE / "close.csv").read_bytes()).hexdigest(),
                  "new_tickers": EXTRA, "original_tickers": original_columns, "sources": sources, "errors": errors,
                  "merge_policy": "Original 32 Nov13 completed-session columns are copied unchanged; seven independent full-history requests use identical dates and corporate-action parameters. Raw JSON for all 39 symbols is included."}
    (OUT / "provenance.json").write_text(json.dumps(provenance, indent=2))
    assert not errors, errors
    close.to_csv(OUT / "close.csv", index_label="Date")
    adjusted.to_csv(OUT / "adjusted_close.csv", index_label="Date")
    daily = adjusted.pct_change(fill_method=None)
    daily.to_csv(OUT / "daily_returns.csv", index_label="Date")
    qa = {"ticker_count": len(close.columns), "price_rows": len(close), "start": close.index[0], "end": close.index[-1],
          "base_close_columns_identical": bool(close[original_columns].equals(pd.read_csv(BASE / "close.csv", index_col=0))),
          "base_adjusted_columns_identical": bool(adjusted[original_columns].equals(pd.read_csv(BASE / "adjusted_close.csv", index_col=0))),
          "missing_close": close.isna().sum().astype(int).to_dict(),
          "missing_adjusted": adjusted.isna().sum().astype(int).to_dict(),
          "duplicate_dates": int(close.index.duplicated().sum()), "monotonic_dates": bool(close.index.is_monotonic_increasing),
          "nonpositive_prices": int((adjusted <= 0).sum().sum()),
          "new_symbols_usd": all(sources[t]["currency"] == "USD" for t in EXTRA),
          "new_symbols_latest_date": {t: sources[t]["last_price_date"] for t in EXTRA},
          "new_symbols_close_metadata_difference": {t: float(abs(close.loc[ASOF, t] - sources[t]["regular_market_price"])) for t in EXTRA},
          "absolute_daily_returns_above_80pct": [],
          "notes": ["CEG retains 50 missing prelisting price dates. It is excluded from full five-year metrics and covariance; all other symbols have the full requested history.",
                    "A five-year sample starts at the 2021-11-12 close; a two-year sample starts at 2024-11-13 close.",
                    "No postmarket prices used; fresh symbol metadata is checked against the regular-session close."]}
    for ticker in EXTRA:
        for date, value in daily[ticker].dropna().items():
            if abs(value) > .8:
                qa["absolute_daily_returns_above_80pct"].append({"ticker": ticker, "date": date, "return": float(value)})
    assert qa["base_close_columns_identical"] and qa["base_adjusted_columns_identical"]
    assert qa["duplicate_dates"] == 0 and qa["monotonic_dates"] and qa["nonpositive_prices"] == 0
    assert qa["new_symbols_usd"] and all(x == ASOF for x in qa["new_symbols_latest_date"].values())
    assert max(qa["new_symbols_close_metadata_difference"].values()) < .011
    assert not qa["absolute_daily_returns_above_80pct"]
    (OUT / "quality_checks.json").write_text(json.dumps(qa, indent=2))

    records = []
    window_metadata = {}
    for window, anchor in [("two_year", "2024-11-13"), ("five_year", "2021-11-12")]:
        prices = adjusted.loc[anchor:ASOF]
        returns = prices.pct_change(fill_method=None).iloc[1:]
        nvda = returns["NVDA"]
        vti = returns["VTI"]
        n_q10 = float(nvda.quantile(.1))
        n_q05 = float(nvda.quantile(.05))
        # Strict < follows the requested empirical-coexceedance definition.
        # Inclusive <= is also retained to reconcile the preceding 51-day table.
        n_low10 = nvda < n_q10
        n_low05 = nvda < n_q05
        inclusive10 = nvda <= n_q10
        inclusive05 = nvda <= n_q05
        full_columns = prices.columns[~prices.isna().any()].tolist()
        returns[full_columns].corr().to_csv(OUT / f"{window}_correlation.csv")
        returns[full_columns].cov().to_csv(OUT / f"{window}_daily_covariance.csv")
        window_metadata[window] = {"price_anchor": anchor, "first_return_date": returns.index[0],
            "last_return_date": returns.index[-1], "n_returns": len(returns),
            "nvda_q10": n_q10, "nvda_q05": n_q05,
            "nvda_strict_q10_count": int(n_low10.sum()), "nvda_strict_q05_count": int(n_low05.sum()),
            "nvda_inclusive_q10_count": int(inclusive10.sum()), "nvda_inclusive_q05_count": int(inclusive05.sum()),
            "complete_symbols": full_columns, "incomplete_symbols": [t for t in prices if t not in full_columns]}
        for ticker in adjusted.columns:
            r = returns[ticker]
            record = {"window": window, "ticker": ticker, "last_close": float(close.loc[ASOF, ticker]),
                      "price_anchor": anchor, "last_return_date": ASOF, "requested_n_returns": len(returns),
                      "complete_window": ticker in full_columns, "observed_n_returns": int(r.notna().sum())}
            if ticker not in full_columns:
                record["reason_metrics_omitted"] = "Incomplete requested history; no extrapolation or IPO-date truncation of the common five-year window."
                records.append(record)
                continue
            nav = prices[ticker] / prices[ticker].iloc[0]
            q10 = float(r.quantile(.1))
            q05 = float(r.quantile(.05))
            other_low10 = r < q10
            other_low05 = r < q05
            record.update({"ann_vol": float(r.std(ddof=1) * np.sqrt(252)), "rho_nvda": float(r.corr(nvda)),
                "beta_vti": float(r.cov(vti) / vti.var(ddof=1)), "max_drawdown": float((nav / nav.cummax() - 1).min()),
                "mean_return_on_nvda_worst_decile_strict": float(r[n_low10].mean()),
                "mean_return_on_nvda_worst_decile_inclusive": float(r[inclusive10].mean()),
                "fraction_negative_on_nvda_worst_decile_strict": float((r[n_low10] < 0).mean()),
                "nvda_q10_threshold": n_q10, "stock_q10_threshold": q10,
                "nvda_strict_q10_count": int(n_low10.sum()), "stock_strict_q10_count": int(other_low10.sum()),
                "joint_strict_q10_count": int((n_low10 & other_low10).sum()),
                "empirical_conditional_coexceedance_q10": float((n_low10 & other_low10).sum() / n_low10.sum()),
                "nvda_q05_threshold": n_q05, "stock_q05_threshold": q05,
                "nvda_strict_q05_count": int(n_low05.sum()), "stock_strict_q05_count": int(other_low05.sum()),
                "joint_strict_q05_count": int((n_low05 & other_low05).sum()),
                "empirical_conditional_coexceedance_q05": float((n_low05 & other_low05).sum() / n_low05.sum()),
                "mean_return_on_nvda_worst_5pct_strict": float(r[n_low05].mean())})
            records.append(record)
    metrics = pd.DataFrame(records)
    metrics.to_csv(OUT / "asset_metrics_two_five_year.csv", index=False)
    for window in window_metadata:
        metrics[metrics.window == window].to_csv(OUT / f"{window}_asset_metrics.csv", index=False)

    event_records = []
    for start, end in [("2026-11-03", "2026-11-05"), ("2026-11-02", "2026-11-04"), ("2026-11-06", ASOF)]:
        for ticker in close:
            event_records.append({"ticker": ticker, "start_close_date": start, "end_close_date": end,
                "n_daily_returns": len(close.loc[start:end]) - 1,
                "start_close": float(close.loc[start, ticker]), "end_close": float(close.loc[end, ticker]),
                "price_return": float(close.loc[end, ticker] / close.loc[start, ticker] - 1),
                "adjusted_total_return": float(adjusted.loc[end, ticker] / adjusted.loc[start, ticker] - 1)})
    events = pd.DataFrame(event_records)
    events.to_csv(OUT / "event_window_returns.csv", index=False)
    # Audit exact submitted numerical claims, without inferring their unstated
    # sampling window or categorizing correlations into universal thresholds.
    two = metrics[metrics.window == "two_year"].set_index("ticker")
    claims = {"SBUX": {"claimed_rho_nvda": .18, "claimed_ann_vol": .26},
              "JPM": {"claimed_rho_nvda": .12, "claimed_ann_vol": .16}}
    for ticker, claim in claims.items():
        claim.update({"observed_rho_nvda_2y": float(two.loc[ticker, "rho_nvda"]),
                      "observed_ann_vol_2y": float(two.loc[ticker, "ann_vol"]),
                      "rho_difference_observed_minus_claim": float(two.loc[ticker, "rho_nvda"] - claim["claimed_rho_nvda"]),
                      "vol_difference_observed_minus_claim": float(two.loc[ticker, "ann_vol"] - claim["claimed_ann_vol"]),
                      "qualification": "Only comparable when the claim uses the same dates, adjusted daily simple returns, and 252-day annualization; source/method for the pasted claim was not supplied."})
    summary = {"asof": ASOF, "price_start": START, "n_tickers": len(adjusted.columns),
               "windows": window_metadata, "metrics": records, "claim_audit": claims,
               "tail_definitions": {
                   "strict_q10": "Count(r_i < empirical q10_i AND r_NVDA < empirical q10_NVDA) / Count(r_NVDA < empirical q10_NVDA), using same-window daily adjusted simple returns.",
                   "strict_q05": "Analogous finite-threshold empirical conditional frequency at 5%, with both marginal and joint counts reported.",
                   "inclusive_means": "The prior table used NVDA <= q10 (51 two-year observations). This extension also reports that mean for reconciliation; strict < uses 50 observations because the interpolated quantile equals an observed return for N=501.",
                   "limitation": "These are finite-sample, finite-threshold descriptive coexceedances. They are NOT asymptotic lower-tail dependence lambda, future probabilities, proof of a hedge, or confidence bounds."},
               "event_windows": event_records,
               "interpretation": "Positive or weak ordinary correlation alone does not establish a hedge; compare volatility, broad-market beta, stress-day average returns, and empirical lower-tail coexceedance. Metrics are historical and regime dependent."}
    (OUT / "asset_metrics.json").write_text(json.dumps(summary, indent=2, allow_nan=False))
    print("EXTENDED_QA_OK", len(adjusted.columns), "tickers", len(adjusted), "price dates", flush=True)
    print(metrics[(metrics.window == "two_year") & metrics.ticker.isin(EXTRA + ["NVDA", "SBUX", "JPM"])][
        ["ticker", "last_close", "ann_vol", "rho_nvda", "beta_vti", "max_drawdown",
         "mean_return_on_nvda_worst_decile_strict", "empirical_conditional_coexceedance_q10",
         "empirical_conditional_coexceedance_q05"]].round(5).to_string(index=False))
    print(json.dumps({"windows": window_metadata, "claim_audit": claims}, indent=2))


if __name__ == "__main__":
    main()
