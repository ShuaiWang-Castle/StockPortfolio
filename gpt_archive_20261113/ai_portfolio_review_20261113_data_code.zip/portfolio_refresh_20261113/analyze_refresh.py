"""Dated, reproducible portfolio review. No return forecasting or weight optimization.

Uses only prices available at the 2026-11-13 US regular close. New allocations
are selected after that date's information; their historical paths are hypothetical.
"""
from pathlib import Path
import json
import math
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
OUT = BASE / 'analysis'
OUT.mkdir(exist_ok=True)
PRICES = pd.read_csv(BASE/'market_data/adjusted_close.csv', index_col=0, parse_dates=True)
CLOSE = pd.read_csv(BASE/'market_data/close.csv', index_col=0, parse_dates=True)
END = pd.Timestamp('2026-11-13')
BUDGET = 7000

# Policy choices fixed before inspecting their backtest results, not fitted weights.
ALLOCATIONS = {
    'original6': {'label':'最初六资产方案', 'weights':{'VTI':.35,'NVDA':.20,'MSFT':.15,'AMZN':.10,'XLV':.10,'SGOV':.10}},
    'prior7': {'label':'上次七资产方案', 'weights':{'VTI':.40,'NVDA':.15,'GOOGL':.10,'MSFT':.10,'AMZN':.05,'XLV':.10,'SGOV':.10}},
    'platform7': {'label':'平台倾斜比较方案', 'weights':{'VTI':.40,'GOOGL':.15,'MSFT':.10,'META':.10,'NVDA':.05,'XLV':.10,'SGOV':.10}},
    'revised7': {'label':'本次目标方案', 'weights':{'VTI':.45,'GOOGL':.12,'MSFT':.10,'META':.08,'NVDA':.05,'XLV':.10,'SGOV':.10}},
    'entry': {'label':'当前分步建仓方案', 'weights':{'VTI':.45,'GOOGL':.10,'MSFT':.10,'META':.05,'XLV':.10,'SGOV':.20}},
}
for satellite in ('ANET','TSM','NOW','ETN'):
    ALLOCATIONS['satellite_'+satellite] = {
        'label': '额外5%'+satellite+'比较方案',
        'weights':{'VTI':.40,'GOOGL':.12,'MSFT':.10,'META':.08,'NVDA':.05,satellite:.05,'XLV':.10,'SGOV':.10}
    }

WINDOWS = {'five_year':'2021-11-12','two_year':'2024-11-13','one_year':'2025-11-13'}

STRESSES = {
    'nvda_specific': {
        'label':'NVDA个别事件冲击',
        'definition':'NVDA -40%; VTI -2.5% as an explicit assumed indirect index effect; all other assets 0%. Not a measured look-through calculation.',
        'shocks':{'NVDA':-.40,'VTI':-.025}
    },
    'ai_capex_contraction': {
        'label':'AI资本开支收缩',
        'definition':'Hypothetical joint repricing: VTI -25%, NVDA -50%, platforms -30%, ANET/TSM -40%, NOW/ETN -30%, XLV -10%, SGOV 0%. No assigned probability.',
        'shocks':{'VTI':-.25,'NVDA':-.50,'GOOGL':-.30,'MSFT':-.30,'META':-.30,'AMZN':-.30,'ANET':-.40,'TSM':-.40,'NOW':-.30,'ETN':-.30,'XLV':-.10,'SGOV':0.}
    },
    'platform_ad_repricing': {
        'label':'广告与平台估值下调',
        'definition':'VTI -20%, GOOGL/META -30%, MSFT/AMZN/NOW -20%, NVDA/ANET/TSM/ETN -10%, XLV -10%, SGOV 0%. Designed to expose the revised portfolio\'s shared platform risk.',
        'shocks':{'VTI':-.20,'GOOGL':-.30,'META':-.30,'MSFT':-.20,'AMZN':-.20,'NOW':-.20,'NVDA':-.10,'ANET':-.10,'TSM':-.10,'ETN':-.10,'XLV':-.10,'SGOV':0.}
    }
}

def portfolio_returns(weights, start, end=END):
    """Quarterly calendar rebalancing at previous quarter's final close, no costs."""
    columns = list(weights) # Exclude zero-weight/newly listed securities before NaN checks.
    p = PRICES.loc[pd.Timestamp(start):pd.Timestamp(end), columns]
    assert not p.isna().any().any(), (columns, start)
    r = p.pct_change(fill_method=None).iloc[1:]
    target = np.array([weights[t] for t in columns], dtype=float)
    assert abs(target.sum()-1)<1e-12
    current = target.copy()
    previous_quarter = p.index[0].to_period('Q')
    values = []
    for date, vector in r.iterrows():
        quarter = date.to_period('Q')
        if quarter != previous_quarter:
            current = target.copy()
        asset_return = vector.to_numpy(dtype=float)
        result = float(current @ asset_return)
        values.append(result)
        current = current*(1+asset_return)/(1+result)
        previous_quarter = quarter
    return pd.Series(values, index=r.index), r

def stats(returns, start):
    nav = pd.Series(np.r_[1., np.cumprod(1+returns.to_numpy())])
    drawdown = nav/nav.cummax()-1
    k = math.ceil(.05*len(returns))
    years = (returns.index[-1]-pd.Timestamp(start)).days/365.25
    return {
        'price_anchor_date':str(pd.Timestamp(start).date()),
        'first_return_date':str(returns.index[0].date()),
        'last_return_date':str(returns.index[-1].date()),
        'n_returns':len(returns),
        'annualized_volatility':float(returns.std(ddof=1)*np.sqrt(252)),
        'max_drawdown':float(drawdown.min()),
        'daily_es95_loss':float(-returns.nsmallest(k).mean()),
        'daily_es95_observations':k,
        'historical_cagr':float(nav.iloc[-1]**(1/years)-1),
        'historical_total_return':float(nav.iloc[-1]-1),
    }

def risk_contribution(weights, asset_returns):
    w = np.array([weights[t] for t in asset_returns.columns])
    cov = asset_returns.cov().to_numpy()*252
    variance = float(w@cov@w)
    rc = w*(cov@w)/variance
    return {'target_covariance_volatility':float(np.sqrt(variance)),
            'fraction_of_variance_by_asset':dict(zip(asset_returns.columns, map(float,rc)))}

def make_screen():
    old = json.load(open(ROOT/'valuation_research/consolidated_model.json'))
    candidates = json.load(open(BASE/'candidate_research.json'))
    results = {}
    # Reprice latest reported TTM actuals, not previous fair-value estimates.
    for c in old['companies']:
        t=c['ticker']
        if t not in CLOSE.columns:
            continue
        price=float(CLOSE.loc[END,t]); shares=c['share_count_billion']
        cap=price*shares; fcf=c['cfo']-c['cash_capex']
        results[t] = {'ticker':t,'name':c['name'],'price':price,'price_date':'2026-11-13',
            'financial_period_end':c['financial_period_end'],'shares_billion':shares,'share_date':c['share_date'],
            'revenue_billion':c['ttm_revenue'],'net_income_billion':c['ttm_net_income'],
            'operating_income_billion':c['ttm_op_income'],'cfo_billion':c['cfo'],
            'cash_capex_billion':c['cash_capex'],'sbc_billion':c['sbc'],
            'fcf_billion':fcf,'market_cap_billion':cap,'pe':cap/c['ttm_net_income'] if c['ttm_net_income']>0 else None,
            'fcf_yield':fcf/cap,'fcf_minus_sbc_yield':(fcf-c['sbc'])/cap if c['sbc'] is not None else None,
            'source_urls':c['source_urls'],'notes':c['notes'],
            'actuals_status':'Latest reported TTM reused from verified prior model; price refreshed, not a new earnings release.'}
    for t,c in candidates['companies'].items():
        v=c.get('valuation')
        if not v:
            continue
        def actual(key):
            a=v.get(key)
            return a.get('ttm')/1e9 if isinstance(a,dict) and a.get('ttm') is not None else None
        source_urls=[x['url'] for k,x in candidates['sources'].items() if k.startswith(('goog' if t=='GOOGL' else t.lower())+'_')]
        results[t] = {'ticker':t,'name':t,'price':v['price'],'price_date':'2026-11-13',
            'financial_period_end':'2026-09-30','shares_billion':v['common_shares']/1e9,
            'share_date':'Latest disclosed shares; see SEC components in candidate_research.json',
            'revenue_billion':actual('revenue'),'net_income_billion':actual('net_income'),
            'operating_income_billion':actual('operating_income'),'cfo_billion':actual('cfo'),
            'cash_capex_billion':actual('capex'),'sbc_billion':actual('sbc'),
            'fcf_billion':v['fcf']/1e9,'market_cap_billion':v['market_cap']/1e9,
            'pe':v['pe'],'fcf_yield':v['fcf_yield'],'fcf_minus_sbc_yield':v.get('fcf_minus_sbc_yield'),
            'source_urls':source_urls,'notes':c.get('portfolio_role',c.get('judgment','')),
            'actuals_status':'Rebuilt TTM from SEC: FY2025 + 9m2026 - 9m2025.'}
    return results,old,candidates

def main():
    asset_data=json.load(open(BASE/'market_data/asset_metrics.json'))
    news=json.load(open(BASE/'nvidia_news.json'))
    supplemental=json.load(open(BASE/'market_data/supplemental_diagnostics.json'))
    result={
        'meta':{'as_of':'2026-11-13 US regular close','budget_usd':BUDGET,
            'recommended_target':'revised7','initial_entry':'entry','historical_windows':WINDOWS,
            'important':'Hypothetical retrospective comparisons, not a prospective or out-of-sample validation of these newly selected weights.',
            'method':'Split/dividend-adjusted USD daily returns; quarterly calendar rebalancing; 252 trading-day annualization; sample covariance; no taxes, spreads or commissions. SGOV distributions are included.',
            'tail_metric':'ES95 is the mean loss among ceil(5% * N) worst daily historical returns, not an annual maximum loss or a loss bound.',
            'suitability_assumption':'Independent growth capital; 3-5 year or longer horizon assumed but not confirmed. No existing holdings or tax lots presumed.',
            'choice_basis':'Rule-based exposure limits and accounting/news judgment; weights not optimized for highest retrospective return or Sharpe ratio.',
            'event_week_method':'Counterfactual buy-and-hold return after resetting each candidate to target weights at the 2026-11-06 close. Different from that week inside a five-year quarterly-rebalanced path; new weights were selected after the week.',
            'risk_contribution_limit':'Variance contributions attribute ETF wrappers separately. Direct NVDA contribution excludes NVIDIA held inside VTI and is not total issuer look-through risk.',
            'valuation_limit':'Repriced reported TTM multiples are not intrinsic values. Previous GOOGL/MSFT DCF Base values (182.21/356.34) remain conditional assumption outputs, below current prices; target allocations do not assert a margin of safety.',
            'budget_note':'Dollar allocation assumes fractional shares; theoretical units at the close are not execution instructions.'},
        'allocations':{},'stresses':STRESSES,'assets':{r['ticker']:r for r in asset_data['metrics']},
        'data_revisions':supplemental['provider_revisions'],
        'rolling_correlation':supplemental['rolling_summaries'],
    }
    full_returns={}
    nvda_all=PRICES['NVDA'].pct_change(fill_method=None)
    nvda_two=nvda_all.loc[(nvda_all.index>pd.Timestamp(WINDOWS['two_year']))&(nvda_all.index<=END)]
    tail_dates=nvda_two.nsmallest(math.ceil(.1*len(nvda_two))).index
    for name, item in ALLOCATIONS.items():
        weights=item['weights']; metrics={}
        for window,start in WINDOWS.items():
            r,ar=portfolio_returns(weights,start)
            metrics[window]=stats(r,start)
            metrics[window].update(risk_contribution(weights,ar))
            if window=='five_year': full_returns[name]=r
        pre_r,pre_ar=portfolio_returns(weights,WINDOWS['two_year'],pd.Timestamp('2026-11-06'))
        metrics['two_year_pre_event']=stats(pre_r,WINDOWS['two_year'])
        metrics['two_year_pre_event'].update(risk_contribution(weights,pre_ar))
        week_assets=PRICES.loc[END,list(weights)]/PRICES.loc['2026-11-06',list(weights)]-1
        week_return=float(sum(weights[t]*week_assets[t] for t in weights))
        tail_asset_returns=PRICES[list(weights)].pct_change(fill_method=None).loc[tail_dates]
        tail_portfolio=tail_asset_returns.to_numpy()@np.array(list(weights.values()))
        stress_results={}
        for scenario,s in STRESSES.items():
            ret=sum(w*s['shocks'].get(t,0) for t,w in weights.items())
            stress_results[scenario]={'return':ret,'pnl_usd':ret*BUDGET}
        result['allocations'][name]={'label':item['label'],'weights':weights,
            'amounts_usd':{t:w*BUDGET for t,w in weights.items()},
            'theoretical_fractional_units':{t:w*BUDGET/float(CLOSE.loc[END,t]) for t,w in weights.items()},
            'equity_weight':1-weights.get('SGOV',0),
            'direct_ai_company_weight':sum(w for t,w in weights.items() if t not in ('VTI','XLV','SGOV')),
            'metrics':metrics,'week_total_return':week_return,'week_pnl_on_7000':week_return*BUDGET,
            'stress_results':stress_results,
            'nvda_worst_decile':{'n_days':len(tail_dates),'nvda_mean_return':float(nvda_two.loc[tail_dates].mean()),'portfolio_fixed_weight_mean_return':float(tail_portfolio.mean())}}
    screen,old,candidates=make_screen()
    result['company_screen']=screen
    nvda=next(x for x in old['dcf'] if x['ticker']=='NVDA')
    base=nvda['expected_results']['Base']; assumption=nvda['case_assumptions']['Base']
    sensitivity=[]
    for discount in (.11,.12,.13):
        pv=sum(f['fcff']/(1+discount)**f['year'] for f in base['forecast'])
        terminal=base['terminal_fcff']/(discount-assumption['terminal_growth'])/(1+discount)**10
        value=(pv+terminal+base['net_equity_bridge'])/nvda['shares']
        sensitivity.append({'discount_rate':discount,'value_per_share':value,'value_vs_current_price':value/float(CLOSE.loc[END,'NVDA'])-1})
    result['nvda_old_model_sensitivity']={'warning':'Sensitivity of the previous conditional model only; does not establish new intrinsic value. Holds prior cash-flow forecasts, terminal growth and balance-sheet bridge fixed; actual governance effects may also change cash flows.',
        'previous_model_date':'2026-11-09','forecast_first5_revenue_growth':assumption['revenue_growth'][:5],
        'terminal_growth':assumption['terminal_growth'],'shares_billion':nvda['shares'],
        'values':sensitivity,'current_price':float(CLOSE.loc[END,'NVDA'])}
    result['news']=news
    result['candidate_sources']=candidates['sources']
    result['entry_policy']={'target_name':'revised7','entry_name':'entry',
        'deferred_usd':{'GOOGL':140,'META':210,'NVDA':350},
        'review_event':'NVIDIA scheduled 2026-11-17 earnings release 16:20 ET, call 17:00 ET; reassess next trading session after reading filings.',
        'not_automatic':'Deferred amounts remain SGOV/cash unless valuation, operating cash flow and governance evidence justify purchase; 5% direct NVDA is a target cap, not a mandatory exposure.',
        'ongoing':'Quarterly review; new cash directed to underweight exposures; a material governance/financial thesis change triggers review without waiting for quarter end.'}
    result['dollar_risk_comparison']={name:{'budget_usd':b,'historical_ann_vol_dollars':result['allocations'][key]['metrics']['five_year']['annualized_volatility']*b} for name,key,b in [('old5000','prior7',5000),('old7000','prior7',7000),('new7000','revised7',7000),('entry7000','entry',7000)]}
    with open(OUT/'portfolio_review.json','w') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False)
    pd.DataFrame(full_returns).to_csv(OUT/'portfolio_daily_returns.csv',index_label='Date')
    summary=[]
    for k,p in result['allocations'].items():
        summary.append({'id':k,'label':p['label'],'vol_2y':p['metrics']['two_year']['annualized_volatility'],
            'vol_5y':p['metrics']['five_year']['annualized_volatility'],'maxdd_5y':p['metrics']['five_year']['max_drawdown'],
            'es95_2y':p['metrics']['two_year']['daily_es95_loss'],'event_week':p['week_total_return'],
            'nvda_risk_share_2y':p['metrics']['two_year']['fraction_of_variance_by_asset'].get('NVDA',0),
            'ai_stress':p['stress_results']['ai_capex_contraction']['return']})
    df=pd.DataFrame(summary)
    df.to_csv(OUT/'portfolio_comparison.csv',index=False)
    print(df.to_string(index=False,float_format=lambda x:f'{x:.6f}'))
    print('NVDA sensitivity',sensitivity)
    print('Dollar risk',result['dollar_risk_comparison'])
    print('Saved',OUT/'portfolio_review.json')

if __name__=='__main__': main()
