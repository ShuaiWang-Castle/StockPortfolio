"""User-steered NVDA conviction review. Retains the earlier cautious comparison.

Adds transparent policy allocations, not a fitted Max-Sharpe or risk-parity model.
Run analyze_refresh.py first if its saved JSON is absent.
"""
from pathlib import Path
import copy, json, math
import numpy as np
import pandas as pd
import analyze_refresh as original

BASE=Path(__file__).resolve().parent
OUT=BASE/'analysis'
original.PRICES=pd.read_csv(BASE/'market_data_extended/adjusted_close.csv',index_col=0,parse_dates=True)
original.CLOSE=pd.read_csv(BASE/'market_data_extended/close.csv',index_col=0,parse_dates=True)
END=original.END
BUDGET=7000

# Frozen before examining their retrospective results. The user explicitly prefers
# NVIDIA's business as a core holding; 5% is no longer the recommended risk budget.
BASE_WEIGHTS={'VTI':.35,'NVDA':.15,'GOOGL':.15,'MSFT':.10,'META':.05,'BRK-B':.10,'XLV':.05,'SGOV':.05}
NEW={
 'conviction8':{'label':'NVDA核心目标方案','weights':BASE_WEIGHTS},
 'conviction_entry':{'label':'NVDA核心分步建仓','weights':{**BASE_WEIGHTS,'NVDA':.10,'SGOV':.10}},
 'conviction_nvda10':{'label':'NVDA10%比较方案','weights':{**BASE_WEIGHTS,'NVDA':.10,'VTI':.40}},
 'conviction_no_bills':{'label':'核心方案100%股票比较','weights':{k:v for k,v in {**BASE_WEIGHTS,'VTI':.40,'SGOV':0.}.items() if v>0}},
 'conviction_crm':{'label':'5%CRM替换5%MSFT','weights':{**BASE_WEIGHTS,'MSFT':.05,'CRM':.05}},
 'conviction_qcom':{'label':'5%QCOM替换5%MSFT','weights':{**BASE_WEIGHTS,'MSFT':.05,'QCOM':.05}},
 'conviction_sbux':{'label':'SBUX替换BRK比较','weights':{k:v for k,v in {**BASE_WEIGHTS,'BRK-B':0.,'SBUX':.10}.items() if v>0}},
}

def main():
 result=json.load(open(OUT/'portfolio_review.json'))
 result['meta'].update({
    'recommended_target':'conviction8','initial_entry':'conviction_entry',
    'prior_risk_limited_variant':'revised7',
    'user_steering':'User explicitly remains bullish on NVIDIA products/ecosystem independently of founder, accepts aggressive discretionary-capital risk, and wants news risk judged against the price already paid.',
    'choice_basis':'Exposure limits and business/accounting judgment; no estimated expected-return vector, no Max-Sharpe optimization, and not risk parity. NVDA direct15% is an explicit concentration choice, not an intrinsic-value conclusion.',
    'important':'Historical hypothetical comparisons selected with current information; no true prospective validation. A price decline is evidence of repricing, not proof every future adverse cash-flow outcome is fully priced.',
    'budget_note':'All dollar allocations use exactly USD7000. No additional USD500/1000 is required for percentages to work. Fractional shares assumed.'
 })
 result['allocations']['revised7']['label']='审慎比较方案（NVDA5%）'
 result['allocations']['entry']['label']='审慎比较起步（NVDA0%）'
 stresses=copy.deepcopy(result['stresses'])
 stresses['nvda_specific']['label']='NVDA追加跌幅压力（非预测）'
 stresses['ai_capex_contraction']['shocks'].update({'BRK-B':-.15,'SBUX':-.20,'QCOM':-.35,'CRM':-.30})
 stresses['ai_capex_contraction']['definition']+=' BRK-B -15%, SBUX -20%, QCOM -35%, CRM -30%; these are assumptions, not estimated hedge behavior.'
 stresses['platform_ad_repricing']['shocks'].update({'BRK-B':-.15,'SBUX':-.20,'QCOM':-.10,'CRM':-.20})
 stresses['platform_ad_repricing']['definition']+=' BRK-B -15%, SBUX -20%, QCOM -10%, CRM -20%; not guaranteed relative resilience.'
 stresses['broad_equity_bear']={'label':'广泛股票熊市压力','definition':'VTI -35%, NVDA -50%, platforms/CRM -40%, QCOM -45%, BRK-B -25%, SBUX -35%, XLV -20%, SGOV 0%; other AI suppliers -45%. No probability implied.',
     'shocks':{'VTI':-.35,'NVDA':-.50,'GOOGL':-.40,'MSFT':-.40,'META':-.40,'AMZN':-.40,'CRM':-.40,'QCOM':-.45,'BRK-B':-.25,'SBUX':-.35,'XLV':-.20,'SGOV':0.,'ANET':-.45,'TSM':-.45,'NOW':-.40,'ETN':-.35}}
 result['stresses']=stresses
 extended=json.load(open(BASE/'market_data_extended/asset_metrics.json'))
 event=pd.read_csv(BASE/'market_data_extended/event_window_returns.csv')
 result['extended_market_metrics']=extended
 # Preserve original keys needed by the workbook, enrich each with extended fields.
 for a in extended['metrics']:
  if a['window']!='two_year':continue
  t=a['ticker']; merged=result['assets'].get(t,{})
  merged.update(a)
  merged['mean_return_on_nvda_worst_decile_days']=a['mean_return_on_nvda_worst_decile_inclusive']
  merged['week_price_return_nov6_to_nov13']=float(original.CLOSE.loc[END,t]/original.CLOSE.loc['2026-11-06',t]-1)
  merged['week_total_return_nov6_to_nov13']=float(original.PRICES.loc[END,t]/original.PRICES.loc['2026-11-06',t]-1)
  result['assets'][t]=merged
 full_returns=pd.read_csv(OUT/'portfolio_daily_returns.csv',index_col=0,parse_dates=True)
 nvda=original.PRICES['NVDA'].pct_change(fill_method=None)
 nvda_two=nvda.loc[(nvda.index>pd.Timestamp(original.WINDOWS['two_year']))&(nvda.index<=END)]
 tail_dates=nvda_two.nsmallest(math.ceil(.1*len(nvda_two))).index
 for name,item in NEW.items():
  w=item['weights']; metrics={}
  for window,start in original.WINDOWS.items():
   r,ar=original.portfolio_returns(w,start)
   metrics[window]=original.stats(r,start)
   metrics[window].update(original.risk_contribution(w,ar))
   if window=='five_year':full_returns[name]=r
  r,ar=original.portfolio_returns(w,original.WINDOWS['two_year'],pd.Timestamp('2026-11-06'))
  metrics['two_year_pre_event']=original.stats(r,original.WINDOWS['two_year'])
  metrics['two_year_pre_event'].update(original.risk_contribution(w,ar))
  week=float(sum(v*(original.PRICES.loc[END,t]/original.PRICES.loc['2026-11-06',t]-1) for t,v in w.items()))
  tail=original.PRICES[list(w)].pct_change(fill_method=None).loc[tail_dates].to_numpy()@np.array(list(w.values()))
  result['allocations'][name]={'label':item['label'],'weights':w,'amounts_usd':{t:v*BUDGET for t,v in w.items()},
    'theoretical_fractional_units':{t:v*BUDGET/float(original.CLOSE.loc[END,t]) for t,v in w.items()},
    'equity_weight':1-w.get('SGOV',0),
    'direct_ai_company_weight':sum(v for t,v in w.items() if t not in ('VTI','BRK-B','XLV','SBUX','SGOV')),
    'metrics':metrics,'week_total_return':week,'week_pnl_on_7000':week*BUDGET,
    'nvda_worst_decile':{'n_days':len(tail_dates),'nvda_mean_return':float(nvda_two.loc[tail_dates].mean()),'portfolio_fixed_weight_mean_return':float(tail.mean())}}
 for p in result['allocations'].values():
  p['stress_results']={}
  for key,s in stresses.items():
   r=sum(w*s['shocks'].get(t,0) for t,w in p['weights'].items())
   p['stress_results'][key]={'return':r,'pnl_usd':r*BUDGET}
 result['entry_policy']={
   'target_name':'conviction8','entry_name':'conviction_entry',
   'deferred_usd':{'NVDA':350},
   'review_event':'NVIDIA scheduled earnings November17 16:20 ET, call17:00 ET. New financial/governance data inform the remaining5%, not the price direction alone.',
   'not_automatic':'Initial direct NVDA10% / USD700 expresses conviction before earnings. Additional5% / USD350 remains in SGOV until earnings quality, financing commitments and valuation support it. The15% target is an exposure ceiling for initial construction, not forced averaging down.',
   'ongoing':'Quarterly review; consider rebalance if a single-stock weight exceeds target by3 percentage points or NVDA direct weight exceeds20%. These are policy thresholds, not alpha guarantees. Fundamental deterioration may require review even without a price trigger.'}
 result['dollar_risk_comparison']={name:{'budget_usd':b,'historical_ann_vol_dollars':result['allocations'][key]['metrics']['five_year']['annualized_volatility']*b} for name,key,b in [('old5000','prior7',5000),('old7000','prior7',7000),('new7000','conviction8',7000),('entry7000','conviction_entry',7000)]}
 # Add QCOM/CRM reported actuals if available. A separate qualitative audit explains
 # tax/investment gains, debt, and data-center dependencies; no full DCF asserted.
 fp=BASE/'gemini_audit/financial_metrics.json'
 if fp.exists():
  fs=json.load(open(fp))
  for t,c in fs.items():
   shares=c['latest_cover_shares']['val']/1e9
   price=float(original.CLOSE.loc[END,t]); cap=price*shares
   def val(k):return c[k]['ttm']/1e9 if c.get(k) and c[k].get('ttm') is not None else None
   ni=val('net_income');cfo=val('cfo');capex=val('cash_capex');sbc=val('sbc');fcf=cfo-capex
   urls=[f"https://www.sec.gov/Archives/edgar/data/{804328 if t=='QCOM' else 1108524}/"+('000080432826000128/qcom-20260927.htm' if t=='QCOM' else '000110852426000190/crm-20260731.htm')]
   result['company_screen'][t]={'ticker':t,'name':t,'price':price,'price_date':'2026-11-13',
      'financial_period_end':c['ttm_period_end'],'shares_billion':shares,'share_date':c['latest_cover_shares']['end'],
      'revenue_billion':val('revenue'),'net_income_billion':ni,'operating_income_billion':val('operating_income'),
      'cfo_billion':cfo,'cash_capex_billion':capex,'sbc_billion':sbc,'fcf_billion':fcf,'market_cap_billion':cap,
      'pe':cap/ni if ni>0 else None,'fcf_yield':fcf/cap,'fcf_minus_sbc_yield':(fcf-sbc)/cap if sbc is not None else None,
      'source_urls':urls,'notes':'QCOM税项及净债务、CRM投资收益及融资回购需单独分析；低表面P/E不等于低估。',
      'actuals_status':'New SEC TTM facts for Gemini-claim audit; statements and price may have different dates.'}
 for fn,key in [('policy_math_nvda_audit.json','policy_math_audit'),('accounting_and_exposure_audit.json','company_claim_audit'),('brk_accounting_check.json','berkshire_review')]:
  f=BASE/'gemini_audit'/fn
  if f.exists():result[key]=json.load(open(f))
 result['news']['portfolio_implications_analysis_not_fact']=[
    'The user prioritizes NVIDIA business conviction; direct10–15% is a defensible explicit aggressive risk budget, replacing the earlier cautious5% ceiling.',
    'Leadership and investigation facts affect the range of cash flows/required returns; the size of that effect is uncertain and must not be treated as a known extra loss.',
    'A lower price can compensate for risk. A retrospective price fall alone does not demonstrate that every relevant future scenario is fully reflected.'
 ]
 json.dump(result,open(OUT/'portfolio_conviction_review.json','w'),ensure_ascii=False,indent=2,allow_nan=False)
 full_returns.to_csv(OUT/'portfolio_conviction_daily_returns.csv',index_label='Date')
 summary=[]
 for k,p in result['allocations'].items():
  summary.append({'id':k,'label':p['label'],'vol2':p['metrics']['two_year']['annualized_volatility'],'vol5':p['metrics']['five_year']['annualized_volatility'],
      'dd5':p['metrics']['five_year']['max_drawdown'],'cagr5':p['metrics']['five_year']['historical_cagr'],'es2':p['metrics']['two_year']['daily_es95_loss'],
      'NVDA_RC2':p['metrics']['two_year']['fraction_of_variance_by_asset'].get('NVDA',0),
      'week':p['week_total_return'],'ai_stress':p['stress_results']['ai_capex_contraction']['return']})
 df=pd.DataFrame(summary);df.to_csv(OUT/'portfolio_conviction_comparison.csv',index=False)
 print(df[df['id'].isin(['prior7','revised7']+list(NEW))].to_string(index=False,float_format=lambda x:f'{x:.5f}'))
 print('New valuations',{t:{k:result['company_screen'][t][k] for k in ('price','pe','fcf_yield','fcf_minus_sbc_yield')} for t in ('QCOM','CRM') if t in result['company_screen']})

if __name__=='__main__':main()
