import fs from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { Workbook, SpreadsheetFile } from '@oai/artifact-tool';

const base='/workspace/scratch/7569b1d31554';
const work=`${base}/portfolio_refresh_20261113`;
const outputDir=`${base}/outputs/ai_portfolio_20261113`;
const modelText=await fs.readFile(`${work}/analysis/portfolio_conviction_review.json`,'utf8');
const review=JSON.parse(modelText);
const candidates=JSON.parse(await fs.readFile(`${work}/candidate_research.json`,'utf8'));
const provenance=JSON.parse(await fs.readFile(`${work}/market_data_extended/provenance.json`,'utf8'));
const audit=JSON.parse(await fs.readFile(`${work}/gemini_audit/policy_math_nvda_audit.json`,'utf8'));
const brk=JSON.parse(await fs.readFile(`${work}/gemini_audit/brk_accounting_check.json`,'utf8'));
const companyAudit=JSON.parse(await fs.readFile(`${work}/gemini_audit/accounting_and_exposure_audit.json`,'utf8'));
const corrCsv=(await fs.readFile(`${work}/market_data_extended/two_year_correlation.csv`,'utf8')).trim().split(/\r?\n/).map(x=>x.split(','));
const corrByTicker=Object.fromEntries(corrCsv.slice(1).map(r=>[r[0],r]));
const csv=(await fs.readFile(`${work}/market_data_extended/adjusted_close.csv`,'utf8')).trim().split(/\r?\n/).map(x=>x.split(','));
const targetId=review.meta.recommended_target,entryId=review.meta.initial_entry;
const target=review.allocations[targetId],entry=review.allocations[entryId];
const portfolioIds=Object.keys(review.allocations);
const displayed=['VTI','NVDA','GOOGL','MSFT','META','BRK-B','XLV','SGOV'];
const portfolioTickers=[...new Set([...displayed,...portfolioIds.flatMap(k=>Object.keys(review.allocations[k].weights))])];
const pLast=3+portfolioTickers.length;
const companyOrder=['GOOGL','MSFT','META','NVDA','AMZN','TSM','AVGO','AMD','MU','VRT','PLTR','ANET','NOW','ETN','QCOM','CRM','ORCL','ASML'];
const market=review.extended_market_metrics.metrics.filter(x=>x.window==='two_year');
const marketMap=Object.fromEntries(market.map(x=>[x.ticker,x]));
const selectedIds=['prior7','revised7','conviction8','conviction_entry','conviction_nvda10','conviction_no_bills','conviction_crm','conviction_qcom','conviction_sbux'];
const labels={...Object.fromEntries(portfolioIds.map(k=>[k,review.allocations[k].label])),prior7:'上次七资产',revised7:'审慎比较 NVDA5%',conviction8:'本次核心目标 NVDA15%',conviction_entry:'当前进入 NVDA10%',conviction_nvda10:'NVDA10%+更多VTI',conviction_no_bills:'核心方案100%股票',conviction_crm:'5%CRM替换MSFT',conviction_qcom:'5%QCOM替换MSFT',conviction_sbux:'SBUX替换BRK'};
const allRiskRows=['two_year','five_year'].flatMap(window=>portfolioIds.map(id=>({id,window,period:window==='two_year'?'2年':'5年',m:review.allocations[id].metrics[window]})));
const selectedRiskRows=['two_year','five_year'].flatMap(window=>selectedIds.map(id=>({id,window,period:window==='two_year'?'2年':'5年',m:review.allocations[id].metrics[window]})));
const stressList=Object.entries(review.stresses);
const corrTickers=displayed;
const wb=Workbook.create();
const sheets=Object.fromEntries(['配置','风险比较','公司筛选','新闻与方法','数据与来源'].map(n=>[n,wb.worksheets.add(n)]));
const colors={ink:'#172C4B',body:'#263445',muted:'#66758A',brand:'#254766',header:'#365A79',light:'#EAF0F5',input:'#174EA6',linked:'#197346',warn:'#FFF0CC',border:'#C6D1DC'};
const fmt={pct:'0.0%;(0.0%);"-"',num:'#,##0.0;(#,##0.0);"-"',int:'#,##0;(#,##0);"-"',usd:'"$"#,##0;("$"#,##0);"-"',price:'"$"0.00;("$"0.00);"-"',mult:'0.0"x"',corr:'0.00;(0.00);"-"'};
const col=n=>{let s='';for(;n>0;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;};
const date=x=>/^\d{4}-\d{2}-\d{2}/.test(x??'')?new Date(`${String(x).slice(0,10)}T12:00:00Z`):null;
const write=(s,r,c,a)=>{if(a.length)s.getRange(`${col(c)}${r}:${col(c+a[0].length-1)}${r+a.length-1}`).values=a.map(row=>row.map(v=>v??null));};
const cell=(s,a,v)=>s.getRange(a).values=[[v]];
const formula=(s,a,v)=>s.getRange(a).formulas=[[v]];
function init(s,n=100,last='R'){
 s.showGridLines=false;s.getRange(`A1:${last}${n}`).format.font={name:'Arial',size:10,color:colors.body};
 s.getRange(`A1:${last}${n}`).format.verticalAlignment='center';s.getRange(`A1:${last}${n}`).format.rowHeight=23;
 s.getRange(`A1:B${n}`).format.columnWidth=2.4;s.getRange(`C1:${last}${n}`).format.columnWidth=13;
 s.getRange('C2').format.font={name:'Arial',size:15,bold:true,color:colors.ink};
 s.getRange(`C3:${last}3`).format.borders={bottom:{style:'thin',color:colors.border}};
}
function title(s,t){cell(s,'C2',t);}
function header(s,r,c,labels){write(s,r,c,[labels]);const a=s.getRange(`${col(c)}${r}:${col(c+labels.length-1)}${r}`);a.format={fill:colors.header,font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},horizontalAlignment:'center',verticalAlignment:'center',wrapText:true};a.format.rowHeight=34;}
function section(s,r,t,last='N'){cell(s,`C${r}`,t);s.getRange(`C${r}:${last}${r}`).format={fill:colors.light,font:{name:'Arial',size:10,bold:true,color:colors.ink}};s.getRange(`C${r}:${last}${r}`).format.rowHeight=26;}
function note(s,r,t){cell(s,`C${r}`,t);s.getRange(`C${r}`).format.font={name:'Arial',size:10,color:colors.muted};}
function total(s,r,last='I'){s.getRange(`C${r}:${last}${r}`).format={font:{bold:true,color:colors.ink},borders:{top:{style:'thin',color:colors.border}}};}
const rows={weightsHead:8,financeHead:31,assetsHead:55,historyHead:100,stressHead:139,shockHead:148,corrHead:158,exposureHead:176,oneYearHead:185,brkHead:192,sourcesHead:231,priceHead:421};
const inp=sheets['数据与来源'];init(inp,1800,col(3+csv[0].length-1));title(inp,'原始输入、会计计算与来源');
inp.getRange('C1:C1800').format.columnWidth=20;inp.getRange('T1:T1800').format.columnWidth=49;inp.getRange('U1:U1800').format.columnWidth=3;inp.getRange('V1:V1800').format.columnWidth=75;
note(inp,4,'价格截至2026-11-13收盘。财务单位：十亿美元；股数：十亿股（BRK专表例外）；价格：美元。');
note(inp,5,'蓝色为输入。修改金额、权重或情景不会重新计算固定历史统计；历史结果需运行配套分析脚本。');
inp.freezePanes.freezeRows(8);inp.freezePanes.freezeColumns(3);
section(inp,7,'全部比较方案权重',col(pLast));header(inp,rows.weightsHead,3,['方案',...portfolioTickers]);
const pRow={};portfolioIds.forEach((id,i)=>{const r=rows.weightsHead+1+i;pRow[id]=r;write(inp,r,3,[[labels[id],...portfolioTickers.map(t=>review.allocations[id].weights[t]??0)]]);});
inp.getRange(`D9:${col(pLast)}${8+portfolioIds.length}`).setNumberFormat(fmt.pct);inp.getRange(`D9:${col(pLast)}${8+portfolioIds.length}`).format.font={color:colors.input};
const sourceRows=[],sourceSeen=new Set();
function addSource(kind,label,asof,url){if(url&&!sourceSeen.has(url)){sourceSeen.add(url);sourceRows.push([kind,label,date(asof),url]);}}
const notes={GOOGL:'投资收益抬高净利；资本支出压低现金FCF。',MSFT:'投资收益和融资租赁需单独审视。',META:'税务、诉讼和新增融资需复核。',NVDA:'盈利含投资收益；应收、担保与治理风险。',AMZN:'投资收益抬高净利；毛现金资本支出FCF为负。',TSM:'ADR等价股数；币种与利息分类不同。',AVGO:'ASIC与网络仍承受AI投入和客户融资风险。',AMD:'GPU竞争与高估值，不是NVDA稳定对冲。',MU:'内存周期与资本投入。',VRT:'供电散热；项目审批、建设、订单与估值风险。',PLTR:'高估值、SBC与云服务成本。',ANET:'大型云客户集中，估值不低。',NOW:'严格现金FCF未加回收购费用；SBC较高。',ETN:'缺失经营利润/SBC保留n.a.。',QCOM:'FY26净利包含约57亿美元税务利益，且并非净现金。',CRM:'投资收益抬高净利；ASR股数使市值/净利不同于价格/稀释EPS。',ORCL:'本轮只作业务观察，未执行财务估值。',ASML:'本轮只作业务观察，未执行财务估值。'};
const fRows={};section(inp,29,'公司财务输入与估值公式','V');header(inp,rows.financeHead,3,['代码','财报截止','股数日期','收盘价','估值股数','收入','经营利润','普通股净利','经营现金流','毛现金资本支出','股权激励','近似市值','现金FCF','市值/TTM净利','经营利润率','FCF收益率','FCF−SBC收益率','口径说明','','财务来源']);
companyOrder.forEach((t,i)=>{
 const r=rows.financeHead+1+i;fRows[t]=r;const x=review.company_screen[t]??{};const urls=x.source_urls??[];
 write(inp,r,3,[[t,date(x.financial_period_end),date(x.share_date),x.price??marketMap[t]?.last_close,x.shares_billion,x.revenue_billion,x.operating_income_billion,x.net_income_billion,x.cfo_billion,x.cash_capex_billion,x.sbc_billion,null,null,null,null,null,null,notes[t],null,urls[0]]]);
 for(const [cc,ff] of Object.entries({N:`=IF(AND(ISNUMBER(F${r}),ISNUMBER(G${r})),F${r}*G${r},"n.a.")`,O:`=IF(AND(ISNUMBER(K${r}),ISNUMBER(L${r})),K${r}-L${r},"n.a.")`,P:`=IF(AND(ISNUMBER(N${r}),ISNUMBER(J${r})),IF(J${r}>0,N${r}/J${r},"n.m."),"n.a.")`,Q:`=IF(AND(ISNUMBER(I${r}),ISNUMBER(H${r})),IF(H${r}=0,"n.a.",I${r}/H${r}),"n.a.")`,R:`=IF(AND(ISNUMBER(O${r}),ISNUMBER(N${r})),IF(N${r}=0,"n.a.",O${r}/N${r}),"n.a.")`,S:`=IF(AND(ISNUMBER(O${r}),ISNUMBER(M${r}),ISNUMBER(N${r})),IF(N${r}=0,"n.a.",(O${r}-M${r})/N${r}),"n.a.")`}))formula(inp,`${cc}${r}`,ff);
 urls.forEach(u=>addSource('财报',t,x.financial_period_end,u));
});
const fStart=rows.financeHead+1,fEnd=rows.financeHead+companyOrder.length;
inp.getRange(`D${fStart}:E${fEnd}`).setNumberFormat('yyyy-mm-dd');inp.getRange(`F${fStart}:F${fEnd}`).setNumberFormat(fmt.price);inp.getRange(`G${fStart}:G${fEnd}`).setNumberFormat('0.000');inp.getRange(`H${fStart}:O${fEnd}`).setNumberFormat('#,##0.00;(#,##0.00);"-"');inp.getRange(`P${fStart}:P${fEnd}`).setNumberFormat(fmt.mult);inp.getRange(`Q${fStart}:S${fEnd}`).setNumberFormat(fmt.pct);inp.getRange(`D${fStart}:M${fEnd}`).format.font={color:colors.input};inp.getRange(`N${fStart}:S${fEnd}`).format.font={color:'#000000'};inp.getRange(`D${fStart}:S${fEnd}`).format.horizontalAlignment='right';inp.getRange(`T${fStart}:T${fEnd}`).format.wrapText=true;inp.getRange(`V${fStart}:V${fEnd}`).format.wrapText=true;inp.getRange(`C${fStart}:V${fEnd}`).format.rowHeight=46;
section(inp,53,'39项资产的固定两年历史结果','O');header(inp,rows.assetsHead,3,['代码','收盘价','年化波动','与NVDA相关','对VTI贝塔','最大回撤','事件周总回报','NVDA差日均回报','尾部共跌比例','完整窗口']);
const mRows={};market.forEach((m,i)=>{const r=rows.assetsHead+1+i;mRows[m.ticker]=r;write(inp,r,3,[[m.ticker,m.last_close,m.ann_vol,m.rho_nvda,m.beta_vti,m.max_drawdown,review.assets[m.ticker]?.week_total_return_nov6_to_nov13,m.mean_return_on_nvda_worst_decile_inclusive,m.empirical_conditional_coexceedance_q10,m.complete_window?'是':'否']]);});
const mStart=rows.assetsHead+1,mEnd=rows.assetsHead+market.length;
inp.getRange(`D${mStart}:D${mEnd}`).setNumberFormat(fmt.price);inp.getRange(`E${mStart}:E${mEnd}`).setNumberFormat(fmt.pct);inp.getRange(`F${mStart}:G${mEnd}`).setNumberFormat(fmt.corr);inp.getRange(`H${mStart}:K${mEnd}`).setNumberFormat(fmt.pct);inp.getRange(`D${mStart}:K${mEnd}`).format.font={color:colors.input};
note(inp,96,'差日均值使用NVDA最差ceil(10%N)日；尾部共跌比例使用各自严格10%分位阈值，二者口径不同。');
section(inp,98,'全部组合固定历史结果；不是收益预测','O');header(inp,rows.historyHead,3,['方案','期间','历史CAGR','年化波动','最大回撤','日ES95损失','NVDA直接方差占比','观察数','事件周总回报']);
const riskSourceRow={};allRiskRows.forEach((x,i)=>{const r=rows.historyHead+1+i;riskSourceRow[`${x.id}_${x.window}`]=r;write(inp,r,3,[[labels[x.id],x.period,x.m.historical_cagr,x.m.annualized_volatility,x.m.max_drawdown,x.m.daily_es95_loss,x.m.fraction_of_variance_by_asset.NVDA??0,x.m.n_returns,review.allocations[x.id].week_total_return]]);});
const hStart=rows.historyHead+1,hEnd=rows.historyHead+allRiskRows.length;
inp.getRange(`E${hStart}:I${hEnd}`).setNumberFormat(fmt.pct);inp.getRange(`J${hStart}:J${hEnd}`).setNumberFormat(fmt.int);inp.getRange(`K${hStart}:K${hEnd}`).setNumberFormat(fmt.pct);inp.getRange(`E${hStart}:K${hEnd}`).format.font={color:colors.input};
section(inp,137,'假设压力情景结果','O');header(inp,rows.stressHead,3,['情景','上次方案','核心目标','当前进入','假设来源']);
stressList.forEach(([id,s],i)=>{const r=rows.stressHead+1+i;write(inp,r,3,[[s.label,null,null,null,'下方数字输入']]);for(const [dest,pid]of[['D','prior7'],['E',targetId],['F',entryId]])formula(inp,`${dest}${r}`,`=SUMPRODUCT($D$${pRow[pid]}:$${col(pLast)}$${pRow[pid]},D${rows.shockHead+1+i}:${col(pLast)}${rows.shockHead+1+i})`);});
inp.getRange(`D140:F${139+stressList.length}`).setNumberFormat(fmt.pct);
section(inp,146,'压力冲击输入（可编辑；均非预测）',col(pLast));header(inp,rows.shockHead,3,['情景',...portfolioTickers]);stressList.forEach(([id,s],i)=>write(inp,rows.shockHead+1+i,3,[[s.label,...portfolioTickers.map(t=>s.shocks[t]??0)]]));inp.getRange(`D149:${col(pLast)}${148+stressList.length}`).setNumberFormat(fmt.pct);inp.getRange(`D149:${col(pLast)}${148+stressList.length}`).format.font={color:colors.input};
section(inp,157,'核心资产两年日收益相关系数','L');header(inp,rows.corrHead,3,['代码',...corrTickers]);write(inp,rows.corrHead+1,3,corrTickers.map(a=>[a,...corrTickers.map(b=>Number(corrByTicker[a][corrCsv[0].indexOf(b)]))]));inp.getRange(`D159:${col(3+corrTickers.length)}${158+corrTickers.length}`).setNumberFormat(fmt.corr);
section(inp,175,'ETF穿透限制','L');header(inp,rows.exposureHead,3,['输入','数值','说明']);write(inp,177,3,[['NVDA完整穿透','n.a.','未取得同日VTI完整持仓；直接15%不是总发行人敞口。']]);
section(inp,184,'一年回撤比较','I');header(inp,rows.oneYearHead,3,['项目','上次方案','核心目标','当前进入']);write(inp,186,3,[['1年最大回撤',review.allocations.prior7.metrics.one_year.max_drawdown,target.metrics.one_year.max_drawdown,entry.metrics.one_year.max_drawdown]]);inp.getRange('D186:F186').setNumberFormat('0.00%;(0.00%);"-"');
section(inp,190,'BRK-B专项：账面价值、经营盈利与流动性','L');header(inp,rows.brkHead,3,['输入','数值','口径']);header(inp,rows.brkHead,7,['计算','结果']);
const bi=brk.inputs;
const brkInput=[['收盘价',bi.price_usd,'美元'],['期末A股',bi.september30_class_a_outstanding,'2026-09-30，股'],['期末B股',bi.september30_class_b_outstanding,'2026-09-30，股'],['A转B经济比例',bi.economic_b_shares_per_a_share,'1500，不是投票权比例'],['母公司股东权益',bi.berkshire_shareholders_equity_billion,'十亿美元；不含少数股东'],['FY25经营盈利',bi.operating_earnings_after_tax_billion.FY2025,'公司定义税后经营盈利'],['9M26经营盈利',bi.operating_earnings_after_tax_billion['9M2026'],'公司定义税后经营盈利'],['9M25经营盈利',bi.operating_earnings_after_tax_billion['9M2025'],'公司定义税后经营盈利'],['FY25 GAAP净利',bi.gaap_net_income_attributable_billion.FY2025,'十亿美元'],['9M26 GAAP净利',bi.gaap_net_income_attributable_billion['9M2026'],'十亿美元'],['9M25 GAAP净利',bi.gaap_net_income_attributable_billion['9M2025'],'十亿美元'],['最新A股',bi.latest_cover_class_a_outstanding,'2026-10-28，股'],['最新B股',bi.latest_cover_class_b_outstanding,'2026-10-28，股'],['保险及其他现金',bi.insurance_and_other_cash_cash_equivalents_billion,'十亿美元'],['短期国库券',bi.insurance_and_other_short_term_treasury_bills_billion,'十亿美元'],['未结算购券应付',bi.unsettled_treasury_purchase_payables_billion,'十亿美元'],['保险浮存金',bi.insurance_float_billion,'资金负债，不是额外股东现金']];
write(inp,193,3,brkInput);inp.getRange('D193:D209').format.font={color:colors.input};inp.getRange('D193:D209').setNumberFormat('#,##0.000');inp.getRange('C193:C209').format.wrapText=true;inp.getRange('E193:E209').format.wrapText=false;
const brkFormula=[['近似总市值','=D193*(D204*D196+D205)/1000000000'],['期末B等价账面价值','=D197*1000000000/(D194*D196+D195)'],['股价/期末B账面价值','=D193/H194'],['TTM经营盈利','=D198+D199-D200'],['总市值/TTM经营盈利','=H193/H196'],['TTM GAAP净利','=D201+D202-D203'],['GAAP P/E','=H193/H198'],['净购券后现金及国库券','=D206+D207-D208']];
brkFormula.forEach(([label,f],i)=>{cell(inp,`G${193+i}`,label);formula(inp,`H${193+i}`,f);});inp.getRange('G193:G200').format.wrapText=true;inp.getRange('C193:H200').format.rowHeight=36;inp.getRange('H193:H200').setNumberFormat('0.00');
note(inp,213,'经营盈利为税后非GAAP公司指标，包含保险投资利息收入；不能等同EBIT或FCF。');note(inp,215,'现金与国库券不是全部可分配现金；保险浮存金及经营资本需求不能忽略。');
for(const [k,s]of Object.entries(candidates.sources))addSource('公司披露',k,s.date,s.url);
for(const e of review.news.events)for(const s of e.sources)addSource('新闻与监管',e.id,e.announcement_date??e.publication_date??e.event_date,s.url);
for(const [k,s]of Object.entries(audit.sources))addSource('论点核验',k,s.date,s.url);
for(const [k,s]of Object.entries(companyAudit.sources??{}))addSource('会计核验',k,s.date??s.period_end,s.url);
for(const [k,s]of Object.entries(brk.sources))addSource('BRK会计',k,s.release_date??s.period_end,s.url);
for(const [t,s]of Object.entries(provenance.sources))addSource('股价',t,'2026-11-13',s.url);
section(inp,229,'来源登记','W');header(inp,rows.sourcesHead,3,['类型','资料','日期']);header(inp,rows.sourcesHead,7,['URL']);write(inp,232,3,sourceRows.map(r=>r.slice(0,3)));write(inp,232,7,sourceRows.map(r=>[r[3]]));inp.getRange(`E232:E${231+sourceRows.length}`).setNumberFormat('yyyy-mm-dd');inp.getRange(`D232:D${231+sourceRows.length}`).format.wrapText=true;inp.getRange(`C232:G${231+sourceRows.length}`).format.rowHeight=32;
if(rows.sourcesHead+sourceRows.length>=rows.priceHead-5)throw new Error('Source registry overlaps prices');
const histTickers=csv[0].slice(1);section(inp,419,'39项资产调整后收盘价（供应商分红与拆股调整）',col(3+histTickers.length));header(inp,rows.priceHead,3,['日期',...histTickers]);write(inp,422,3,csv.slice(1).map(r=>[date(r[0]),...r.slice(1).map(x=>x===''?null:Number(x))]));inp.getRange(`C422:C${420+csv.length}`).setNumberFormat('yyyy-mm-dd');inp.getRange(`D422:${col(3+histTickers.length)}${420+csv.length}`).setNumberFormat('0.0000');

const alloc=sheets['配置'];init(alloc,50,'R');title(alloc,'AI投资组合｜NVDA核心版本');alloc.tabColor=colors.brand;
alloc.getRange('C1:C50').format.columnWidth=12;alloc.getRange('D1:D50').format.columnWidth=21;alloc.getRange('E1:I50').format.columnWidth=14;alloc.getRange('J1:J50').format.columnWidth=3;alloc.getRange('K1:R50').format.columnWidth=9;
cell(alloc,'C4','投入资金（USD）');cell(alloc,'E4',review.meta.budget_usd);alloc.getRange('E4').setNumberFormat(fmt.usd);alloc.getRange('E4').format={fill:'#E9F1FC',font:{color:colors.input,bold:true}};cell(alloc,'G4','收盘日期');cell(alloc,'H4',date('2026-11-13'));alloc.getRange('H4').setNumberFormat('yyyy-mm-dd');
note(alloc,6,'目标95%股票、45%直接AI公司；当前先进入90%股票、40%直接AI公司。');
header(alloc,9,3,['代码','配置作用','核心目标','目标金额','当前进入','当前金额','待复核差额']);
const roles={VTI:'美国股票基础仓',NVDA:'AI算力与生态核心',GOOGL:'搜索、云与AI平台',MSFT:'云与企业软件',META:'广告变现与AI应用','BRK-B':'保险与多行业经营',XLV:'医疗行业分散',SGOV:'短期美国国债储备'};
displayed.forEach((t,i)=>{const r=10+i,c=col(4+portfolioTickers.indexOf(t));write(alloc,r,3,[[t,roles[t]]]);formula(alloc,`E${r}`,`='数据与来源'!${c}${pRow[targetId]}`);formula(alloc,`F${r}`,`=E${r}*$E$4`);formula(alloc,`G${r}`,`='数据与来源'!${c}${pRow[entryId]}`);formula(alloc,`H${r}`,`=G${r}*$E$4`);formula(alloc,`I${r}`,`=F${r}-H${r}`);});
cell(alloc,'C19','合计');for(const c of ['E','F','G','H','I'])formula(alloc,`${c}19`,`=SUM(${c}10:${c}17)`);total(alloc,19);alloc.getRange('E10:E19').setNumberFormat(fmt.pct);alloc.getRange('G10:G19').setNumberFormat(fmt.pct);alloc.getRange('F10:F19').setNumberFormat(fmt.usd);alloc.getRange('H10:I19').setNumberFormat(fmt.usd);alloc.getRange('C10:I17').format.rowHeight=28;
note(alloc,21,'新增资金配置参考；未假定你已经持有这些资产，也未下达交易。');note(alloc,23,'只预留NVDA额外5%（350美元）：11月17日财报后复核，不自动买入。');note(alloc,25,'降低价格可以补偿部分风险，但不能仅凭跌幅断言所有风险已被计价。');note(alloc,27,'改变预算会更新金额。按比例分配不要求额外加钱；碎股可用性需由券商确认。');
section(alloc,30,'仓位边界与复核规则','R');
const rules=['期限暂按3–5年以上假设，尚未经你确认；核心目标允许更大回撤。','NVDA直接15%是主动集中选择；当前10%表达看好业务，额外5%仍需证据支持。','VTI内含AI企业；BRK也有股票与国债投资。直接比例不是最终经济敞口。','季度复核；单股偏离目标3个百分点或NVDA直接超过20%时考虑再平衡。','基本面恶化不必等待价格阈值。再平衡不保证alpha，历史统计不保证未来收益。','SGOV不是银行存款；BRK与XLV也不是NVDA下跌时必然上涨的对冲。'];rules.forEach((t,i)=>note(alloc,32+i*2,t));
const chart=alloc.charts.add('bar',[alloc.getRange('C9:C17'),alloc.getRange('E9:E17'),alloc.getRange('G9:G17')]);chart.title='核心目标与当前进入';chart.titleTextStyle.typeface='Arial';chart.titleTextStyle.fontSize=13;chart.setPosition('K9','R26');chart.legend={position:'top',textStyle:{typeface:'Arial',fontSize:10}};chart.xAxis={axisType:'textAxis',textStyle:{typeface:'Arial',fontSize:10}};chart.yAxis={numberFormatCode:'0%',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:10}};chart.series.items[0].fill=colors.brand;chart.series.items[1].fill='#9BB4CC';

const risk=sheets['风险比较'];init(risk,90,'L');title(risk,'历史比较与压力损失');risk.tabColor=colors.brand;risk.getRange('C1:C90').format.columnWidth=28;risk.getRange('D1:D90').format.columnWidth=18;risk.getRange('E1:L90').format.columnWidth=14;
note(risk,5,'本次核心目标提高主动风险：5年波动约21.0%，最大回撤约33.1%；两者均高于上次七资产。');note(risk,6,'CAGR仅描述历史。这不是Max Sharpe或风险平价组合；没有宣称消除左尾损失。');
header(risk,8,3,['方案','样本','历史CAGR','年化波动','最大回撤','日ES95损失','NVDA直接方差占比','观察数']);
selectedRiskRows.forEach((x,i)=>{const r=9+i,src=riskSourceRow[`${x.id}_${x.window}`];for(let k=0;k<8;k++)formula(risk,`${col(3+k)}${r}`,`='数据与来源'!${col(3+k)}${src}`);if(x.id===targetId)risk.getRange(`C${r}:J${r}`).format={fill:colors.light,font:{bold:true,color:colors.ink}};});
const riskEnd=8+selectedRiskRows.length;risk.getRange(`E9:I${riskEnd}`).setNumberFormat(fmt.pct);risk.getRange(`J9:J${riskEnd}`).setNumberFormat(fmt.int);risk.getRange(`C9:J${riskEnd}`).format.rowHeight=25;risk.getRange('C18:J18').format.borders={top:{style:'thin',color:colors.border}};
section(risk,30,'人为联合冲击：只表示条件损益，不附带概率','L');header(risk,32,3,['情景','上次方案收益','核心目标收益','当前进入收益','核心目标损益','当前进入损益']);
stressList.forEach(([id,s],i)=>{const r=33+i,src=140+i;for(let k=0;k<4;k++)formula(risk,`${col(3+k)}${r}`,`='数据与来源'!${col(3+k)}${src}`);formula(risk,`G${r}`,`=E${r}*'配置'!$E$4`);formula(risk,`H${r}`,`=F${r}*'配置'!$E$4`);});risk.getRange('D33:F36').setNumberFormat(fmt.pct);risk.getRange('G33:H36').setNumberFormat(fmt.usd);
const stressNotes=['NVDA事件：NVDA再跌40%，VTI跌2.5%，其余不变；VTI跌幅仅是假设。','AI投入收缩：VTI跌25%，NVDA跌50%，平台跌30%，BRK跌15%。','广告重估：VTI跌20%，GOOGL/META跌30%，BRK跌15%。','广泛熊市：VTI跌35%，NVDA跌50%，平台跌40%，BRK跌25%。','全部冲击列于输入页；这些数值不是持仓穿透、概率估计或损失上限。'];stressNotes.forEach((t,i)=>note(risk,38+i,t));
section(risk,46,'核心资产两年日收益相关系数','L');header(risk,48,3,['代码',...corrTickers]);corrTickers.forEach((t,i)=>{for(let j=0;j<=corrTickers.length;j++)formula(risk,`${col(3+j)}${49+i}`,`='数据与来源'!${col(3+j)}${159+i}`);});const heat=risk.getRange(`D49:${col(3+corrTickers.length)}${48+corrTickers.length}`);heat.setNumberFormat(fmt.corr);heat.conditionalFormats.add('colorScale',{colors:['#E6EDF7','#FFFFFF','#D3A06A'],thresholds:['min',{type:'num',value:0},'max']});
note(risk,59,'低相关或历史相对抗跌不等于负相关对冲；危机下关系会改变。');note(risk,61,'NVDA直接15%贡献约29.5%的两年方差，尚未计入VTI内的NVDA；风险并非均分。');formula(risk,'C63',`="1年最大回撤：上次"&TEXT('数据与来源'!D186,"0.00%")&"，核心目标"&TEXT('数据与来源'!E186,"0.00%")&"，当前进入"&TEXT('数据与来源'!F186,"0.00%")&"。"`);risk.getRange('C63').format.font={color:colors.muted};risk.freezePanes.freezeRows(8);risk.freezePanes.freezeColumns(3);

const screen=sheets['公司筛选'];init(screen,65,'O');title(screen,'业务角色与会计估值');screen.tabColor=colors.brand;screen.getRange('C1:C65').format.columnWidth=10;screen.getRange('D1:D65').format.columnWidth=19;screen.getRange('E1:M65').format.columnWidth=13;screen.getRange('N1:N65').format.columnWidth=3;screen.getRange('O1:O65').format.columnWidth=48;
note(screen,5,'11月13日价格 × 已报告TTM；表面低P/E可能来自投资收益或税项，不是内在价值结论。');header(screen,8,3,['代码','业务角色','收盘价','市值/TTM净利','经营利润率','现金FCF率','FCF−SBC率','2年波动','与NVDA相关','事件周总回报','财报截止']);cell(screen,'O8','配置与会计判断');screen.getRange('O8').format.font={bold:true,color:colors.ink};
const roleMap={GOOGL:'搜索与云平台',MSFT:'云与企业软件',META:'广告与AI应用',NVDA:'GPU与生态',AMZN:'云与电商',TSM:'晶圆制造',AVGO:'ASIC与网络',AMD:'GPU与CPU',MU:'高带宽内存',VRT:'供电与散热',PLTR:'数据与AI软件',ANET:'以太网交换',NOW:'企业工作流',ETN:'电力设备',QCOM:'端侧芯片与许可',CRM:'企业CRM与AI代理',ORCL:'数据库与AI云',ASML:'光刻设备'};
const verdict={GOOGL:'目标15%；投资重估影响净利，云和搜索仍有资本支出风险。',MSFT:'目标10%；企业现金流与AI投入并存，核查融资租赁。',META:'目标5%；增加应用变现来源，广告周期仍与GOOGL重叠。',NVDA:'目标15%，先10%；看好业务并承担集中风险，剩余5%复核。',AMZN:'暂不单列；现金投入较大，仍通过VTI间接持有。',TSM:'优质制造观察；不能认为所有芯片或所有工厂都在台湾。',AVGO:'观察ASIC；与NVDA仍有共同AI资本开支风险。',AMD:'不作稳定对冲；竞争与估值需独立判断。',MU:'内存周期观察；不因新增金额而必须加入。',VRT:'保留观察；电力约束可能延迟建设，也可能支持效率投资。',PLTR:'云服务成本真实存在；高估值不适合用作低风险对冲。',ANET:'盈利较好；大型客户集中，不追短期相对表现。',NOW:'工作流业务更差异化；高SBC与并购仍需估价。',ETN:'电力设备代表；受益建设并不消除周期风险。',QCOM:'观察5%替换方案；税项推高净利，且不只经营端侧业务。',CRM:'观察5%替换方案；投资收益、净债务及融资回购需复核。',ORCL:'只作业务观察；本轮未重跑完整财务估值。',ASML:'只作业务观察；出口与客户投资周期需跟踪。'};
companyOrder.forEach((t,i)=>{const r=9+i,f=fRows[t],m=mRows[t];write(screen,r,3,[[t,roleMap[t]]]);for(const [dest,src]of Object.entries({E:'F',F:'P',G:'Q',H:'R',I:'S',M:'D'}))formula(screen,`${dest}${r}`,`=IF(ISBLANK('数据与来源'!${src}${f}),"n.a.",'数据与来源'!${src}${f})`);for(const [dest,src]of Object.entries({J:'E',K:'F',L:'I'}))formula(screen,`${dest}${r}`,`='数据与来源'!${src}${m}`);cell(screen,`O${r}`,verdict[t]);});const sEnd=8+companyOrder.length;screen.getRange(`E9:E${sEnd}`).setNumberFormat(fmt.price);screen.getRange(`F9:F${sEnd}`).setNumberFormat(fmt.mult);screen.getRange(`G9:J${sEnd}`).setNumberFormat(fmt.pct);screen.getRange(`K9:K${sEnd}`).setNumberFormat(fmt.corr);screen.getRange(`L9:L${sEnd}`).setNumberFormat(fmt.pct);screen.getRange(`M9:M${sEnd}`).setNumberFormat('yyyy-mm-dd');screen.getRange(`E9:M${sEnd}`).format.horizontalAlignment='right';screen.getRange(`O9:O${sEnd}`).format.wrapText=true;screen.getRange(`C9:O${sEnd}`).format.rowHeight=36;
section(screen,30,'估值口径与边界','O');
const valNotes=['近似市值=股价×估值股数；TSM使用ADR等价股数，多类别股份按同价近似，股数日期不同。','现金FCF=经营现金流−毛现金资本支出；未扣收购或融资租赁本金，不等同可分配现金或FCFF。','FCF−SBC是股东经济成本敏感性；不能与完整股数稀释或现金替代成本重复扣减。','GOOGL/NVDA/CRM投资收益、META税务诉讼、QCOM税项均可能扭曲表面P/E。','表中盈利倍数=当前近似市值/TTM净利。CRM约18.6倍；价格/TTM稀释EPS约19.9倍，受ASR股数影响。','缺失数据保留n.a.，不是零。本轮没有对全部公司重新运行DCF。','配置权重不等于估值买入信号；仍承担增长兑现、融资与估值下降的风险。'];valNotes.forEach((t,i)=>note(screen,32+i*2,t));
section(screen,47,'BRK-B采用不同的会计观察口径','O');header(screen,49,3,['收盘价','P/B','经营盈利倍数','GAAP P/E','TTM经营盈利','净购券后流动性','财报截止']);formula(screen,'C50',"='数据与来源'!D193");formula(screen,'D50',"='数据与来源'!H195");formula(screen,'E50',"='数据与来源'!H197");formula(screen,'F50',"='数据与来源'!H199");formula(screen,'G50',"='数据与来源'!H196");formula(screen,'H50',"='数据与来源'!H200");cell(screen,'I50',date('2026-09-30'));screen.getRange('C50').setNumberFormat(fmt.price);screen.getRange('D50:F50').setNumberFormat(fmt.mult);screen.getRange('G50:H50').setNumberFormat('0.00"bn"');screen.getRange('I50').setNumberFormat('yyyy-mm-dd');
note(screen,53,'经营盈利是公司定义税后非GAAP指标，包含利息收入；GAAP净利受投资重估影响。');note(screen,55,'流动性仅为保险及其他分部现金+短期国库券−未结算购券应付，不是全部可分配现金。');note(screen,57,'A股按1:1500换算B股经济权益；P/B约1.66、经营盈利倍数约26.7，不证明低估。');note(screen,59,'BRK降低AI利润依赖，但仍有保险、市场、利率和经营风险；目标10%不是现金替代。');screen.freezePanes.freezeRows(8);screen.freezePanes.freezeColumns(4);

const meth=sheets['新闻与方法'];init(meth,95,'L');title(meth,'事实核验、数学边界与复核规则');meth.getRange('C1:C95').format.columnWidth=15;meth.getRange('D1:D95').format.columnWidth=34;meth.getRange('E1:E95').format.columnWidth=23;meth.getRange('F1:F95').format.columnWidth=72;
header(meth,7,3,['日期','事实或问题','证据状态','投资含义与边界']);
const eventRows=[['2026-11-11','黄仁勋辞任CEO与董事','SEC 8-K确认','11月11日生效，12日公开；Kress临时兼任CEO与CFO。看好产品不能使治理风险归零。'],['2026-11-13','独立调查、诉讼与国会监督','程序与报道，未裁定','调查存在，不等于指控已证实。没有把所有传闻当作财务造假结论。'],['2026-11-17','Q3财报与电话会议','公司确认日程','纽约约16:20发布、17:00电话会；截至11月13日尚不知道实际结果。'],['2026-07-26','收入、现金流、应收与担保','最新季度披露','经营业绩强劲，但GAAP利润含投资收益；担保上限并非即时债务或确定亏损。'],['2026-08-03','德州数据中心并网审计','共和党州长既有指令','暂停早于11月选举；9月21日扩展到环境许可。不能把全部变化归因新当选民主党。'],['2026-11-03','Hinojosa胜选与州长承诺','选举结果+政策意向','德州胜选已确认；多个州的暂停主张仍需实施。地方限制不等于全国新法律。'],['2026-11-13','规划容量约25%–27%','机构估计，口径不同','是项目管线份额，不是现有产能、NVDA收入或必然取消比例。'],['2026-09-24','台湾核三再运转计划获批','核安会批准计划阶段','仍需安全工作与后续审查，不是已重启；也不能假定非核政策永远不变。'],['2026-09-26','AAPL零机房/零台湾敞口','与10-K及PCC说明冲突','Apple依赖台湾供应链及自身/第三方云；端侧AI只改变暴露方式，不把暴露归零。'],['2026-09-30','软件不耗数据中心电力','与公司披露冲突','PLTR有最低云采购承诺；CRM披露电力、土地和水限制。外包算力不是零能耗。']];
write(meth,8,3,eventRows.map(x=>[date(x[0]),...x.slice(1)]));meth.getRange(`C8:C${7+eventRows.length}`).setNumberFormat('yyyy-mm-dd');meth.getRange(`D8:F${7+eventRows.length}`).format.wrapText=true;meth.getRange(`C8:F${7+eventRows.length}`).format.rowHeight=44;
section(meth,21,'历史计算定义','L');const definitions=['两年从2024-11-14起共501个收益日；五年从2021-11-15起共1255日，截止2026-11-13。','日收益以供应商分红/拆股调整价计算；按季度再平衡，期间权重漂移。未计税、点差或佣金。','年化波动=日收益样本标准差×√252；相关系数使用收益率，不使用价格水平。','最大回撤=历史净值相对此前最高值的最大跌幅；日ES95=最差约5%交易日的平均损失。','NVDA方差占比使用目标权重协方差分解，只归因直接头寸，未做ETF内发行人穿透。','事件周以11月6日收盘重设权重作事后回放；不是季度漂移路径或样本外验证。','回看有选择和幸存者偏差。新权重未完成前瞻验证；若引用bootstrap，它也只是历史抽样。','当前权重依据主动风险预算与业务判断；不是Max Sharpe、风险平价或均匀风险配置。'];definitions.forEach((t,i)=>note(meth,23+i*2,t));
section(meth,41,'对粘贴方案的数学核验','L');const mathNotes=['MCTR_i=(Σw)_i/σ；RC_i=w_i×MCTR_i；方差占比=w_i(Σw)_i/(w′Σw)。','10%本金占40%方差，表示风险集中程度高；这不等于用了4倍借款或衍生品杠杆。','未提供完整权重、μ、Σ、无风险利率和限制条件，无法复现“Max Sharpe”和25.6%波动。','“Grid beta=1.3或<0”缺少因子定义、正负号和回归证据，不能按行业标签直接赋值。','软件相对硬件抗跌，不等于绝对收益为正；有限波动率也不能证明消除左尾崩盘。','季度再平衡用于控制权重；趋势持续时可能落后买入持有，不保证alpha。'];mathNotes.forEach((t,i)=>note(meth,43+i*2,t));
section(meth,57,'剩余NVDA 5%的复核标准','L');const checklist=['看收入、下一季指引、产品交付和毛利率；不把价格上涨/下跌本身当作加仓证明。','分清主营盈利、税后投资收益和现金回款；检查相同期间应收、账期与减值准备。','核对已签担保、实际提款、融资方与客户信用；MOU与长期容量意向不是已收款订单。','判断新治理与出口事实是否改变预期现金流或所需回报；不是机械逢跌加仓。'];checklist.forEach((t,i)=>note(meth,59+i*2,t));

// Recalculation and economically meaningful edit checks, with defaults restored.
wb.recalculate();const initialDollar=alloc.getRange('F10').values[0][0];cell(alloc,'E4',7200);wb.recalculate();const changedDollar=alloc.getRange('F10').values[0][0];cell(alloc,'E4',review.meta.budget_usd);wb.recalculate();
if(Math.abs(initialDollar-review.meta.budget_usd*target.weights.VTI)>1e-7||Math.abs(changedDollar-7200*target.weights.VTI)>1e-7)throw new Error('Budget formula check failed');
const sums=alloc.getRange('E19:I19').values[0];if(Math.abs(sums[0]-1)>1e-9||Math.abs(sums[2]-1)>1e-9||Math.abs(sums[1]-7000)>1e-7||Math.abs(sums[3]-7000)>1e-7||Math.abs(sums[4])>1e-7)throw new Error('Allocation totals failed');
for(const [i,[id]]of stressList.entries())for(const [c,pid]of[['D','prior7'],['E',targetId],['F',entryId]])if(Math.abs(inp.getRange(`${c}${140+i}`).values[0][0]-review.allocations[pid].stress_results[id].return)>1e-10)throw new Error('Stress reconciliation failed');
for(const [t,x]of Object.entries(review.company_screen))for(const [c,k]of[['P','pe'],['R','fcf_yield'],['S','fcf_minus_sbc_yield']])if(typeof x[k]==='number'&&Math.abs(inp.getRange(`${c}${fRows[t]}`).values[0][0]-x[k])>1e-9)throw new Error(`Valuation reconciliation failed ${t} ${k}`);
for(const [c,k]of[['H193','latest_share_based_market_cap_billion'],['H194','book_value_per_b_equivalent_at_september30'],['H195','price_to_reported_book_per_b_share'],['H196','ttm_operating_earnings_after_tax_billion'],['H197','market_cap_to_ttm_operating_earnings'],['H198','ttm_gaap_net_income_attributable_billion'],['H199','market_cap_to_ttm_gaap_net_income'],['H200','insurance_and_other_cash_treasuries_net_of_unsettled_purchase_payables_billion']])if(Math.abs(inp.getRange(c).values[0][0]-brk.calculations[k])>1e-8)throw new Error(`BRK formula failed ${k}`);
const baseStress=inp.getRange('E140').values[0][0],shockCell=`${col(4+portfolioTickers.indexOf('NVDA'))}149`;cell(inp,shockCell,-0.5);wb.recalculate();const alteredStress=inp.getRange('E140').values[0][0];cell(inp,shockCell,-0.4);wb.recalculate();if(Math.abs(alteredStress-baseStress+0.1*target.weights.NVDA)>1e-10)throw new Error('Editable stress failed');
const inspection=await wb.inspect({kind:'table',range:'配置!C9:I19',include:'values,formulas',tableMaxRows:11,tableMaxCols:7,maxChars:5500});
const errors=await wb.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:100},summary:'final formula error scan',maxChars:5000});
await fs.mkdir(outputDir,{recursive:true});await fs.writeFile(`${outputDir}/verification.json`,JSON.stringify({modelSha256:createHash('sha256').update(modelText).digest('hex'),targetId,entryId,budgetBefore:initialDollar,budgetChanged:changedDollar,allocationTotals:sums,stressBefore:baseStress,stressChanged:alteredStress,valuationRatiosChecked:Object.keys(review.company_screen).length,berkshireFormulaChecks:8,sourceCount:sourceRows.length,priceTickerCount:histTickers.length,inspection:inspection.ndjson,errors:errors.ndjson},null,2));
const renders=[['配置','C2:R44','allocation'],['风险比较','C2:L65','risk'],['公司筛选','C2:O61','companies'],['新闻与方法','C2:F67','news_methods'],['数据与来源',`C2:${col(pLast)}26`,'source_weights'],['数据与来源',`C29:S${fEnd}`,'source_financials'],['数据与来源','C229:W238','source_urls'],['数据与来源','C419:O433','source_prices'],['数据与来源',`C137:${col(pLast)}154`,'source_stress'],['数据与来源','C190:L216','source_berkshire']];
const only=process.env.PORTFOLIO_RENDER_ONLY?.split(',');for(const[sheetName,range,file]of renders){if(only&&!only.includes(file))continue;const b=await wb.render({sheetName,range,scale:1.35,format:'png'});await fs.writeFile(`${outputDir}/${file}.png`,new Uint8Array(await b.arrayBuffer()));}
const xlsx=await SpreadsheetFile.exportXlsx(wb);await xlsx.save(`${outputDir}/ai_portfolio_review_20261113.xlsx`);console.log(JSON.stringify({output:`${outputDir}/ai_portfolio_review_20261113.xlsx`,sheets:5,targetId,entryId,companies:companyOrder.length,sourceCount:sourceRows.length,priceRows:csv.length-1,priceTickers:histTickers.length,allocationTotals:sums,errors:errors.ndjson}));
