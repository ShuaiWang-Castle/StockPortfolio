from pathlib import Path
import json
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
quotes = pd.read_csv(BASE / 'market_data/close.csv', index_col=0).iloc[-1]
TAGS = {
    'revenue': ['RevenueFromContractWithCustomerExcludingAssessedTax', 'Revenues', 'SalesRevenueNet'],
    'net_income': ['NetIncomeLoss'],
    'operating_income': ['OperatingIncomeLoss'],
    'cfo': ['NetCashProvidedByUsedInOperatingActivities'],
    'capex': ['PaymentsToAcquirePropertyPlantAndEquipment', 'PaymentsToAcquireProductiveAssets'],
    'sbc': ['ShareBasedCompensation', 'AllocatedShareBasedCompensationExpense'],
}
PERIODS = [('fy2025', '2025-01-01', '2025-12-31'), ('ytd2026', '2026-01-01', '2026-09-30'), ('ytd2025', '2025-01-01', '2025-09-30')]
SHARES = {'ANET': 1263402335, 'NOW': 1037917000, 'ETN': 388500000, 'GOOGL': 12294000000, 'META': 2556241253}
allout = {}
for sym, shares in SHARES.items():
    facts = json.load(open(BASE / 'candidate_raw' / f'{sym}_companyfacts.json'))['facts']['us-gaap']
    out = {}
    for label, tags in TAGS.items():
        if sym == 'GOOGL' and label == 'net_income':
            tags = ['NetIncomeLossAvailableToCommonStockholdersBasic', 'NetIncomeLoss']
        components = {}
        for period, start, end in PERIODS:
            observations = []
            for tag in tags:
                for obs in facts.get(tag, {}).get('units', {}).get('USD', []):
                    if (obs.get('start') == start and obs['end'] == end
                            and obs['filed'] <= '2026-11-13' and obs['form'] in ['10-K', '10-Q', '10-K/A', '10-Q/A']):
                        observations.append(dict(obs, tag=tag))
                if observations:
                    break
            if observations:
                components[period] = sorted(observations, key=lambda x: x['filed'])[-1]
        ttm = components['fy2025']['val'] + components['ytd2026']['val'] - components['ytd2025']['val'] if len(components) == 3 else None
        out[label] = {'ttm': ttm, 'components': components}
    out['common_shares'] = shares
    out['price'] = float(quotes[sym])
    out['market_cap'] = out['price'] * shares
    out['pe'] = out['market_cap'] / out['net_income']['ttm']
    out['fcf'] = out['cfo']['ttm'] - out['capex']['ttm']
    out['fcf_yield'] = out['fcf'] / out['market_cap']
    out['fcf_minus_sbc_yield'] = (out['fcf'] - out['sbc']['ttm']) / out['market_cap'] if out['sbc']['ttm'] is not None else None
    out['methodology'] = 'TTM FY2025 + Jan-Sep2026 minus Jan-Sep2025. SEC 10-K/10-Q only; proxies excluded because potentially inconsistent XBRL scale. Latest reported common shares times Nov13 2026 closing price. Gross cash capex; SBC subtraction is a conservative shareholder-cost sensitivity, not a GAAP metric or full FCFF.'
    allout[sym] = out
    print(sym, {k: round(v, 5) if isinstance(v, float) else v for k, v in out.items() if k not in TAGS and k != 'methodology'})
    print('ttm_usd_bn', {k: round(v['ttm'] / 1e9, 4) if v['ttm'] is not None else None for k, v in out.items() if k in TAGS})
json.dump(allout, open(BASE / 'candidate_raw/ttm_metrics.json', 'w'), indent=2)
