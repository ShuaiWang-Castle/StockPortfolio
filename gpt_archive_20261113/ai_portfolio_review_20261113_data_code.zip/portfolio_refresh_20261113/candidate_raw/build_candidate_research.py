from pathlib import Path
import json
import pandas as pd

base = Path(__file__).resolve().parents[1]
metrics = json.load(open(base / 'candidate_raw/ttm_metrics.json'))
market = pd.read_csv(base / 'market_data/two_year_asset_metrics.csv').set_index('ticker')
sources = {
 'goog_release': {'url': 'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000080/googexhibit991q32026.htm', 'date': '2026-10-28', 'ref': 'turn93view0'},
 'goog_q': {'url': 'https://www.sec.gov/Archives/edgar/data/1652044/000165204426000084/goog-20260930.htm', 'date': '2026-10-29', 'ref': 'turn93view2'},
 'goog_call': {'url': 'https://abc.xyz/investor/events/event-details/2026/2026-Q3-Earnings-Call-2026-Ujou16CTw9/default.aspx', 'date': '2026-10-28', 'ref': 'turn81search0'},
 'goog_tpu': {'url': 'https://cloud.google.com/blog/topics/ai-infrastructure/tpu-8tx-and-tpu-8i-max', 'date': '2026-11-09', 'ref': 'turn83search0'},
 'meta_release': {'url': 'https://investor.atmeta.com/investor-news/press-release-details/2026/Meta-Reports-Third-Quarter-2026-Results/', 'date': '2026-10-21', 'ref': 'turn90view1'},
 'meta_q': {'url': 'https://www.sec.gov/Archives/edgar/data/1326801/000162828026066773/meta-20260930.htm', 'date': '2026-10-22', 'ref': 'turn94view1'},
 'meta_preferred_close': {'url': 'https://www.sec.gov/Archives/edgar/data/1326801/000119312526438017/d183592d8k.htm', 'date': '2026-10-29', 'ref': 'turn97view1'},
 'meta_usd_close': {'url': 'https://www.sec.gov/Archives/edgar/data/1326801/000119312526450074/d166273d8k.htm', 'date': '2026-11-05', 'ref': 'turn97view2'},
 'meta_eur_close': {'url': 'https://www.sec.gov/Archives/edgar/data/1326801/000119312526458525/d177728d8k.htm', 'date': '2026-11-12', 'ref': 'turn97view0'},
 'anet_release': {'url': 'https://www.arista.com/en/company/news/press-release/25025-pr-20261103', 'date': '2026-11-03', 'ref': 'turn78view0'},
 'anet_release_pdf': {'url': 'https://s21.q4cdn.com/861911615/files/doc_news/Arista-Networks-Inc--Reports-Third-Quarter-2026-Financial-Results-2026.pdf', 'date': '2026-11-03', 'ref': 'turn95search8'},
 'anet_q': {'url': 'https://www.sec.gov/Archives/edgar/data/1596532/000159653226000254/anet-20260930.htm', 'date': '2026-11-04', 'ref': None, 'retrieval': 'SEC HTML fetched directly with urllib; web open returned InternalError. Local candidate_raw/ANET_20260930.html and .txt.'},
 'now_release': {'url': 'https://www.sec.gov/Archives/edgar/data/1373715/000137371526000092/erq3fy26.htm', 'date': '2026-10-28', 'ref': 'turn96view0'},
 'now_q': {'url': 'https://www.sec.gov/Archives/edgar/data/1373715/000137371526000096/now-20260930.htm', 'date': '2026-10-28', 'ref': 'turn96view1'},
 'etn_release': {'url': 'https://www.eaton.com/us/en-us/company/news-insights/news-releases/2026/eaton-reports-record-third-quarter-2026-results.html', 'date': '2026-11-03', 'ref': 'turn78view2'},
 'etn_q': {'url': 'https://www.sec.gov/Archives/edgar/data/1551182/000155118226000040/etn-20260930.htm', 'date': '2026-11-03', 'ref': 'turn91view2'},
 'orcl_release': {'url': 'https://investor.oracle.com/investor-news/news-details/2026/Oracle-Announces-Q1-Results-Driven-by-Triple-Digit-Growth-in-Cloud-Infrastructure-Revenues/default.aspx', 'date': '2026-09-10', 'ref': 'turn81search9'},
 'asml_release': {'url': 'https://www.investor.asml.com/news-releases/news-release-details/asml-reports-eu11.7-billion-total-net-sales-and-eu5.0-billion-net-income-q3-2026', 'date': '2026-10-14', 'ref': 'turn81search10'},
}
research = {
 'cutoff': '2026-11-13 US close',
 'scope': 'Candidate business roles, accounting quality and trailing valuation; no full DCF and no intrinsic-value point targets.',
 'sources': sources,
 'methodology': {
  'ttm': 'FY2025 + Jan-Sep2026 - Jan-Sep2025, fiscal financial statements ending 2026-09-30. All XBRL observations limited to 10-K/10-Q (and amendments) filed by cutoff.',
  'pe': 'Nov13 close times latest reported common shares divided by TTM net income available to common. Uses current common shares rather than historical diluted EPS denominator. Approximate for multiclass issuers: GOOGL price applied to all classes. Preferred future conversions and future forwards are not current common shares.',
  'fcf': 'GAAP CFO less gross cash purchases of PP&E/productive assets. Does not add back acquisition costs and does not subtract acquisitions or finance-lease principal. CFO is after cash interest/tax, hence this is not FCFF.',
  'sbc_sensitivity': 'FCF less the SBC addback in the cash flow statement. Conservative shareholder-cost proxy, not a GAAP metric or an exact dilution calculation. It must not be double-counted with both ongoing cash compensation replacement and separately modeled dilution.',
  'etn_sbc': 'Not separately available in current standard XBRL cash-flow tags; not assumed zero. Current CF statement groups other adjustments. No SBC sensitivity shown.',
  'quality_trap': 'ANET companyfacts has a DEF14A FY2025 net-income observation 3511 while 10-K reports USD3,511,400,000; the proxy observation is excluded, preventing a unit/scale error.',
  'current_share_dates': {'ANET':'2026-10-29 cover', 'NOW':'2026-09-30', 'ETN':'2026-09-30', 'GOOGL':'2026-10-21 cover rounded; total same as Sep30', 'META':'2026-10-16 cover'},
  'splits': 'NOW and ANET current share counts and market prices are consistently post-split.',
  'period_limit': 'Historical correlation/drawdown figures come from the parent price agent two-year common sample, 501 daily returns; no causal or forward hedge guarantee.'
 },
 'companies': {},
 'portfolio_judgment': {
  'status': 'Analyst interpretation, not a fact from company sources.',
  'default': 'Keep GOOGL as an existing holding; add META only at a limited weight within the fixed AI budget. For a USD7000 portfolio there is no structural need to force a ninth holding; spare AI weight can stay in existing GOOGL/MSFT.',
  'meta': 'A 5-8% satellite allocation is more defensible than replacing most NVDA risk with META. Ads monetize AI today but financing/commitments and capex constrain cash returns.',
  'extra_name': 'If specifically choosing a different AI revenue engine, NOW is most differentiated among ANET/NOW/ETN, and at most 5% is a speculative choice. Its lower NVDA correlation does not compensate automatically for deteriorating gross margin, high SBC and acquisition leverage. Default watchlist until margin/backlog quality improves.',
  'anet': 'Best current operating profitability and balance-sheet quality of these three; 52.45x trailing P/E and 2.01% cash FCF yield after a 15.5% weekly rally weaken the entry case. Watchlist instead of chasing rotation.',
  'etn': 'Broader industrial/power demand, but 35.19x P/E, acquisition-funded debt and 0.60 historical NVDA correlation make it a weak candidate for a dedicated hedge slot.',
  'tsm_comparison': 'TSM may be a stronger quality/value choice using the semiconductor specialist valuation, but it changes supplier concentration more than AI demand exposure; two-year NVDA rho0.712 remains high.',
  'avoid_expansion_for_its_own_sake': 'One position at 5% is only USD350. More names are not a substitute for sector/risk-budget discipline; no need for ANET,NOW,ETN,ORCL,ASML simultaneously.'
 }
}

facts = {
 'GOOGL': {
  'role': 'Search advertising, cloud/model services and an alternative compute platform through proprietary TPU systems.',
  'new_week_event': {'date':'2026-11-09','fact':'Official launch of TPU 8tx and TPU 8i Max; TPU customers can deploy systems in their own data centers as well as use Google Cloud.','source':'goog_tpu'},
  'latest_report': {'q3_revenue_usd_bn':127.577,'revenue_yoy':0.25,'cloud_revenue_usd_bn':30.709,'cloud_revenue_yoy':1.03,'search_revenue_yoy':0.12,'q3_cfo_usd_bn':42.290,'q3_cash_capex_usd_bn':51.355,'q3_cash_fcf_usd_bn':-9.065,'source':'goog_release'},
  'guidance': {'fy2026_capex_usd_bn':[195,205],'2027_capex':'significant increase expected, not a numerical forecast','source':'goog_call'},
  'accounting': {'nine_month_unrealized_nonmarketable_equity_net_gains_usd_bn':116.316,'source':'goog_q','interpretation':'Reported P/E is inflated-earnings sensitive. Gains include private-company/SpaceX pre-IPO valuation movements; do not treat as recurring AI operating earnings. Cash+marketable totals include risky equity; do not add investment gains again to asset value.'},
  'portfolio_role': 'Existing holding, not newly introduced. Alternative chip ecosystem can reduce NVIDIA-specific supplier risk; shared capex/market exposure remains.'
 },
 'META': {
  'role':'AI-driven advertising recommendations, targeting and engagement; frontier-model and infrastructure investment funded by advertising plus external capital.',
  'latest_report': {'q3_revenue_usd_bn':64.60,'revenue_yoy':0.26,'ad_impressions_yoy':0.10,'average_ad_price_yoy':0.14,'fy2026_capex_including_finance_lease_principal_usd_bn':[135,145],'source':'meta_release'},
  'accounting': {'q1_discrete_tax_benefit_usd_bn':8.03,'q3_litigation_charge_usd_bn':9.89,'source':'meta_q','interpretation':'Tax benefit and legal charge distort simple reported earnings comparisons. Neither subtracting every legal charge nor accepting every tax benefit is a clean recurring earnings estimate.'},
  'financing': [
   {'event':'Mandatory convertible preferred closed','date':'2026-10-29','gross_claim_usd_bn':12.5,'coupon':0.065,'source':'meta_preferred_close'},
   {'event':'USD bonds closed','date':'2026-11-05','principal_usd_bn':15.0,'source':'meta_usd_close'},
   {'event':'EUR bonds newly closed','date':'2026-11-12','principal_eur_bn':9.0,'source':'meta_eur_close'},
   {'event':'Forward common sale agreements','total_shares_mn':46,'initial_cash_received_by_company':0,'settlement_deadline':'2027-11-19','source':['meta_preferred_close','meta_usd_close'],'interpretation':'Future dilution/proceeds; 46m borrowed shares sold by forward counterparties are not 46m newly issued company shares today.'}
  ],
  'portfolio_role':'Small platform/ad-monetization satellite; positive performance on one NVDA shock day is not a stable hedge. Debt/preferred proceeds must be paired with corresponding claims in any valuation bridge.'
 },
 'ANET': {
  'role':'Ethernet scale-up/scale-out networking and software; open architectures supporting multiple accelerator ecosystems.',
  'latest_report': {'q3_revenue_usd_bn':3.6576,'revenue_yoy':0.585,'gaap_operating_margin':0.449,'q4_revenue_guidance_usd_bn':[3.9,4.0],'source':'anet_release'},
  'accounting': {'cash_plus_marketable_usd_bn':14.359,'funded_debt_usd_bn':0,'two_largest_customer_2025_revenue_shares':[0.16,0.26],'nine_month_cfo_usd_bn':3.9774,'deferred_revenue_inflow_usd_bn':1.4671,'inventory_cash_use_usd_bn':0.9628,'receivables_cash_use_usd_bn':0.4409,'noncancellable_supplier_commitments_usd_bn':11.4,'commitments_due_within_12m_usd_bn':9.3,'source':'anet_q'},
  'portfolio_role':'Strong current business quality, but same hyperscaler-capex factor and customer concentration. Current valuation after sharp rotation rally calls for patience.'
 },
 'NOW': {
  'role':'Enterprise workflows, AI agents and governance, security and process automation; customer software budgets rather than primarily GPU unit shipments.',
  'latest_report': {'q3_subscription_revenue_usd_bn':3.988,'subscription_revenue_yoy':0.21,'q3_total_revenue_usd_bn':4.106,'crpo_usd_bn':13.65,'crpo_growth_constant_currency':0.21,'q4_crpo_growth_guidance_constant_currency':0.185,'fy2026_ai_acv_target_usd_bn':1.7,'source':'now_release','acv_caution':'Annual contract value target is not recognized AI revenue.'},
  'accounting': {'q3_gaap_subscription_gross_margin':0.735,'prior_year_q3_gaap_subscription_gross_margin':0.80,'q3_nongaap_subscription_gross_margin':0.80,'prior_year_q3_nongaap_subscription_gross_margin':0.83,'nine_month_cfo_usd_bn':3.096,'prior_ytd_cfo_usd_bn':3.206,'nine_month_cash_capex_usd_bn':0.346,'prior_ytd_cash_capex_usd_bn':0.630,'cash_MA_costs_added_back_in_company_fcf_usd_bn':0.371,'acquisitions_armis_veza_cash_consideration_approx_usd_bn':8.9,'cash_plus_marketable_usd_bn':6.961,'funded_debt_usd_bn':7.524,'goodwill_usd_bn':10.012,'source':'now_q','interpretation':'Strict cash FCF differs from company adjusted FCF; gross margins deteriorated despite headline AI momentum. Low capex does not eliminate third-party cloud opex or acquisition cash use.'},
  'portfolio_role':'Best incremental business-model diversification, but speculative at up to 5% because SBC, margin decline and integration debt offset the improved headline cash-FCF yield.'
 },
 'ETN': {
  'role':'Electrical distribution, power quality, cooling and broader industrial/aerospace demand; wider end markets than AI alone.',
  'latest_report': {'q3_revenue_usd_bn':8.947,'revenue_yoy':0.28,'organic_growth':0.19,'acquisition_growth_contribution':0.08,'gaap_eps':2.77,'adjusted_eps':3.68,'fy2026_gaap_eps_guidance':[10.39,10.49],'fy2026_adjusted_eps_guidance':[13.70,13.80],'source':'etn_release'},
  'accounting': {'nine_month_acquisitions_cash_usd_bn':11.079,'boyd_acquisition_cash_usd_bn':9.55,'ultra_acquisition_cash_usd_bn':1.53,'funded_debt_usd_bn':20.106,'supplier_finance_obligations_usd_bn':0.763,'2026_share_repurchases':'none and not planned because of Boyd acquisition','source':'etn_q','interpretation':'25.3% reported segment margin is not consolidated GAAP operating margin. Acquisition amortization and debt matter; strict cash FCF excludes acquisition consideration.'},
  'portfolio_role':'Representative industrial AI infrastructure name; expensive and cyclical, not a defensive utility or natural NVIDIA hedge.'
 },
 'ORCL': {
  'role':'Cloud infrastructure and databases; AI compute supplier to model customers.',
  'latest_report': {'period_end':'2026-08-31','revenue_usd_bn':19.3,'revenue_yoy':0.30,'iaas_revenue_usd_bn':7.4,'iaas_revenue_yoy':1.21,'rpo_usd_bn':664,'common_stock_atm_sold_in_quarter_usd_bn':20,'source':'orcl_release'},
  'portfolio_role':'Watchlist. RPO is not cash or recognized revenue; large capital requirements do not reduce the customer-financing risk currently worrying investors.'
 },
 'ASML': {
  'role':'Lithography equipment for semiconductor manufacturing; benefits from broader fab investment rather than one model or GPU designer.',
  'latest_report': {'period_end':'2026-09-30','q3_revenue_eur_bn':11.7,'q3_net_income_eur_bn':5.0,'fy2026_revenue_guidance_eur_bn':[44,45],'source':'asml_release'},
  'portfolio_role':'Watchlist alternative manufacturing exposure; still tied to semiconductor capital spending, customer concentration and export-policy risk. No need alongside every other manufacturing name.'
 }
}
for sym, record in facts.items():
    if sym in metrics:
        record['valuation'] = metrics[sym]
    if sym in market.index:
        record['historical_market_metrics'] = {k:(float(v) if hasattr(v,'item') else v) for k,v in market.loc[sym].items()}
    research['companies'][sym] = record
out = base / 'candidate_research.json'
out.write_text(json.dumps(research, ensure_ascii=False, indent=2))
print(str(out))
print('bytes', out.stat().st_size, 'companies', len(facts), 'valuation_rows', len(metrics))
