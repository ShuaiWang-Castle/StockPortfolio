"""Render the portfolio review from final, read-only model inputs.

Run with: python portfolio_refresh_20261113/make_portfolio_review_figure.py
No model inputs are modified. All portfolio paths are retrospective examples.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.ticker import FuncFormatter, MultipleLocator
from matplotlib.patches import FancyBboxPatch

BASE = Path(__file__).resolve().parent
OUT = BASE.parent / 'outputs/ai_portfolio_20261113/ai_portfolio_review_20261113.png'
MODEL = json.loads((BASE / 'analysis/portfolio_review.json').read_text())
CLOSE = pd.read_csv(BASE / 'market_data/close.csv', index_col=0, parse_dates=True)
CORR = pd.read_csv(BASE / 'market_data/two_year_correlation.csv', index_col=0)
RETURNS = pd.read_csv(BASE / 'analysis/portfolio_daily_returns.csv', index_col=0, parse_dates=True)

INK, MUTED, GRID, BG = '#192E40', '#596D7E', '#E2E8EE', '#F4F7FA'
TEAL, BLUE, RED, GOLD = '#087D86', '#2C668A', '#CB5A52', '#B27C19'
plt.rcParams.update({
    'font.family': 'DejaVu Sans', 'font.size': 10.5,
    'axes.labelcolor': MUTED, 'xtick.color': MUTED, 'ytick.color': MUTED,
    'text.color': INK, 'axes.titlecolor': INK, 'axes.edgecolor': GRID,
    'savefig.facecolor': BG, 'figure.facecolor': BG,
})
fig = plt.figure(figsize=(16, 12.8))

def card(x, y, w, h):
    fig.add_artist(FancyBboxPatch(
        (x, y), w, h, boxstyle='round,pad=0.010,rounding_size=0.012',
        transform=fig.transFigure, fc='white', ec='#E5EBF0', lw=0.8, zorder=-10))

card(.035, .505, .435, .350)
card(.495, .505, .470, .350)
card(.035, .145, .930, .333)

fig.text(.045, .949, 'AI portfolio review', fontsize=29, weight='bold')
fig.text(.045, .918, 'Market rotation, co-movement and portfolio drawdowns', fontsize=15.5, color=MUTED)
fig.text(.955, .953, '13 NOV 2026', fontsize=12.5, weight='bold', ha='right', color=TEAL)
fig.text(.955, .932, 'U.S. regular-session close', fontsize=10.5, ha='right', color=MUTED)
fig.text(.045, .884, '$7,000 discretionary portfolio  /  Historical comparisons; no forward prediction',
         fontsize=11.5, color=MUTED)

# Panel 1: raw closing-price returns over the last completed week.
fig.text(.052, .826, '01  One-week price rotation', fontsize=15, weight='bold')
fig.text(.052, .805, 'Nov 6 to Nov 13, 2026', fontsize=10.5, color=MUTED)
rotation_names = ['NVDA', 'MSFT', 'GOOGL', 'META', 'AMD', 'AVGO', 'ANET', 'VTI']
rotation = (CLOSE.loc['2026-11-13', rotation_names] / CLOSE.loc['2026-11-06', rotation_names] - 1) * 100
for name, value in rotation.items():
    expected = MODEL['assets'][name]['week_price_return_nov6_to_nov13'] * 100
    assert abs(value - expected) < 1e-9, (name, value, expected)
ax1 = fig.add_axes([.105, .566, .337, .216])
bars = ax1.barh(range(len(rotation)), rotation.values, height=.58,
               color=[RED if x < 0 else BLUE for x in rotation], zorder=3)
ax1.set_yticks(range(len(rotation)), rotation_names, fontweight='medium', color=INK)
ax1.invert_yaxis()
ax1.set_xlim(-17, 23)
ax1.set_xticks([-10, 0, 10, 20])
ax1.xaxis.set_major_formatter(FuncFormatter(lambda x, _: f'{x:.0f}%'))
ax1.grid(axis='x', color=GRID, linewidth=.7, zorder=0)
ax1.axvline(0, color='#96A8B8', lw=.9, zorder=2)
ax1.tick_params(axis='both', length=0)
for b, value in zip(bars, rotation):
    # Long negative bars carry their value inside to avoid the ticker labels.
    inside = value < -5
    ax1.text(value + (.7 if value >= 0 or inside else -.7), b.get_y() + b.get_height()/2,
             f'{value:+.1f}%', va='center', ha='left' if value >= 0 or inside else 'right',
             fontsize=10.5, weight='bold', color='white' if inside else RED if value < 0 else BLUE)
for spine in ax1.spines.values():
    spine.set_visible(False)
fig.text(.052, .525, 'Price return only; dividends are excluded in this panel.', fontsize=9.3, color=MUTED)

# Panel 2: full Pearson correlation matrix on the common two-year sample.
fig.text(.512, .826, '02  Two-year return correlations', fontsize=15, weight='bold')
fig.text(.512, .805, 'Nov 14, 2024 to Nov 13, 2026  |  501 daily returns', fontsize=10.5, color=MUTED)
names = ['VTI', 'NVDA', 'GOOGL', 'MSFT', 'META', 'XLV', 'SGOV']
mat = CORR.loc[names, names].to_numpy()
cmap = LinearSegmentedColormap.from_list('portfolio_corr', ['#BB534E', '#FCFCFB', '#18566E'])
ax2 = fig.add_axes([.573, .570, .319, .202])
im = ax2.imshow(mat, vmin=-1, vmax=1, cmap=cmap, aspect='auto')
ax2.set_xticks(range(len(names)), names, fontsize=9.8)
ax2.set_yticks(range(len(names)), names, fontsize=9.8)
ax2.tick_params(top=True, labeltop=True, bottom=False, labelbottom=False, length=0, pad=6)
ax2.set_xticks(np.arange(-.5, len(names), 1), minor=True)
ax2.set_yticks(np.arange(-.5, len(names), 1), minor=True)
ax2.grid(which='minor', color='white', linewidth=2.0)
ax2.tick_params(which='minor', bottom=False, left=False, top=False)
for (i, j), value in np.ndenumerate(mat):
    ax2.text(j, i, f'{value:.2f}', ha='center', va='center', fontsize=9.5,
             color='white' if abs(value) > .61 else INK,
             weight='bold' if i == j else 'normal')
for spine in ax2.spines.values():
    spine.set_visible(False)
cax = fig.add_axes([.627, .543, .207, .010])
cb = fig.colorbar(im, cax=cax, orientation='horizontal', ticks=[-1, -.5, 0, .5, 1])
cb.outline.set_visible(False)
cb.ax.tick_params(length=0, labelsize=8.5, pad=3)
fig.text(.852, .542, 'Pearson r', fontsize=9.2, color=MUTED)
fig.text(.512, .515, 'Split/dividend-adjusted returns. Historical relationships can change.', fontsize=9.1, color=MUTED)

# Panel 3: initialize NAV at 1 at the prior trading-day anchor before compounding.
fig.text(.052, .448, '03  Five-year hypothetical drawdowns', fontsize=15, weight='bold')
fig.text(.052, .427, 'Nov 12, 2021 to Nov 13, 2026  |  Quarterly rebalancing; dividends reinvested', fontsize=10.5, color=MUTED)
ax3 = fig.add_axes([.090, .196, .847, .185])
colors = {'prior7': '#637485', 'revised7': TEAL, 'entry': GOLD}
labels = {'prior7': 'Prior allocation', 'revised7': 'Revised target', 'entry': 'Initial entry mix'}
drawdown_summary = {}
for key in ['prior7', 'revised7', 'entry']:
    r = RETURNS[key].dropna()
    anchor = pd.Timestamp(MODEL['allocations'][key]['metrics']['five_year']['price_anchor_date'])
    assert anchor < r.index[0]
    nav = pd.concat([pd.Series([1.0], index=[anchor]), (1 + r).cumprod()])
    dd = nav / nav.cummax() - 1
    mdd = float(dd.min())
    expected = MODEL['allocations'][key]['metrics']['five_year']['max_drawdown']
    assert abs(mdd - expected) < 1e-11, (key, mdd, expected)
    drawdown_summary[key] = {'max_drawdown': mdd, 'minimum_date': str(dd.idxmin().date()), 'anchor_nav': float(nav.iloc[0])}
    ax3.plot(dd.index, dd * 100, color=colors[key], lw=1.9,
             ls='--' if key == 'entry' else '-',
             label=f'{labels[key]}   |   max drawdown {mdd:.1%}', zorder=4 if key == 'entry' else 3)
    if key == 'prior7':
        ax3.fill_between(dd.index, dd * 100, 0, color=colors[key], alpha=.045, linewidth=0)
    ax3.scatter([dd.idxmin()], [mdd * 100], s=23, color=colors[key], edgecolor='white', linewidth=.7, zorder=6)
ax3.set_ylim(-34, 1.2)
ax3.set_xlim(pd.Timestamp('2021-11-12'), pd.Timestamp('2026-11-23'))
ax3.yaxis.set_major_locator(MultipleLocator(10))
ax3.yaxis.set_major_formatter(FuncFormatter(lambda y, _: f'{y:.0f}%'))
ax3.xaxis.set_major_locator(mdates.YearLocator())
ax3.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
ax3.grid(axis='y', color=GRID, lw=.8)
ax3.axhline(0, color='#B4C2CD', lw=.7)
ax3.tick_params(length=0, pad=7)
ax3.set_ylabel('Below previous peak', fontsize=10.5, labelpad=10)
for s in ['left', 'right', 'top']:
    ax3.spines[s].set_visible(False)
ax3.spines['bottom'].set_color(GRID)
legend = ax3.legend(loc='lower left', bbox_to_anchor=(-.005, 1.03), ncol=3,
                   frameon=False, fontsize=10.1, handlelength=2.4, columnspacing=2.5)
for txt, key in zip(legend.get_texts(), ['prior7', 'revised7', 'entry']):
    txt.set_color(colors[key])
fig.text(.052, .159, 'The revised target retains equity drawdown risk; the entry mix holds a larger Treasury-bill allocation.',
         fontsize=10, color=MUTED)

# Weight key keeps the chart useful independently of the accompanying report.
weight_y = [.116, .096, .076]
for key, y in zip(['prior7', 'revised7', 'entry'], weight_y):
    weight_text = '   '.join(f'{ticker} {weight:.0%}' for ticker, weight in MODEL['allocations'][key]['weights'].items())
    fig.text(.045, y, labels[key], fontsize=9.4, weight='bold', color=colors[key])
    fig.text(.167, y, weight_text, fontsize=9.4, color=MUTED)
fig.text(.045, .044, 'Sources: Yahoo Finance closing and adjusted-price history; portfolio_review.json. Drawdowns start with NAV = 1 on Nov 12, 2021.',
         fontsize=8.8, color=MUTED)
fig.text(.045, .027, 'Retrospective hypothetical allocations selected today, applied to past returns. Taxes, spreads and fees excluded. Past results do not predict future outcomes.',
         fontsize=8.8, color=MUTED)

OUT.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(OUT, dpi=190, bbox_inches=None)
plt.close(fig)
print(json.dumps({'output': str(OUT), 'pixel_dimensions': [3040, 2432], 'bytes': OUT.stat().st_size,
                  'rotation_pct': rotation.round(6).to_dict(), 'drawdowns_verified': drawdown_summary}, indent=2))
