"""Independent numerical audit of the saved portfolio review.

The audited implementation is NOT imported. This script takes portfolio policy
weights and dates from its saved JSON, then uses price-unit holdings and NumPy
covariances to reproduce the outputs. It does not choose portfolio weights.
"""
from pathlib import Path
import hashlib
import json
import math
import sys

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "market_data"))
from independent_methods import (
    price_unit_backtest,
    independently_recomputed_metrics,
    fixed_target_covariance_risk,
    paired_stationary_bootstrap_fixed_weight_vol_ratio,
)

SOURCE = BASE / "analysis/portfolio_conviction_review.json"
SOURCE_BYTES = SOURCE.read_bytes()
REVIEW = json.loads(SOURCE_BYTES)
P = pd.read_csv(BASE / "market_data_extended/adjusted_close.csv", index_col=0, parse_dates=True)
C = pd.read_csv(BASE / "market_data_extended/close.csv", index_col=0, parse_dates=True)
SAVED_RETURNS = pd.read_csv(BASE / "analysis/portfolio_conviction_daily_returns.csv", index_col=0, parse_dates=True)
END = "2026-11-13"
BUDGET = 7000.0
checks = []


def near(label, actual, expected, tolerance=1e-10):
    error = abs(float(actual) - float(expected))
    item = {"check": label, "passed": bool(error <= tolerance),
            "independent_value": float(actual), "reported_value": float(expected),
            "absolute_error": error, "tolerance": tolerance}
    checks.append(item)
    return item


def exact(label, actual, expected):
    item = {"check": label, "passed": bool(actual == expected),
            "independent_value": actual, "reported_value": expected}
    checks.append(item)
    return item


results = {}
navs = {}
metric_names = {
    "ann_vol": "annualized_volatility", "max_drawdown": "max_drawdown",
    "es95_daily_loss": "daily_es95_loss", "cagr": "historical_cagr",
    "n_returns": "n_returns", "total_return": "historical_total_return",
}
tail_nvda = P["NVDA"].loc["2024-11-13":END].pct_change(fill_method=None).iloc[1:]
tail_count = math.ceil(.1 * len(tail_nvda))
# Stable ascending NumPy sorting supplies the same worst-decile convention;
# the returns at the cutoff are distinct in this dataset.
tail_dates = tail_nvda.index[np.argsort(tail_nvda.to_numpy(), kind="stable")[:tail_count]]

for portfolio_name, allocation in REVIEW["allocations"].items():
    weights = allocation["weights"]
    near(f"{portfolio_name}: weights sum", sum(weights.values()), 1)
    exact(f"{portfolio_name}: no negative weights", all(x >= 0 for x in weights.values()), True)
    near(f"{portfolio_name}: total dollars", sum(allocation["amounts_usd"].values()), BUDGET)
    for ticker, weight in weights.items():
        near(f"{portfolio_name}: dollars {ticker}", BUDGET * weight, allocation["amounts_usd"][ticker])
        near(f"{portfolio_name}: fractional units {ticker}", BUDGET * weight / C.loc[END, ticker],
             allocation["theoretical_fractional_units"][ticker])

    result = {"windows": {}}
    for window, reported in allocation["metrics"].items():
        anchor = reported["price_anchor_date"]
        last = reported["last_return_date"]
        nav, returns = price_unit_backtest(P, weights, anchor, last)
        independent = independently_recomputed_metrics(nav, returns)
        columns = [ticker for ticker, w in weights.items() if w > 0]
        asset_returns = P.loc[anchor:last, columns].pct_change(fill_method=None).iloc[1:]
        covariance = fixed_target_covariance_risk(asset_returns, weights)
        exact(f"{portfolio_name}/{window}: date anchor", str(nav.index[0].date()), anchor)
        exact(f"{portfolio_name}/{window}: first return date", str(returns.index[0].date()), reported["first_return_date"])
        exact(f"{portfolio_name}/{window}: last return date", str(returns.index[-1].date()), last)
        for source_key, target_key in metric_names.items():
            near(f"{portfolio_name}/{window}: {target_key}", independent[source_key], reported[target_key])
        near(f"{portfolio_name}/{window}: target covariance vol", covariance["ann_vol"],
             reported["target_covariance_volatility"])
        near(f"{portfolio_name}/{window}: variance shares sum", sum(covariance["variance_risk_contribution"].values()), 1)
        for ticker, share in covariance["variance_risk_contribution"].items():
            near(f"{portfolio_name}/{window}: risk share {ticker}", share,
                 reported["fraction_of_variance_by_asset"][ticker])
        k = math.ceil(.05 * len(returns))
        exact(f"{portfolio_name}/{window}: ES tail count", k, reported["daily_es95_observations"])
        # Explicit order statistic check is separate from the quantile method.
        near(f"{portfolio_name}/{window}: ES order statistic", -np.sort(returns.to_numpy())[:k].mean(),
             reported["daily_es95_loss"])
        if window == "five_year":
            navs[portfolio_name] = nav
            exact(f"{portfolio_name}: saved daily dates", returns.index.equals(SAVED_RETURNS.index), True)
            near(f"{portfolio_name}: max saved daily return discrepancy",
                 float(np.max(np.abs(returns.to_numpy() - SAVED_RETURNS[portfolio_name].to_numpy()))), 0)
        peak_date = nav.loc[:(nav / nav.cummax() - 1).idxmin()].idxmax()
        result["windows"][window] = {
            **independent,
            "target_covariance_ann_vol": covariance["ann_vol"],
            "target_covariance_variance_risk_contributions": covariance["variance_risk_contribution"],
            "max_drawdown_peak_date": str(peak_date.date()),
            "max_drawdown_trough_date": str((nav / nav.cummax() - 1).idxmin().date()),
        }

    # Target dollar positions are initialized at the Nov 6 adjusted close.
    # This is a five-session buy-and-hold counterfactual, not the drifted
    # weights resulting from the earlier quarterly backtest.
    w = pd.Series({t: x for t, x in weights.items() if x > 0})
    units = BUDGET * w / P.loc["2026-11-06", w.index]
    ending_value = float(units @ P.loc[END, w.index])
    week_return = ending_value / BUDGET - 1
    near(f"{portfolio_name}: fixed-target week return", week_return, allocation["week_total_return"])
    near(f"{portfolio_name}: fixed-target week PNL", ending_value - BUDGET,
         allocation["week_pnl_on_7000"])
    result["week_fixed_target_return"] = week_return
    result["week_quarterly_drifted_return"] = float(navs[portfolio_name].loc[END] / navs[portfolio_name].loc["2026-11-06"] - 1)
    result["week_fixed_target_pnl_usd"] = ending_value - BUDGET
    result["stress_results"] = {}
    for stress_name, scenario in REVIEW["stresses"].items():
        # Apply shocks to individual initial dollar positions and add PNL.
        stress_pnl = sum(BUDGET * weights[t] * scenario["shocks"].get(t, 0) for t in weights)
        stress_return = stress_pnl / BUDGET
        reported = allocation["stress_results"][stress_name]
        near(f"{portfolio_name}/{stress_name}: stress return", stress_return, reported["return"])
        near(f"{portfolio_name}/{stress_name}: stress dollars", stress_pnl, reported["pnl_usd"])
        result["stress_results"][stress_name] = {"return": stress_return, "pnl_usd": stress_pnl}
    weighted_tail_returns = sum(weights[t] * P[t].pct_change(fill_method=None).loc[tail_dates] for t in weights)
    near(f"{portfolio_name}: NVDA worst decile mean", tail_nvda.loc[tail_dates].mean(),
         allocation["nvda_worst_decile"]["nvda_mean_return"])
    near(f"{portfolio_name}: fixed-target worst decile mean", weighted_tail_returns.mean(),
         allocation["nvda_worst_decile"]["portfolio_fixed_weight_mean_return"])
    exact(f"{portfolio_name}: worst decile number of days", len(tail_dates), allocation["nvda_worst_decile"]["n_days"])
    results[portfolio_name] = result

for label, key, budget in [("old5000", "prior7", 5000), ("old7000", "prior7", 7000),
                           ("new7000", "conviction8", 7000), ("entry7000", "conviction_entry", 7000)]:
    near(f"{label}: historical dollar vol", results[key]["windows"]["five_year"]["ann_vol"] * budget,
         REVIEW["dollar_risk_comparison"][label]["historical_ann_vol_dollars"])

target = REVIEW["allocations"]["conviction8"]["weights"]
entry = REVIEW["allocations"]["conviction_entry"]["weights"]
for ticker, deferred in REVIEW["entry_policy"]["deferred_usd"].items():
    near(f"entry: deferred {ticker}", BUDGET * (target.get(ticker, 0) - entry.get(ticker, 0)), deferred)
near("entry: total deferred matches extra SGOV", sum(REVIEW["entry_policy"]["deferred_usd"].values()),
     BUDGET * (entry["SGOV"] - target["SGOV"]))

bootstrap = {}
old_weights = REVIEW["allocations"]["prior7"]["weights"]
new_weights = REVIEW["allocations"]["conviction8"]["weights"]
tickers = sorted(set(old_weights) | set(new_weights))
for label, start, end in [("five_year", "2021-11-12", END), ("two_year", "2024-11-13", END),
                           ("two_year_pre_event", "2024-11-13", "2026-11-06")]:
    r = P.loc[start:end, tickers].pct_change(fill_method=None).iloc[1:]
    bootstrap[label] = paired_stationary_bootstrap_fixed_weight_vol_ratio(
        r, old_weights, new_weights, mean_block_length=20, replications=2000, seed=20261113)

issues = [x for x in checks if not x["passed"]]
audit = {
    "audit_scope": "Independent price-unit reconstruction of all sixteen quarterly-rebalanced portfolios over all four saved windows; independent covariance risk shares, week returns, allocation dollars, ES, stress arithmetic, and paired block-bootstrap diagnostic.",
    "audited_file": str(SOURCE),
    "audited_file_sha256": hashlib.sha256(SOURCE_BYTES).hexdigest(),
    "source_adjusted_prices_sha256": hashlib.sha256((BASE / "market_data_extended/adjusted_close.csv").read_bytes()).hexdigest(),
    "passed": not issues,
    "number_of_checks": len(checks),
    "number_failed": len(issues),
    "maximum_numerical_discrepancy": max(x.get("absolute_error", 0) for x in checks),
    "material_issues": issues,
    "interpretive_caveats": [
        "New weights were selected after the observed news and prices. All their historical comparisons are retrospective hypothetical diagnostics, not prospective or out-of-sample validation.",
        "Week returns assume target-weight portfolios initiated at the Nov 6 close; they differ from the five-year quarterly strategy's drifted weights in that week. Both values are retained below.",
        "Covariance risk contributions use fixed target weights. The reported quarterly backtest volatility includes weight drift and therefore need not equal target covariance volatility.",
        "The conviction target has 5% SGOV, versus 10% in both the prior target and new entry. Its 95% equity allocation is higher than those 90% equity comparators. Risk differences therefore reflect both security composition and total equity exposure.",
        "Maximum historical drawdown and daily ES are sample descriptions, not a maximum future loss, annual loss forecast, or guarantee.",
        "CEG prelisting NaNs were excluded by selecting positive-weight holdings before return arithmetic. No portfolio dates were truncated to CEG's listing.",
        "Paired stationary bootstrap tests historical sampling sensitivity under a 20-day mean block length. These percentile ranges are not future confidence bounds and do not model structural regime changes.",
        "All stress shocks, including the VTI indirect event effect, are explicit hypothetical assumptions with no assigned probability; they are not a fund holdings look-through calculation.",
    ],
    "independent_results": results,
    "paired_stationary_bootstrap": bootstrap,
    "comparative_differences": {name: {"versus_prior7": {window: {metric: results[name]["windows"][window][metric] - results["prior7"]["windows"][window][metric] for metric in ("ann_vol", "max_drawdown", "cagr", "es95_daily_loss")} for window in ("five_year", "two_year", "one_year")}, "versus_conviction8": {window: {metric: results[name]["windows"][window][metric] - results["conviction8"]["windows"][window][metric] for metric in ("ann_vol", "max_drawdown", "cagr", "es95_daily_loss")} for window in ("five_year", "two_year", "one_year")}} for name in results if name.startswith("conviction")},
    "checks": checks,
}
destination = BASE / "analysis/conviction_independent_audit.json"
destination.write_text(json.dumps(audit, ensure_ascii=False, indent=2, allow_nan=False))
print(json.dumps({"passed": audit["passed"], "checks": len(checks), "failed": len(issues),
                  "max_error": audit["maximum_numerical_discrepancy"], "issues": issues,
                  "headline": {k: results[k] for k in ("prior7", "conviction8", "conviction_entry")},
                  "bootstrap": bootstrap, "saved_to": str(destination)}, indent=2))
