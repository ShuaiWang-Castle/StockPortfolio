from pathlib import Path
import json
import csv

BASE=Path(__file__).resolve().parent
FORMS={'10-K','10-Q','10-K/A','10-Q/A'}
TAGS={
 'revenue':['RevenueFromContractWithCustomerExcludingAssessedTax','Revenues'],
 'net_income':['NetIncomeLoss'], 'operating_income':['OperatingIncomeLoss'],
 'cfo':['NetCashProvidedByUsedInOperatingActivities'],
 'cash_capex':['PaymentsToAcquirePropertyPlantAndEquipment','PaymentsToAcquireProductiveAssets'],
 'sbc':['ShareBasedCompensation'],
 'investment_gains':['GainLossOnInvestments'],
 'depreciation_amortization':['DepreciationAndAmortization','DepreciationDepletionAndAmortization','DepreciationDepletionAndAmortizationPropertyPlantAndEquipment'],
 'acquisition_cash':['PaymentsToAcquireBusinessesNetOfCashAcquired'],
 'share_repurchases_cash':['PaymentsForRepurchaseOfCommonStock'],
 'cash_tax':['IncomeTaxesPaidNet'],
 'income_tax':['IncomeTaxExpenseBenefit'],
}
PERIODS={
 'QCOM':[('fy2026','2025-09-29','2026-09-27',1)],
 'CRM':[('fy2026','2025-02-01','2026-01-31',1),('h1fy2027','2026-02-01','2026-07-31',1),('h1fy2026','2025-02-01','2025-07-31',-1)]
}
OUT={}
with (BASE.parent/'market_data_extended'/'close.csv').open() as handle:
 price_rows=list(csv.DictReader(handle))
price_row=price_rows[-1]
assert list(price_row.values())[0]=='2026-11-13', price_row
BALANCE_TAGS={
 'cash':['CashAndCashEquivalentsAtCarryingValue'],
 'marketable_securities_current':['MarketableSecuritiesCurrent','AvailableForSaleSecuritiesDebtSecuritiesCurrent'],
 'funded_debt_current':['DebtCurrent','LongTermDebtCurrent'],
 'funded_debt_noncurrent':['LongTermDebtNoncurrent'],
}
REPORTED_EPS={'QCOM':12.70,'CRM':2.19+2.07+2.42+4.29}
for ticker,periods in PERIODS.items():
 facts=json.load(open(BASE/'raw'/f'{ticker}_facts.json'))['facts']
 gaap=facts['us-gaap']
 row={}
 for key,tags in TAGS.items():
  components={}
  for label,start,end,sign in periods:
   found=[]
   for tag in tags:
    found=[dict(x,tag=tag,sign=sign) for x in gaap.get(tag,{}).get('units',{}).get('USD',[]) if x.get('start')==start and x['end']==end and x.get('form') in FORMS and x['filed']<='2026-11-13']
    if found:break
   if found:components[label]=sorted(found,key=lambda x:x['filed'])[-1]
  row[key]={'ttm':sum(x['sign']*x['val'] for x in components.values()) if len(components)==len(periods) else None,'components':components}
 shares=[x for x in facts.get('dei',{}).get('EntityCommonStockSharesOutstanding',{}).get('units',{}).get('shares',[]) if x['filed']<='2026-11-13' and x.get('form') in FORMS]
 row['latest_cover_shares']=sorted(shares,key=lambda x:x['end'])[-1]
 row['ttm_period_start']=periods[0][1] if ticker=='QCOM' else '2025-08-01'
 row['ttm_period_end']=periods[-1][2] if ticker=='QCOM' else '2026-07-31'
 row['strict_cash_fcf']=row['cfo']['ttm']-row['cash_capex']['ttm']
 row['strict_cash_fcf_minus_cf_sbc']=row['strict_cash_fcf']-row['sbc']['ttm']
 row['price_date']='2026-11-13'
 row['price_session']='US regular-session close'
 row['price_usd']=float(price_row[ticker])
 row['price_source']='market_data_extended/close.csv; Yahoo chart query2 raw and timestamps in market_data_extended/provenance.json'
 row['market_cap_latest_cover_shares_usd']=row['price_usd']*row['latest_cover_shares']['val']
 row['pe_current_cover_market_cap_over_ttm_net_income']=row['market_cap_latest_cover_shares_usd']/row['net_income']['ttm']
 row['reported_diluted_eps_ttm']=REPORTED_EPS[ticker]
 row['reported_diluted_eps_method']='FY2026 annual diluted EPS' if ticker=='QCOM' else 'Sum four individual quarterly diluted EPS, 2.19 + 2.07 + 2.42 + 4.29; changed share counts mean this differs from annual-plus-half-year EPS arithmetic'
 row['pe_price_over_reported_diluted_eps']=row['price_usd']/row['reported_diluted_eps_ttm']
 row['fcf_yield']=row['strict_cash_fcf']/row['market_cap_latest_cover_shares_usd']
 row['fcf_minus_sbc_yield_sensitivity']=row['strict_cash_fcf_minus_cf_sbc']/row['market_cap_latest_cover_shares_usd']
 row['sbc_fraction_fcf']=row['sbc']['ttm']/row['strict_cash_fcf']
 row['balance_sheet_date']=row['ttm_period_end']
 row['balance_sheet']={}
 for key,tags in BALANCE_TAGS.items():
  found=[]
  for tag in tags:
   found=[dict(x,tag=tag) for x in gaap.get(tag,{}).get('units',{}).get('USD',[]) if 'start' not in x and x['end']==row['balance_sheet_date'] and x.get('form') in FORMS and x['filed']<='2026-11-13']
   if found:break
  assert found,(ticker,key)
  row['balance_sheet'][key]=sorted(found,key=lambda x:x['filed'])[-1]
 bs=row['balance_sheet']
 row['cash_plus_current_marketable_securities']=bs['cash']['val']+bs['marketable_securities_current']['val']
 row['funded_debt_carrying_value']=bs['funded_debt_current']['val']+bs['funded_debt_noncurrent']['val']
 row['net_funded_debt_excluding_leases']=row['funded_debt_carrying_value']-row['cash_plus_current_marketable_securities']
 row['notes']=[
  'All USD quantities are in dollars; ratios are decimal fractions except P/E.',
  'FCF = GAAP CFO less cash purchases of property/equipment or productive assets; excludes acquisitions and financing cash flows.',
  'FCF minus stock compensation is only a dilution/cash-flow sensitivity, not a GAAP metric or a literal cash expense.',
  'Current cover-share market cap is an estimate based on latest public filing cover shares, not a live verified share register.',
  'Balance-sheet quantities are historical period-end figures and are not reconstructed Nov13 balances.',
 ]
 if ticker=='CRM':
  row['notes'].append('Aug20 cover shares predate final ASR settlement expected in October; final share count was not verified. Market-cap-based valuation ratios may change with subsequent buyback settlement.')
 OUT[ticker]=row
 print(ticker,'shares',row['latest_cover_shares']['val'],'asof',row['latest_cover_shares']['end'])
 print('TTM_USD_bn',{k:round(v['ttm']/1e9,6) if v['ttm'] is not None else None for k,v in row.items() if k in TAGS})
 print('FCF',row['strict_cash_fcf']/1e9,'FCF_SBC',row['strict_cash_fcf_minus_cf_sbc']/1e9)
 print('Current valuation', {k:row[k] for k in ['price_usd','pe_price_over_reported_diluted_eps','pe_current_cover_market_cap_over_ttm_net_income','fcf_yield','fcf_minus_sbc_yield_sensitivity','net_funded_debt_excluding_leases']})
(BASE/'financial_metrics.json').write_text(json.dumps(OUT,indent=2))
