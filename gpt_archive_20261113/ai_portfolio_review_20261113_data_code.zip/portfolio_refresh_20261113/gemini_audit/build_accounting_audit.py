"""Assemble primary-source claim audit; rerun compute_financials.py first."""
from pathlib import Path
import json

BASE = Path(__file__).resolve().parent
financials = json.loads((BASE / 'financial_metrics.json').read_text())

sources = {
    'qcom_10k': {'url': 'https://www.sec.gov/Archives/edgar/data/804328/000080432826000128/qcom-20260927.htm', 'filed': '2026-11-04', 'period_end': '2026-09-27', 'type': '10-K'},
    'qcom_release': {'url': 'https://www.sec.gov/Archives/edgar/data/804328/000080432826000127/qcom092726erex991.htm', 'published': '2026-11-04', 'period_end': '2026-09-27', 'type': 'Earnings release, SEC exhibit 99.1'},
    'qcom_new_notes': {'url': 'https://www.sec.gov/Archives/edgar/data/804328/000110465926127163/tm2629667d1_8k.htm', 'filed': '2026-11-13', 'officers_certificate_date': '2026-11-12', 'type': '8-K'},
    'qcom_accelerators': {'url': 'https://www.qualcomm.com/news/releases/2025/10/qualcomm-unveils-ai200-and-ai250-redefining-rack-scale-data-cent', 'published': '2025-10-28', 'type': 'Official product announcement'},
    'crm_10q': {'url': 'https://www.sec.gov/Archives/edgar/data/1108524/000110852426000190/crm-20260731.htm', 'filed': '2026-08-27', 'period_end': '2026-07-31', 'type': '10-Q'},
    'crm_10k': {'url': 'https://www.sec.gov/Archives/edgar/data/1108524/000110852426000060/crm-20260131.htm', 'filed': '2026-03-02', 'period_end': '2026-01-31', 'type': '10-K'},
    'crm_q2_release': {'url': 'https://www.sec.gov/Archives/edgar/data/1108524/000110852426000187/crm-q2fy27xexhibit991.htm', 'published': '2026-08-26', 'period_end': '2026-07-31', 'type': 'Earnings release, SEC exhibit 99.1'},
    'crm_q4_release': {'url': 'https://investor.salesforce.com/news/news-details/2026/Salesforce-Delivers-Record-Fourth-Quarter-Fiscal-2026-Results/default.aspx', 'period_end': '2026-01-31', 'type': 'Official earnings release'},
    'crm_braze': {'url': 'https://www.sec.gov/Archives/edgar/data/1108524/000119312526425881/d516983dex991.htm', 'published': '2026-10-20', 'type': 'Acquisition announcement, SEC exhibit 99.1'},
    'crm_contentful_closed': {'url': 'https://www.sec.gov/Archives/edgar/data/1108524/000110852426000195/forms-8xcontentfulequitypl.htm', 'transaction_date': '2026-09-01', 'type': 'S-8 disclosing acquisition completion'},
    'crm_fin_closed': {'url': 'https://www.salesforce.com/news/press-releases/2026/09/10/salesforce-completes-acquisition-of-fin/', 'published': '2026-09-10', 'type': 'Official acquisition completion announcement'},
    'pltr_10q': {'url': 'https://www.sec.gov/Archives/edgar/data/1321655/000132165526000048/pltr-20260930.htm', 'filed': '2026-11-03', 'period_end': '2026-09-30', 'type': '10-Q'},
    'qcom_companyfacts': {'url': 'https://data.sec.gov/api/xbrl/companyfacts/CIK0000804328.json', 'retrieved': '2026-11-13', 'type': 'SEC Companyfacts'},
    'crm_companyfacts': {'url': 'https://data.sec.gov/api/xbrl/companyfacts/CIK0001108524.json', 'retrieved': '2026-11-13', 'type': 'SEC Companyfacts'},
}

audit = {
    'cutoff': '2026-11-13 US regular-session close',
    'scope': 'Audit Gemini valuation and economic-exposure claims for QCOM/CRM; supplementary PLTR hosting evidence. Apple audit is provided separately by the news agent.',
    'units': 'USD amounts are actual dollars; yield figures are decimal fractions. Historical financial statements and current prices have different dates.',
    'financials': financials,
    'sources': sources,
    'claims': [
        {'company': 'QCOM', 'claim': 'Current share price $175.91', 'verdict': 'Different snapshot; replace with verified Nov13 regular close $172.47.', 'sources': ['market_data_extended/provenance.json']},
        {'company': 'QCOM', 'claim': 'P/E 19-20 proves cheap valuation', 'verdict': 'Basis/date unclear. Current FY26 GAAP diluted-EPS P/E is 13.58, but annual earnings include a large tax allowance release. Company non-GAAP EPS is a different definition, not a clean normalized GAAP measure.', 'sources': ['qcom_release', 'qcom_10k']},
        {'company': 'QCOM', 'claim': 'Free cash flow $10.42bn', 'verdict': 'Not latest FY26 strict cash FCF: CFO $11.145bn minus productive-asset purchases $2.494bn equals $8.651bn.', 'sources': ['qcom_10k']},
        {'company': 'QCOM', 'claim': 'Net cash', 'verdict': 'Incorrect at Sep27: cash plus current securities $7.681bn versus funded-debt carrying value $15.112bn, net debt $7.431bn, before leases. A later $4bn note sale is disclosed in Nov13 filing; both new debt and cash proceeds must be considered.', 'sources': ['qcom_10k', 'qcom_new_notes']},
        {'company': 'QCOM', 'claim': 'Only edge AI; no data-center electricity or Taiwan exposure', 'verdict': 'Incorrect as a categorical statement. It has dedicated rack-scale data-center products and a FY27 data-center revenue target. TSMC is an identified foundry supplier; there is also diversification through Samsung and GlobalFoundries. Exact geographic wafer mix was not established.', 'sources': ['qcom_10k', 'qcom_release', 'qcom_accelerators']},
        {'company': 'CRM', 'claim': 'Price $217.42 and P/E 19.7', 'verdict': 'Close to an adjacent market snapshot. At Nov13 close $217.84, sum-of-four-quarter diluted EPS $10.97 gives 19.86x. Current cover-share market cap / TTM net income gives 18.55x; differing share denominators explain much of the gap after the ASR.', 'sources': ['crm_q2_release', 'crm_q4_release', 'crm_companyfacts']},
        {'company': 'CRM', 'claim': 'EPS grew 118%, demonstrating operating acceleration', 'verdict': 'Reported Q2 diluted EPS grew about 119%, but Q2 GAAP operating income was essentially flat: $2.331bn versus $2.332bn. Strategic investment gains contributed $2.43 of the $4.29 GAAP EPS per the company, using a 23.5% tax rate.', 'sources': ['crm_q2_release', 'crm_10q']},
        {'company': 'CRM', 'claim': 'Free cash flow grew 81.5%', 'verdict': 'Approximately true for the single quarter: $1.098bn versus $0.605bn, +81.49%. Full-year FY27 CFO/FCF growth guidance is only 4-5%; quarterly seasonality and working-capital timing preclude extrapolation.', 'sources': ['crm_q2_release']},
        {'company': 'CRM', 'claim': 'Zero data-center cost and depreciation', 'verdict': 'False. CRM uses third-party cloud infrastructure and its own hardware in leased facilities. Hosting and generative-AI usage costs affect cost of revenue and R&D. Low own cash capex does not mean no compute cost or grid dependence.', 'sources': ['crm_10k', 'crm_10q']},
        {'company': 'PLTR', 'claim': 'Software has no data-center electricity exposure', 'verdict': 'False. Its March2026 amended cloud-hosting contract contains $5.6bn minimum commitments through Feb2036; Q3 hosting costs increased $135m in cost of revenue and $21m in R&D. These are vendor obligations and operating costs, not proof it owns all data centers.', 'sources': ['pltr_10q']},
    ],
    'qcom_accounting': {
        'source_ids': ['qcom_10k', 'qcom_release', 'qcom_new_notes'],
        'fy26_revenue_growth': -0.03,
        'fy26_gaap_eps': 12.70,
        'fy26_company_non_gaap_eps': 10.54,
        'fy26_company_non_gaap_pe': financials['QCOM']['price_usd']/10.54,
        'tax_valuation_allowance_release_usd_approx': 5.7e9,
        'tax_release_gaap_eps_contribution_company_disclosed': 5.32,
        'tax_release_exclusion_only_eps_sensitivity': 12.70-5.32,
        'tax_release_exclusion_only_pe_sensitivity': financials['QCOM']['price_usd']/(12.70-5.32),
        'tax_sensitivity_warning': 'Removes only the disclosed after-tax allowance release. This is not a full normalized P/E; it leaves SBC, acquisition charges, investment gains, and other tax items untouched.',
        'acquisitions_and_other_investments_net_of_acquired_cash_fy26_usd': 1.577e9,
        'acquisition_cash_warning': 'Combined cash-flow line includes other investments and must not be called solely acquisition consideration.',
        'stock_issued_in_acquisitions_fy26_usd': 4.512e9,
        'funded_debt_carrying_value_warning': 'Sep27 current debt $2.492bn includes $0.499bn commercial paper. Noncurrent carrying value $12.620bn; do not add the CP twice.',
        'post_statement_notes': {'filed': '2026-11-13', 'officers_certificate_date': '2026-11-12', 'aggregate_principal_usd': 4e9, 'tranches': [{'principal':750e6,'coupon':0.05,'maturity_year':2028},{'principal':750e6,'coupon':0.0515,'maturity_year':2029},{'principal':1e9,'coupon':0.0535,'maturity_year':2031},{'principal':750e6,'coupon':0.056,'maturity_year':2033},{'principal':750e6,'coupon':0.058,'maturity_year':2036}], 'warning': 'This later financing makes Sep27 gross debt stale; new cash proceeds and uses must also be included to reconstruct current net debt.'},
        'customer_warrant': {'issued': '2026-09', 'counterparty': 'Affiliate of Amazon Data Services, Inc.', 'maximum_shares':25e6,'exercise_price':161.26,'term_years':10,'initially_vested_shares_approx':4e6,'grant_date_fair_value_usd_approx':1.8e9,'purchase_milestone_maximum_usd':60e9,'accounting':'Recorded as a reduction to revenue as related revenue is recognized over vesting term.','warning':'Conditional milestone ceiling is not guaranteed backlog or contracted revenue; all 25m shares were unexercised at Sep27.'},
        'fy26_handset_revenue':24.072e9,
        'fy26_auto_revenue':6.004e9,
        'fy26_iot_revenue':7.132e9,
        'fy27_datacenter_revenue_target':5e9,
        'target_warning':'Management target, not recognized historical revenue or certainty.',
        'foundries':['TSMC','Samsung','GlobalFoundries'],
    },
    'crm_accounting': {
        'source_ids': ['crm_10q', 'crm_10k', 'crm_q2_release'],
        'q2_gaap_eps_current':4.29,
        'q2_gaap_eps_prior':1.96,
        'q2_gaap_eps_growth':4.29/1.96-1,
        'q2_investment_gains_usd':2.613e9,
        'q2_operating_income_current':2.331e9,
        'q2_operating_income_prior':2.332e9,
        'q2_investment_gain_gaap_eps_effect':2.43,
        'investment_gain_effect_assumed_tax_rate_company_disclosed':0.235,
        'q2_eps_excluding_only_investment_gain_effect':4.29-2.43,
        'q2_prior_eps_excluding_only_investment_gain_effect':1.96,
        'q2_fcf_current':1.098e9,
        'q2_fcf_prior':0.605e9,
        'q2_fcf_growth':1.098/0.605-1,
        'fy27_cfo_fcf_growth_guidance_low':0.04,
        'fy27_cfo_fcf_growth_guidance_high':0.05,
        'strategic_investments_balance_july31':11.324e9,
        'strategic_investments_warning':'Portfolio carrying value includes publicly held and privately held investments; it is not all private AI investment value. Strategic gains are removed in CFO reconciliation and are not repeated cash operating receipts.',
        'debt_jan31':14.439e9,
        'debt_july31':39.288e9,
        'asr_size':25e9,
        'asr_initial_delivery_shares':103e6,
        'asr_final_settlement_expected':'2026-10 (Aug26 guidance; final delivered share count not verified)',
        'q2_interest_expense_current':473e6,
        'q2_interest_expense_prior':67e6,
        'subsequent_acquisitions':[{'name':'Contentful','closed':'2026-09-01','source_id':'crm_contentful_closed'},{'name':'Fin','closed':'2026-09-10','source_id':'crm_fin_closed'},{'name':'Braze','announced':'2026-10-20','status_as_of_announcement':'Pending','enterprise_value_usd_approx':5.66e9,'cash_price_per_share':47.50,'source_id':'crm_braze','warning':'Enterprise value is not identical to the transaction cash equity outlay.'}],
        'current_balance_warning':'July31 cash/debt do not include subsequent Contentful/Fin closing cash flows, pending Braze financing, subsequent operating cash flows, or any final ASR settlement. Do not present these as exact Nov13 balances.',
        'hosting':'Third-party cloud infrastructure and own hardware in third-party facilities; hosting/generative-AI costs recognized in cost of revenue and R&D.',
        'depreciation_warning':'TTM D&A $3.922bn includes acquired intangibles, fixed assets, and lease/impairment items; it is not a separately disclosed data-center depreciation figure.',
        'ai_arr_warning':'Agentforce/Data360 ARR is a management operating metric, not recognized GAAP AI revenue. Q2 scope includes Slackbot and Headless360, impairing naive growth comparability.',
    },
    'pltr_hosting': {
        'source_id':'pltr_10q','amendment_date':'2026-03','commitment_end':'2036-02-29','minimum_commitment_usd':5.6e9,'annual_minimum_low_usd':268e6,'annual_minimum_high_usd':979e6,'q3_cost_of_revenue_hosting_increase_usd':135e6,'q3_rd_hosting_increase_usd':21e6,'warning':'Multi-year purchase commitment is not a current quarterly expense or automatically funded debt; it demonstrates material dependence on compute suppliers.'
    },
    'portfolio_judgment': {
        'status':'Analytical inference from financial evidence, not a price forecast.',
        'qcom':'Represents mobile/edge AI, auto/IoT, and a growing data-center option. It diversifies semiconductor end markets but retains foundry, hardware-cycle, customer, and data-center execution risk. Net cash and zero-Taiwan claims must be discarded. FY26 cash-FCF yield 4.69%, dropping to 2.82% under the SBC subtraction sensitivity, is less compelling than raw tax-inflated P/E suggests.',
        'crm':'Represents enterprise software monetization with limited own cash capex. Current-estimate cash-FCF yield 8.45% and SBC-adjusted sensitivity 6.41% are economically more interesting than QCOM on this screen, but acquisitions, significantly higher debt, cloud bills, investment gains, and share-count uncertainty need explicit treatment.',
        'if_only_one_additional_name':'For a portfolio retaining NVDA15% plus GOOGL/MSFT/META, CRM at no more than 5% is the more distinct optional business-model exposure, conditional on accepting acquisition/integration and balance-sheet risk. QCOM is an optional alternative for an explicit edge/auto thesis; neither is necessary to make a $7,000 portfolio function and neither is a true downside hedge.',
        'implementation':'Do not add all names merely to lengthen the list. Finance a chosen satellite from the existing equity allocation, keeping any intentionally chosen defensive allocation explicit. Shares, prices, fees and tax lots must be handled separately at execution.',
    },
    'limitations': [
        'This screen estimates valuation multiples and cash yield, not intrinsic value or DCF fair value.',
        'Historical cash flow can be influenced by working capital and tax timing; no perpetuity-growth assumption is imposed.',
        'QCOM and CRM have different fiscal dates; raw multiples are not fully comparable without business and accounting adjustments.',
        'Reported EPS, company non-GAAP EPS, current-common market cap / TTM NI, and SBC cash sensitivity are explicitly different definitions.',
        'No exact current CRM share count after final ASR settlement was verified by the cutoff.',
        'No complete geographic semiconductor supply mix was established; zero exposure cannot be inferred from absent disclosure.',
    ],
}

destination = BASE / 'accounting_and_exposure_audit.json'
destination.write_text(json.dumps(audit, indent=2, ensure_ascii=False))
print(destination)
print('Financial companies:', ', '.join(financials), 'Claims:',len(audit['claims']), 'Primary sources:',len(sources))
