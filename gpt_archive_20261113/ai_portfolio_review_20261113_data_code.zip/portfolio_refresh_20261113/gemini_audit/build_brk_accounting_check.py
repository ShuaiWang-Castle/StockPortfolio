"""Coarse Berkshire share-class and accounting check, not an intrinsic-value model."""
from pathlib import Path
from datetime import datetime, timezone
import concurrent.futures
import hashlib
import json
import urllib.request

import pandas as pd

OUT = Path(__file__).resolve().parent
RAW = OUT / "brk_primary_sources"
RAW.mkdir(parents=True, exist_ok=True)
SOURCES = {
    "q3_10q": {"url": "https://www.berkshirehathaway.com/qtrly/3rdqtr26.pdf", "filename": "3rdqtr26.pdf",
               "search_ref": "turn129view0", "period_end": "2026-09-30",
               "relevant_pdf_pages_zero_based": [0, 2, 3, 21, 22, 38, 48, 49]},
    "q3_release": {"url": "https://www.berkshirehathaway.com/news/nov0726.pdf", "filename": "nov0726.pdf",
                   "search_ref": "turn129view1", "release_date": "2026-11-07"},
    "fy2025_release": {"url": "https://www.berkshirehathaway.com/news/feb2826.pdf", "filename": "feb2826.pdf",
                       "search_ref": "turn130view0", "release_date": "2026-02-28"},
    "q3_10q_sec": {"url": "https://www.sec.gov/Archives/edgar/data/1067983/000119312526452412/brka-20260930.htm",
                   "search_ref": "turn129view2"},
}


def download(key):
    source = SOURCES[key]
    req = urllib.request.Request(source["url"], headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=35) as response:
            raw = response.read()
        assert raw.startswith(b"%PDF"), (key, raw[:40])
        (RAW / source["filename"]).write_bytes(raw)
        return key, {"saved_path": str(RAW / source["filename"]), "sha256": hashlib.sha256(raw).hexdigest(),
                     "bytes": len(raw), "retrieved_utc": datetime.now(timezone.utc).isoformat()}
    except Exception as exc:
        return key, {"download_error": repr(exc), "web_tool_read_successful": True}


price = float(pd.read_csv(OUT.parent / "market_data_extended/close.csv", index_col=0).loc["2026-11-13", "BRK-B"])
inputs = {
    "price_usd": price, "price_date": "2026-11-13", "price_basis": "Yahoo normal-session completed close; raw/provenance in market_data_extended",
    "financial_period_end": "2026-09-30", "financial_units": "USD billions except share counts and per-share amounts",
    "economic_b_shares_per_a_share": 1500,
    "september30_class_a_outstanding": 481584,
    "september30_class_b_outstanding": 1405974025,
    "latest_cover_share_date": "2026-10-28",
    "latest_cover_class_a_outstanding": 480476,
    "latest_cover_class_b_outstanding": 1403805594,
    "berkshire_shareholders_equity_billion": 761.368,
    "noncontrolling_interest_billion_excluded_from_book_value": 2.260,
    "operating_earnings_after_tax_billion": {"FY2025": 44.486, "9M2025": 34.286, "9M2026": 37.034,
                                            "Q3_2025": 13.485, "Q3_2026": 12.705},
    "gaap_net_income_attributable_billion": {"FY2025": 66.968, "9M2025": 47.769, "9M2026": 57.885,
                                            "Q3_2025": 30.796, "Q3_2026": 22.112},
    "after_tax_investment_gains_billion": {"FY2025": 30.737, "9M2025": 17.243, "9M2026": 20.851,
                                         "Q3_2026": 9.407},
    "after_tax_investment_impairment_billion_signed": {"FY2025": -8.255, "9M2025": -3.760, "9M2026": 0.0},
    "insurance_and_other_cash_cash_equivalents_billion": 36.034,
    "insurance_and_other_short_term_treasury_bills_billion": 336.735,
    "unsettled_treasury_purchase_payables_billion": 20.489,
    "railroad_utilities_energy_cash_billion": 4.666,
    "insurance_float_billion": 178.5,
    "insurance_cash_treasuries_gross_billion_subscope": 230.941,
    "insurance_only_unsettled_treasury_purchases_billion_rounded": 15.4,
    "consolidated_cash_treasury_minimum_for_repurchases_billion": 30.0,
    "insurance_after_tax_investment_income_9m2026_billion": 8.472,
    "insurance_after_tax_investment_income_9m2025_billion": 9.441,
}
economic_shares_sep = inputs["september30_class_a_outstanding"] * 1500 + inputs["september30_class_b_outstanding"]
economic_shares_latest = inputs["latest_cover_class_a_outstanding"] * 1500 + inputs["latest_cover_class_b_outstanding"]
book = inputs["berkshire_shareholders_equity_billion"] * 1e9
market_cap = economic_shares_latest * price
ttm_operating = inputs["operating_earnings_after_tax_billion"]["FY2025"] + inputs["operating_earnings_after_tax_billion"]["9M2026"] - inputs["operating_earnings_after_tax_billion"]["9M2025"]
ttm_gaap = inputs["gaap_net_income_attributable_billion"]["FY2025"] + inputs["gaap_net_income_attributable_billion"]["9M2026"] - inputs["gaap_net_income_attributable_billion"]["9M2025"]
ttm_gains = inputs["after_tax_investment_gains_billion"]["FY2025"] + inputs["after_tax_investment_gains_billion"]["9M2026"] - inputs["after_tax_investment_gains_billion"]["9M2025"]
ttm_impairment = inputs["after_tax_investment_impairment_billion_signed"]["FY2025"] + inputs["after_tax_investment_impairment_billion_signed"]["9M2026"] - inputs["after_tax_investment_impairment_billion_signed"]["9M2025"]
assert abs(ttm_operating + ttm_gains + ttm_impairment - ttm_gaap) < 1e-9
net_liquidity = inputs["insurance_and_other_cash_cash_equivalents_billion"] + inputs["insurance_and_other_short_term_treasury_bills_billion"] - inputs["unsettled_treasury_purchase_payables_billion"]
results = {
    "september30_b_equivalent_shares": economic_shares_sep,
    "latest_cover_b_equivalent_shares": economic_shares_latest,
    "book_value_per_b_equivalent_at_september30": book / economic_shares_sep,
    "price_to_reported_book_per_b_share": price / (book / economic_shares_sep),
    "latest_share_based_market_cap_billion": market_cap / 1e9,
    "latest_share_market_cap_to_september30_book": market_cap / book,
    "ttm_period_end": "2026-09-30", "ttm_formula": "FY2025 + 9M2026 - 9M2025",
    "ttm_operating_earnings_after_tax_billion": ttm_operating,
    "ttm_gaap_net_income_attributable_billion": ttm_gaap,
    "ttm_investment_gains_billion": ttm_gains,
    "ttm_investment_impairment_billion_signed": ttm_impairment,
    "market_cap_to_ttm_operating_earnings": market_cap / (ttm_operating * 1e9),
    "market_cap_to_ttm_gaap_net_income": market_cap / (ttm_gaap * 1e9),
    "operating_earnings_yield": ttm_operating * 1e9 / market_cap,
    "q3_operating_earnings_growth_yoy": 12.705 / 13.485 - 1,
    "nine_month_operating_earnings_growth_yoy": 37.034 / 34.286 - 1,
    "insurance_and_other_cash_treasuries_gross_billion": 36.034 + 336.735,
    "insurance_and_other_cash_treasuries_net_of_unsettled_purchase_payables_billion": net_liquidity,
    "same_net_liquidity_plus_rail_utilities_cash_billion": net_liquidity + 4.666,
    "insurance_after_tax_investment_income_9m_growth": 8.472 / 9.441 - 1,
}
notes = [
    "Economic share conversion is 1 Class A = 1,500 Class B. Voting equivalence differs and is irrelevant to this valuation arithmetic. Do not value the whole company using only the literal Class B shares outstanding.",
    "Reported book value per B share aligns the September 30 equity and September 30 share count. Current market capitalization instead uses the latest Oct28 cover share count; the market-cap/book ratio has the normal date mismatch and is separately labeled.",
    "Book equity excludes noncontrolling interests. Treasury shares are already excluded from outstanding shares and are already deducted within book equity; do not deduct them a second time.",
    "Berkshire operating earnings are an after-tax company-defined non-GAAP measure, not EBIT or operating cash flow. They exclude realized/unrealized investment gains and specified investment impairments, while retaining insurance investment income, interest, dividends and some FX effects.",
    "GAAP earnings include large mark-to-market equity investment gains. A low GAAP P/E alone does not establish that Berkshire's operating businesses are cheap. Excluded impairments can still reflect real value destruction.",
    "Cash and Treasury bills in Insurance and Other sum to $372.769bn gross; subtract $20.489bn of unpaid Treasury purchases to obtain $352.280bn. Do not add Treasury bills already inside cash equivalents a second time.",
    "Insurance float is a funding liability, not shareholders' surplus cash. The $178.5bn cannot be added to equity or distributed as free cash. Nor is cash minus float alone a full excess-capital valuation, because float is invested across multiple assets and regulatory/business capital is required.",
    "The $30bn repurchase liquidity floor is a policy limit, not a proof that every dollar above it is distributable. Consolidated subsidiaries also have debt, claim liabilities, capital requirements and operating needs.",
    "Holding BRK-B reduces dependence on AI-company earnings but still leaves stock-market, insurance, interest-rate, and operating-business risk. Berkshire itself owns substantial U.S. Treasury bills, so avoiding a Treasury ETF does not imply zero look-through Treasury exposure.",
    "P/B around 1.66 and a roughly 26.7x operating-earnings multiple are coarse accounting reference points, not an intrinsic-value estimate or a demonstrated margin of safety. No allocation is selected by this script.",
]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    for key, metadata in pool.map(download, ["q3_10q", "q3_release", "fy2025_release"]):
        SOURCES[key].update(metadata)
output = {"ticker": "BRK-B", "inputs": inputs, "calculations": results, "sources": SOURCES, "accounting_notes": notes}
(OUT / "brk_accounting_check.json").write_text(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False))
print(json.dumps({"calculations": results, "downloads": {key: source.get("download_error", "ok") for key, source in SOURCES.items() if "filename" in source},
                  "output": str(OUT / "brk_accounting_check.json")}, indent=2))
