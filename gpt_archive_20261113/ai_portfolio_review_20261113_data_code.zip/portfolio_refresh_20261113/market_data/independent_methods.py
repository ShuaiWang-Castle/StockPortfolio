"""Independent valuation-agnostic portfolio checks.

The price-unit backtest is intentionally independent of a daily weight-drift
implementation. No portfolio weights are selected here.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

def price_unit_backtest(adjusted_prices: pd.DataFrame, weights: dict[str,float], price_start: str, price_end: str):
    """Quarterly rebalance at the previous available quarter-end close.

Adjusted-price units represent the provider's reinvested-dividend series.
Returns are anchored to a one-dollar NAV on the supplied start-price date.
Only strictly positive-weight columns are selected; zero×missing IPO prices
must not shorten or contaminate the common history.
"""
    w=pd.Series({t:float(x) for t,x in weights.items() if x>0},dtype=float)
    assert (w>=0).all() and abs(w.sum()-1)<1e-10
    p=adjusted_prices.loc[price_start:price_end,w.index].copy()
    assert p.index.is_monotonic_increasing and not p.index.duplicated().any()
    assert len(p)>1 and not p.isna().any().any() and (p>0).all().all()
    units=w/p.iloc[0]
    nav=[1.0]
    for i in range(1,len(p)):
        previous_date=p.index[i-1];date=p.index[i]
        if date.to_period('Q')!=previous_date.to_period('Q'):
            # Rebalance BEFORE taking the new quarter's first daily return.
            units=w*nav[-1]/p.iloc[i-1]
        nav.append(float(units@p.iloc[i]))
    nav=pd.Series(nav,index=p.index,name='net_asset_value')
    returns=nav.pct_change(fill_method=None).iloc[1:]
    return nav,returns

def independently_recomputed_metrics(nav: pd.Series, returns: pd.Series):
    x=returns.to_numpy(float)
    threshold=np.quantile(x,.05)
    days=(nav.index[-1]-nav.index[0]).days
    return {'ann_vol':float(np.std(x,ddof=1)*np.sqrt(252)),
            'max_drawdown':float(np.min(nav.to_numpy()/np.maximum.accumulate(nav.to_numpy())-1)),
            'es95_daily_loss':float(-np.mean(x[x<=threshold])),
            'cagr':float(nav.iloc[-1]**(365.25/days)-1),
            'n_returns':len(x),'total_return':float(nav.iloc[-1]-1)}

def fixed_target_covariance_risk(asset_returns: pd.DataFrame, weights: dict[str,float]):
    w=pd.Series({t:float(x) for t,x in weights.items() if x>0},dtype=float)
    r=asset_returns.loc[:,w.index]
    assert not r.isna().any().any()
    cov=np.cov(r.to_numpy(float),rowvar=False,ddof=1)
    ww=w.to_numpy(float)
    variance=float(ww@cov@ww)
    return {'ann_vol':float(np.sqrt(252*variance)),
            'variance_risk_contribution':dict(zip(w.index,(ww*(cov@ww)/variance).tolist()))}

def paired_stationary_bootstrap_fixed_weight_vol_ratio(asset_returns: pd.DataFrame, old_weights: dict[str,float], new_weights: dict[str,float],
                                                       mean_block_length=20,replications=2000,seed=20261113):
    """Sampling sensitivity of sigma(new)/sigma(old), NOT future-risk CI.

Both portfolios use exactly the same circular stationary-bootstrap indices.
This tests fixed target-weight covariance risk; it does not claim to rerun
quarterly rebalancing on each resampled path.
"""
    tickers=sorted(set(t for t,x in old_weights.items() if x>0)|set(t for t,x in new_weights.items() if x>0))
    r=asset_returns.loc[:,tickers]
    assert not r.isna().any().any()
    old=np.array([old_weights.get(t,0) for t in tickers]);new=np.array([new_weights.get(t,0) for t in tickers])
    assert abs(old.sum()-1)<1e-10 and abs(new.sum()-1)<1e-10
    paired=r.to_numpy(float)@np.stack([old,new],axis=1)
    n=len(paired);rng=np.random.default_rng(seed)
    idx=np.empty((replications,n),dtype=np.int32)
    idx[:,0]=rng.integers(0,n,size=replications)
    for j in range(1,n):
        restart=rng.random(replications)<(1/mean_block_length)
        candidate=(idx[:,j-1]+1)%n
        candidate[restart]=rng.integers(0,n,size=int(restart.sum()))
        idx[:,j]=candidate
    sampled=paired[idx]
    sigmas=np.std(sampled,axis=1,ddof=1)
    ratios=sigmas[:,1]/sigmas[:,0]
    return {'observed_ratio':float(paired[:,1].std(ddof=1)/paired[:,0].std(ddof=1)),
            'bootstrap_percentile_2_5':float(np.quantile(ratios,.025)),
            'bootstrap_median':float(np.median(ratios)),
            'bootstrap_percentile_97_5':float(np.quantile(ratios,.975)),
            'fraction_below_1':float(np.mean(ratios<1)),
            'replications':replications,'mean_block_length':mean_block_length,'seed':seed,
            'sample_returns':n,
            'interpretation':'Paired stationary-bootstrap sampling sensitivity for fixed-weight historical covariance-risk ratio; not a forecast, not true out-of-sample validation, not a quarterly-rebalanced backtest confidence interval.'}
