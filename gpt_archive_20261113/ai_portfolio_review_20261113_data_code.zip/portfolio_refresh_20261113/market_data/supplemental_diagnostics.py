"""Window and rolling-correlation diagnostics; no portfolio selection."""
from pathlib import Path
import json
import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
p=pd.read_csv(OUT/'adjusted_close.csv',index_col=0,parse_dates=True)
r=p.pct_change(fill_method=None)
ai=['NVDA','INTC','MSFT','AMZN','GOOGL','META','AVGO','AMD','MU','TSM','VRT','PLTR','ANET','ORCL','NOW','ASML','ETN','CEG']
windows={'two_year':pd.Timestamp('2024-11-13'),'five_year':pd.Timestamp('2021-11-12')}
rows=[]
meta={}
for name,start in windows.items():
    rr=r.loc[r.index>start]
    meta[name]={'price_start':start.date().isoformat(),'first_return_date':rr.index.min().date().isoformat(),
                'end':rr.index.max().date().isoformat(),'full_window_return_count':len(rr),
                'excluded_from_full_five_year':['CEG'] if name=='five_year' else []}
    for t in ai:
        if name=='five_year' and t=='CEG':continue
        assert rr[t].notna().all()
        rows.append({'ticker':t,'window':name,'ann_vol':float(rr[t].std(ddof=1)*np.sqrt(252)),
                     'rho_nvda':float(rr[t].corr(rr['NVDA'])),'beta_vti':float(rr[t].cov(rr['VTI'])/rr['VTI'].var(ddof=1)),
                     'n_returns':len(rr)})
df=pd.DataFrame(rows)
df['volatility_rank_highest_first']=df.groupby('window')['ann_vol'].rank(ascending=False,method='min').astype(int)
df['correlation_rank_highest_first']=df.groupby('window')['rho_nvda'].rank(ascending=False,method='min').astype(int)
df.to_csv(OUT/'two_vs_five_year_ai_metrics.csv',index=False)

roll_rows=[];rolling={}
for t in ai:
    s=r[t].rolling(126,min_periods=126).corr(r['NVDA'])
    shown=s.loc['2024-11-14':'2026-11-13'].dropna()
    rolling[t]=shown
    roll_rows.append({'ticker':t,'trailing_return_observations_per_estimate':126,'estimate_count':len(shown),
                     'minimum':float(shown.min()),'q25':float(shown.quantile(.25)),'median':float(shown.median()),
                     'q75':float(shown.quantile(.75)),'maximum':float(shown.max()),
                     'minimum_date':shown.idxmin().date().isoformat(),'maximum_date':shown.idxmax().date().isoformat(),
                     'asof_nov6':float(shown.loc['2026-11-06']),'asof_nov13':float(shown.loc['2026-11-13'])})
pd.DataFrame(roll_rows).to_csv(OUT/'rolling_126d_correlation_summary.csv',index=False)
pd.DataFrame(rolling).to_csv(OUT/'rolling_126d_correlation.csv')

# Document provider revisions precisely. Do not manually modify provider prices.
oldfile=ROOT/'ai_expansion_analysis/adjusted_close.csv'
revision=[]
if oldfile.exists():
    old=pd.read_csv(oldfile,index_col=0,parse_dates=True)
    old_r=old.pct_change(fill_method=None)
    for t in old.columns:
        common=old_r.index.intersection(r.index);delta=(old_r.loc[common,t]-r.loc[common,t]).abs()
        for date in delta[delta>.0001].index:
            revision.append({'ticker':t,'date':date.date().isoformat(),'old_adjusted_return':float(old_r.loc[date,t]),
                             'new_adjusted_return':float(r.loc[date,t]),
                             'explanation':'Fresh Yahoo event data contains a Nov2 distribution omitted from the old downloaded snapshot; fresh adjusted history corrects the ex-distribution drop.',
                             'newly_present_distribution':.330 if t=='SGOV' else .311 if t=='IEF' else None})
notes={'windows':meta,'rolling_definition':'Trailing126dailyreturn Pearson correlations versusNVDA; summarize estimate endpoints Nov14,2024 toNov13,2026. First trailingwindow includes returns beforeNov14,2024.',
       'rolling_range_caveat':'Observed minimum/maximum are not confidence or prediction intervals; overlapping windows are highly dependent.',
       'provider_revisions':revision,
       'validation_guidance':['Recompute frozen old portfolio and new candidates from the same fresh data, rather than compare new calculations to the prior printed output.',
          'Any allocation chosen after Nov13 remains retrospectively selected even if an old2025holdout slice is shown. Do not call it a validated out-of-sample strategy.',
          'Covariance estimated onlythroughNov6 can assess a counterfactual Nov6→13 week, but the week has only5observations and cannot validatevariance.',
          'Paired20dayblockbootstrap ofsamejointreturns can diagnose samplingvariation in target-weightvolatilityratios; it doesnot establishfuture-riskconfidence.'],
       'ai_window_metrics':df.to_dict(orient='records'),'rolling_summaries':roll_rows}
(OUT/'supplemental_diagnostics.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2))
print(df.pivot(index='ticker',columns='window',values=['ann_vol','rho_nvda']).round(3).to_string())
print(pd.DataFrame(roll_rows)[['ticker','minimum','maximum','asof_nov6','asof_nov13']].round(3).to_string(index=False))
print('Provider revisions:',revision)
