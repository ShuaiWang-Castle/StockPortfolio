"""Fresh public Yahoo daily data through the completed 2026-11-13 US session.

Read-only market-data research; no portfolio or trading instructions.
All data provenance and complete raw responses are preserved alongside output.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
import concurrent.futures
import urllib.request
import urllib.parse
import json
import hashlib
import time

import numpy as np
import pandas as pd

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
RAW=OUT/'raw'
RAW.mkdir(parents=True,exist_ok=True)
TICKERS=['NVDA','INTC','AMZN','SBUX','KO','PG','JNJ','WMT','XOM','JPM','DUK','SPY','GLD','IEF','SGOV',
         'VTI','MSFT','XLV','GOOGL','META','TSM','AVGO','PLTR','AMD','VRT','MU',
         'ANET','ORCL','NOW','ASML','ETN','CEG']
ASOF='2026-11-13'
START='2021-11-05'
PERIOD1=int(datetime(2021,11,5,tzinfo=timezone.utc).timestamp())
PERIOD2=int(datetime(2026,11,14,tzinfo=timezone.utc).timestamp())

def fetch(ticker):
    args={'period1':PERIOD1,'period2':PERIOD2,'interval':'1d',
          'events':'div,splits,capitalGains','includeAdjustedClose':'true'}
    url=f'https://query2.finance.yahoo.com/v8/finance/chart/{ticker}?'+urllib.parse.urlencode(args)
    error=None
    for attempt in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'})
            with urllib.request.urlopen(req,timeout=35) as resp:
                content=resp.read()
            data=json.loads(content)
            if data.get('chart',{}).get('error'):raise RuntimeError(str(data['chart']['error']))
            result=data['chart']['result'][0]
            retrieved=datetime.now(timezone.utc).isoformat()
            (RAW/f'{ticker}.json').write_bytes(content)
            times=result['timestamp'];meta=result['meta']
            tz=ZoneInfo(meta.get('exchangeTimezoneName','America/New_York'))
            days=[datetime.fromtimestamp(t,tz).date().isoformat() for t in times]
            quote=result['indicators']['quote'][0]
            frame=pd.DataFrame({'Date':days,'Close':quote['close'],
                       'AdjClose':result['indicators']['adjclose'][0]['adjclose'],
                       'Volume':quote.get('volume',[None]*len(times))}).set_index('Date')
            frame=frame.loc[(frame.index>=START)&(frame.index<=ASOF)]
            splits=[]
            for item in result.get('events',{}).get('splits',{}).values():
                splits.append({**item,'date_local':datetime.fromtimestamp(item['date'],tz).date().isoformat()})
            regular_ts=meta.get('regularMarketTime')
            source={'ticker':ticker,'url':url,'retrieved_at_utc':retrieved,
                    'raw_sha256':hashlib.sha256(content).hexdigest(),'raw_bytes':len(content),
                    'symbol':meta.get('symbol'),'currency':meta.get('currency'),
                    'exchange_timezone':meta.get('exchangeTimezoneName'),
                    'regular_market_price':meta.get('regularMarketPrice'),
                    'regular_market_time_utc':datetime.fromtimestamp(regular_ts,timezone.utc).isoformat() if regular_ts else None,
                    'first_trade_date_utc':datetime.fromtimestamp(meta['firstTradeDate'],timezone.utc).isoformat() if meta.get('firstTradeDate') else None,
                    'first_price_date':frame.index.min(),'last_price_date':frame.index.max(),
                    'n_prices':len(frame),'splits':splits,
                    'price_definition':'Yahoo Close is split-adjusted historical close; AdjClose additionally reflects provider dividend/corporate-action adjustment. No manual adjustment or filling applied.'}
            return ticker,frame,source
        except Exception as exc:
            error=repr(exc)
            if attempt<2:time.sleep(1+attempt)
    return ticker,None,{'ticker':ticker,'url':url,'error':error}

def main():
    frames={};provenance={};errors={}
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        for ticker,frame,source in pool.map(fetch,TICKERS):
            if frame is None:errors[ticker]=source;print('ERROR',ticker,source['error'],flush=True)
            else:
                frames[ticker]=frame;provenance[ticker]=source
                print(ticker,source['last_price_date'],f"{frame['Close'].iloc[-1]:.4f}",len(frame),flush=True)
    (OUT/'provenance.json').write_text(json.dumps({'analysis_asof':ASOF,'requested_start':START,
        'retrieval_basis':'Fresh full-history requests in this run; no appending or back-filling old cache',
        'sources':provenance,'errors':errors},ensure_ascii=False,indent=2))
    if errors:raise RuntimeError(f'Missing ticker downloads: {list(errors)}')
    close=pd.DataFrame({t:frames[t]['Close'] for t in TICKERS}).sort_index()
    adjusted=pd.DataFrame({t:frames[t]['AdjClose'] for t in TICKERS}).sort_index()
    close.index.name=adjusted.index.name='Date'
    close.to_csv(OUT/'close.csv');adjusted.to_csv(OUT/'adjusted_close.csv')
    daily=adjusted.pct_change(fill_method=None)
    daily.to_csv(OUT/'daily_returns.csv')
    qa={'asof':ASOF,'rows':len(close),'ticker_count':len(TICKERS),'date_start':close.index.min(),'date_end':close.index.max(),
        'duplicate_index':int(close.index.duplicated().sum()),'index_sorted':bool(close.index.is_monotonic_increasing),
        'missing_prices':close.isna().sum().astype(int).to_dict(),'missing_adjusted':adjusted.isna().sum().astype(int).to_dict(),
        'nonpositive_close':(close<=0).sum().astype(int).to_dict(),'nonpositive_adjusted':(adjusted<=0).sum().astype(int).to_dict(),
        'last_date_is_nov13':{t:provenance[t]['last_price_date']==ASOF for t in TICKERS},
        'all_currency_usd':all(provenance[t]['currency']=='USD' for t in TICKERS),
        'last_close_vs_regular_market_price_absolute_diff':{t:float(abs(close.loc[ASOF,t]-provenance[t]['regular_market_price'])) for t in TICKERS},
        'adjusted_absolute_returns_gt_80pct':[],'old_history_comparison':{},
        'notes':['CEG listed in January2022, so the five-year panel deliberately retains prelisting missing values; no forward/back filling.',
                 'To compare the original 26-asset universe or proposed portfolios without CEG, use their complete common window; do not truncate all columns merely for CEG.',
                 'Regular-market metadata prices are checked against daily session closes; postmarket quotes are not used.',
                 'Adjusted historical levels may change after new distributions; compare old vs new historical returns, not levels alone.']}
    for t in TICKERS:
        for day,x in daily[t].dropna().items():
            if abs(x)>.8:qa['adjusted_absolute_returns_gt_80pct'].append({'ticker':t,'date':day,'return':float(x)})
    oldfile=ROOT/'ai_expansion_analysis/adjusted_close.csv'
    if oldfile.exists():
        old=pd.read_csv(oldfile,index_col=0)
        oldr=old.pct_change(fill_method=None)
        for t in old.columns:
            idx=oldr.index.intersection(daily.index)
            a=oldr.loc[idx,t];b=daily.loc[idx,t];valid=a.notna()&b.notna();diff=(a[valid]-b[valid]).abs()
            ratio=adjusted.loc[old.index.intersection(adjusted.index),t]/old.loc[old.index.intersection(adjusted.index),t]
            qa['old_history_comparison'][t]={'n_compared_returns':int(valid.sum()),'max_absolute_daily_return_difference':float(diff.max()),
                'count_return_differences_gt_1bp':int((diff>.0001).sum()),'new_to_old_adj_level_ratio_min':float(ratio.min()),'new_to_old_adj_level_ratio_max':float(ratio.max())}
    assert qa['duplicate_index']==0 and qa['index_sorted'] and qa['all_currency_usd']
    assert all(qa['last_date_is_nov13'].values())
    assert sum(qa['nonpositive_close'].values())==0 and sum(qa['nonpositive_adjusted'].values())==0
    assert not qa['adjusted_absolute_returns_gt_80pct']
    assert max(qa['last_close_vs_regular_market_price_absolute_diff'].values())<.011
    (OUT/'quality_checks.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
    # Two-year start is exactly an observed Nov13 2024 close.
    p=adjusted.loc['2024-11-13':ASOF]
    r=p.pct_change(fill_method=None).iloc[1:]
    assert not r.isna().any().any()
    threshold=float(r['NVDA'].quantile(.10));tail=r['NVDA']<=threshold
    crash=r['NVDA']<=-.10
    metrics=[]
    for t in TICKERS:
        x=r[t];wealth=(1+x).cumprod();dd=wealth/wealth.cummax().clip(lower=1)-1
        metrics.append({'ticker':t,'last_close':float(close.loc[ASOF,t]),'last_adjusted_close':float(adjusted.loc[ASOF,t]),
            'ann_vol':float(x.std(ddof=1)*np.sqrt(252)),'rho_nvda':float(x.corr(r['NVDA'])),
            'beta_vti':float(x.cov(r['VTI'])/r['VTI'].var(ddof=1)),
            'max_drawdown':float(dd.min()),'es95_daily_loss':float(-x[x<=x.quantile(.05)].mean()),
            'cagr':float(wealth.iloc[-1]**(365.25/(pd.Timestamp(ASOF)-pd.Timestamp('2024-11-13')).days)-1),
            'rho_nvda_worst_decile':float(x[tail].corr(r.loc[tail,'NVDA'])),
            'mean_return_on_nvda_worst_decile_days':float(x[tail].mean()),
            'prob_negative_on_nvda_worst_decile_days':float((x[tail]<0).mean()),
            'mean_return_on_nvda_drop10pct_days':float(x[crash].mean()) if crash.any() else None,
            'week_price_return_nov6_to_nov13':float(close.loc[ASOF,t]/close.loc['2026-11-06',t]-1),
            'week_total_return_nov6_to_nov13':float(adjusted.loc[ASOF,t]/adjusted.loc['2026-11-06',t]-1),
            'nov13_daily_return':float(r.loc[ASOF,t]),'n_returns':len(x)})
    pd.DataFrame(metrics).to_csv(OUT/'two_year_asset_metrics.csv',index=False)
    r.corr().to_csv(OUT/'two_year_correlation.csv')
    r.cov().to_csv(OUT/'two_year_daily_covariance.csv')
    summary={'asof':ASOF,'two_year_price_start':'2024-11-13','two_year_return_start':r.index.min(),
        'two_year_return_end':r.index.max(),'n_returns':len(r),'tail_definition':'NVDA return <= empirical 10th percentile of its two-year daily returns; not NVDA falling10% in a day.',
        'tail_nvda_daily_return_threshold':threshold,'n_tail_days':int(tail.sum()),
        'nvda_drop10pct_definition':'NVDA simple adjusted daily return <= -10%; small sample, not an estimated forward crash probability.',
        'n_nvda_drop10pct_days':int(crash.sum()),'nvda_drop10pct_dates':r.index[crash].tolist(),
        'week_price_start':'2026-11-06','week_price_end':ASOF,'week_return_observations':5,
        'metrics':metrics,'interpretation':'Historical descriptive statistics only; nonstationary correlations and sample-selection effects apply. Conditional correlation on a truncated NVDA sample can suffer range-restriction bias.'}
    (OUT/'asset_metrics.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
    print('QA_OK',len(TICKERS),'tickers;',len(close),'price dates;',len(r),'two-year returns; tail',int(tail.sum()),flush=True)
    print(pd.DataFrame(metrics)[['ticker','last_close','ann_vol','rho_nvda','beta_vti','week_price_return_nov6_to_nov13']].round(4).to_string(index=False))

if __name__=='__main__':main()
